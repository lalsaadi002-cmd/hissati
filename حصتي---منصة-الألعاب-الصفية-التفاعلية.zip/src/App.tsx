/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Activity, GameType, QuestionSet } from './types';
import { GAME_TYPE_METADATA } from './data/initialData';
import { storage } from './services/storageService';
import { sound } from './services/soundService';
import { fireCelebrationConfetti } from './utils/confetti';

// Components
import { Navbar } from './components/Navbar';
import { GameContainer } from './components/GameContainer';
import { ActivityEditorModal } from './components/ActivityEditorModal';
import { QuestionBankModal } from './components/QuestionBankModal';
import {
  BackgroundDoodles,
  GameIllustrations,
  HeroEducationalIllustration,
} from './components/decorative/EducationalDoodles';

// Lucide icons
import {
  Trophy,
  Package,
  CircleDashed,
  CheckCircle2,
  Layers,
  GitCommit,
  Timer,
  Star,
  Ticket,
  Plus,
  Play,
  Edit3,
  Trash2,
  Database,
  Sparkles,
  ArrowRight,
  BookOpen,
  Monitor,
  Flame,
  Search,
  Zap,
  Award,
  Users,
  Compass,
} from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'games' | 'activities' | 'question-bank'>('home');
  const [activities, setActivities] = useState<Activity[]>(() => storage.getActivities());
  const [questionSets, setQuestionSets] = useState<QuestionSet[]>(() => storage.getQuestionSets());
  
  // Active game session
  const [activeActivity, setActiveActivity] = useState<Activity | null>(null);

  // Modals state
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [preSelectedGameType, setPreSelectedGameType] = useState<GameType | undefined>(undefined);
  const [preSelectedQuestionSet, setPreSelectedQuestionSet] = useState<QuestionSet | null>(null);

  const [isQuestionBankOpen, setIsQuestionBankOpen] = useState(false);
  const [questionBankCreateMode, setQuestionBankCreateMode] = useState(false);
  const [isMuted, setIsMuted] = useState(() => sound.isMuted());

  // Search in activities
  const [activitySearchQuery, setActivitySearchQuery] = useState('');

  const refreshData = () => {
    setActivities(storage.getActivities());
    setQuestionSets(storage.getQuestionSets());
  };

  const handleToggleMute = () => {
    const next = sound.toggleMute();
    setIsMuted(next);
  };

  // Launch game
  const handleLaunchActivity = (act: Activity) => {
    sound.playClick();
    sound.playCorrect();
    fireCelebrationConfetti();
    storage.incrementActivityPlay(act.id);
    refreshData();
    setActiveActivity(act);
  };

  // Start new activity with chosen game type
  const handleCreateWithGameType = (type: GameType) => {
    sound.playClick();
    fireCelebrationConfetti();
    setEditingActivity(null);
    setPreSelectedGameType(type);
    setPreSelectedQuestionSet(null);
    setIsEditorOpen(true);
  };

  // Start activity from Question Bank Set with optional chosen game type
  const handlePlayWithQuestionSet = (qSet: QuestionSet, chosenGameType?: GameType) => {
    sound.playClick();
    fireCelebrationConfetti();
    setEditingActivity(null);
    setPreSelectedGameType(chosenGameType || 'team-race');
    setPreSelectedQuestionSet(qSet);
    setIsEditorOpen(true);
  };

  // Edit existing activity
  const handleEditActivity = (act: Activity) => {
    sound.playClick();
    setEditingActivity(act);
    setPreSelectedGameType(act.gameType);
    setPreSelectedQuestionSet(null);
    setIsEditorOpen(true);
  };

  // Delete activity
  const handleDeleteActivity = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('هل أنت متأكد من حذف هذا النشاط؟')) {
      sound.playClick();
      storage.deleteActivity(id);
      refreshData();
      if (activeActivity?.id === id) {
        setActiveActivity(null);
      }
    }
  };

  // After saving from editor
  const handleSaveActivity = (savedActivity: Activity, launchImmediately = false) => {
    refreshData();
    if (launchImmediately) {
      setActiveActivity(savedActivity);
    }
  };

  // If game is active on smartboard/screen, render the GameContainer
  if (activeActivity) {
    return (
      <GameContainer
        activity={activeActivity}
        onBack={() => setActiveActivity(null)}
        onEditActivity={(act) => handleEditActivity(act)}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />
    );
  }

  const allGameTypes: GameType[] = [
    'team-race',
    'mystery-box',
    'wheel-of-names',
    'multiple-choice',
    'flip-card',
    'matching',
    'time-attack',
    'class-points',
    'exit-ticket',
  ];

  const filteredActivities = activities.filter((a) =>
    a.title.toLowerCase().includes(activitySearchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen text-slate-800 flex flex-col font-sans relative overflow-x-hidden">
      
      {/* Playful Floating Educational Background Doodles */}
      <BackgroundDoodles />

      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          if (tab === 'question-bank') {
            setIsQuestionBankOpen(true);
          } else {
            setCurrentTab(tab);
          }
        }}
        onCreateActivity={() => {
          setEditingActivity(null);
          setPreSelectedGameType('team-race');
          setPreSelectedQuestionSet(null);
          setIsEditorOpen(true);
        }}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-14 relative z-10">
        
        {/* HERO BANNER SECTION (Shows on Home) */}
        {currentTab === 'home' && (
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-indigo-900 to-purple-950 text-white p-8 sm:p-12 shadow-2xl shadow-indigo-950/30 border-2 border-indigo-700/60">
            
            {/* Glowing background flares */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-purple-500/25 to-pink-500/10 rounded-full blur-3xl pointer-events-none -mr-32 -mt-32" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/25 rounded-full blur-3xl pointer-events-none -ml-32 -mb-32" />

            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* Left Column: Copy & Actions */}
              <div className="lg:col-span-7 flex flex-col gap-6">
                
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="text-xs font-black text-amber-300 bg-amber-400/20 border border-amber-300/40 px-4 py-1.5 rounded-full flex items-center gap-2 backdrop-blur-xs shadow-sm">
                    <span className="animate-spin text-sm">✨</span>
                    <span>حوّل أسئلة الدرس إلى ألعاب وتحديات ذكية</span>
                  </span>
                  <span className="text-xs font-bold text-cyan-200 bg-cyan-500/20 border border-cyan-400/30 px-3.5 py-1.5 rounded-full backdrop-blur-xs">
                    📺 ملائم للبروجكتر والشاشات الذكية
                  </span>
                </div>

                <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight sm:leading-tight drop-shadow-md">
                  حوّل حصتك إلى{' '}
                  <span className="bg-gradient-to-r from-amber-300 via-orange-300 to-yellow-200 bg-clip-text text-transparent">
                    تجربة تفاعلية ممتعة
                  </span>
                </h1>

                <p className="text-sm sm:text-lg text-indigo-100/90 leading-relaxed font-medium max-w-xl">
                  منصة ألعاب صفية حركية للمعلمين تُحفز التفكير الجماعي والتنافس الإيجابي بين الطلاب، وتجعل كل دقيقة في الحصة مليئة بالحماس والتركيز!
                </p>

                {/* Primary Action Buttons */}
                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <button
                    onClick={() => {
                      sound.playClick();
                      sound.playCorrect();
                      fireCelebrationConfetti();
                      setEditingActivity(null);
                      setPreSelectedGameType('team-race');
                      setPreSelectedQuestionSet(null);
                      setIsEditorOpen(true);
                    }}
                    className="px-8 py-4 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black text-base rounded-2xl shadow-xl shadow-amber-400/30 transition-all flex items-center gap-2.5 cursor-pointer tactile-btn group"
                  >
                    <Plus className="w-5 h-5 stroke-[3] group-hover:rotate-90 transition-transform duration-200" />
                    <span>إنشاء نشاط جديد الآن</span>
                  </button>

                  <button
                    onClick={() => {
                      sound.playClick();
                      setQuestionBankCreateMode(false);
                      setIsQuestionBankOpen(true);
                    }}
                    className="px-6 py-4 bg-white/10 hover:bg-white/20 text-white font-bold text-sm rounded-2xl border border-white/20 backdrop-blur-md transition-all flex items-center gap-2 cursor-pointer tactile-btn"
                  >
                    <Database className="w-4 h-4 text-cyan-300" />
                    <span>بنك الأسئلة المفتوح</span>
                  </button>
                </div>

                {/* Quick Interactive Highlights */}
                <div className="grid grid-cols-3 gap-3 pt-3 border-t border-indigo-700/50 text-center">
                  <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl">
                    <span className="block text-2xl font-black text-amber-300 font-mono">9</span>
                    <span className="text-[11px] text-indigo-200 font-bold">ألعاب صفية متنوعة</span>
                  </div>
                  <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl">
                    <span className="block text-2xl font-black text-emerald-300 font-mono">100%</span>
                    <span className="text-[11px] text-indigo-200 font-bold">تفاعل وانضباط صفي</span>
                  </div>
                  <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl">
                    <span className="block text-2xl font-black text-cyan-300 font-mono">0 ثانية</span>
                    <span className="text-[11px] text-indigo-200 font-bold">جاهز للشاشة فوراً</span>
                  </div>
                </div>

              </div>

              {/* Right Column: Grand Hero Educational Illustration */}
              <div className="lg:col-span-5 flex items-center justify-center">
                <HeroEducationalIllustration />
              </div>

            </div>
          </div>
        )}

        {/* SECTION: مكتبة الألعاب (Arcade / Interactive Learning Games) */}
        {(currentTab === 'home' || currentTab === 'games') && (
          <section className="space-y-6">
            
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-black uppercase tracking-wider text-indigo-700 bg-indigo-100/80 border border-indigo-200 px-3 py-1 rounded-full flex items-center gap-1.5 shadow-2xs">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>صالات الألعاب التعليمية</span>
                  </span>
                </div>
                <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                  <Trophy className="w-8 h-8 text-amber-500 fill-amber-400" />
                  <span>مكتبة ألعاب "حصتي" التسع التفاعلية</span>
                </h2>
                <p className="text-xs sm:text-base text-slate-600 mt-1 font-medium">
                  اختر لعبة مناسبة لهدف حصتك؛ لكل لعبة ميكانيكية ورسومات وتحديات خاصة تنبض بالحياة
                </p>
              </div>

              {currentTab === 'home' && (
                <button
                  onClick={() => {
                    sound.playClick();
                    setCurrentTab('games');
                  }}
                  className="text-xs sm:text-sm font-black text-indigo-700 hover:text-indigo-900 bg-white hover:bg-indigo-50 border border-indigo-200 px-4 py-2.5 rounded-2xl shadow-xs transition-all flex items-center gap-2 cursor-pointer tactile-btn"
                >
                  <span>عرض جميع الألعاب (9)</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* 9 Rich Illustrated Game Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {allGameTypes.map((type) => {
                const meta = GAME_TYPE_METADATA[type];
                const IllustrationComponent = GameIllustrations[type];

                return (
                  <div
                    key={type}
                    className={`rounded-3xl border-2 ${meta.borderAccent} bg-white shadow-md game-card-hover flex flex-col justify-between overflow-hidden relative group`}
                  >
                    {/* Thematic Illustrated Visual Scene Banner */}
                    <div className={`p-4 bg-gradient-to-r ${meta.color} text-white relative overflow-hidden flex flex-col justify-between min-h-[140px]`}>
                      
                      {/* Top bar with Badge and Emoji icon */}
                      <div className="flex items-center justify-between relative z-10">
                        <span className="text-xs font-black uppercase tracking-wide bg-black/30 backdrop-blur-xs px-3 py-1 rounded-full text-white">
                          {meta.badge}
                        </span>
                        <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 group-hover:rotate-6 transition-transform">
                          {meta.emoji}
                        </div>
                      </div>

                      {/* Embedded custom SVG illustration scene */}
                      <div className="my-auto py-1">
                        {IllustrationComponent ? (
                          <IllustrationComponent className="w-full h-24" />
                        ) : null}
                      </div>

                      {/* Game Title on banner */}
                      <div className="relative z-10 pt-1">
                        <h3 className="text-xl font-black text-white drop-shadow-sm">
                          {meta.name}
                        </h3>
                      </div>
                    </div>

                    {/* Content Body */}
                    <div className="p-6 flex-1 flex flex-col justify-between gap-5 bg-white">
                      <div>
                        <div className="text-xs font-black text-indigo-700 bg-indigo-50/80 px-2.5 py-1 rounded-lg inline-flex items-center gap-1.5 mb-2">
                          <Sparkles className="w-3 h-3 text-amber-500" />
                          <span>{meta.tagline}</span>
                        </div>
                        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
                          {meta.description}
                        </p>
                      </div>

                      {/* Action Button */}
                      <div className="pt-2">
                        <button
                          onClick={() => handleCreateWithGameType(type)}
                          className={`w-full py-3.5 bg-gradient-to-r ${meta.btnGradient} text-white font-black text-sm rounded-2xl shadow-md transition-all flex items-center justify-center gap-2.5 cursor-pointer tactile-btn`}
                        >
                          <Play className="w-4 h-4 fill-current" />
                          <span>بدء اللعبة أو تجهيز نشاط</span>
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>

          </section>
        )}

        {/* SECTION: أنشطتي المحفوظة */}
        {(currentTab === 'home' || currentTab === 'activities') && (
          <section className="space-y-6">
            
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-black uppercase tracking-wider text-purple-700 bg-purple-100/80 border border-purple-200 px-3 py-1 rounded-full flex items-center gap-1.5 shadow-2xs">
                    <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                    <span>أنشطة المعلم المحفوظة</span>
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                  <Award className="w-7 h-7 text-purple-600" />
                  <span>أنشطتي المحفوظة وجاهزة للعرض</span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-1 font-medium">
                  أنشطتك المجهزة سابقاً، جاهزة للعرض التفاعلي على الشاشات الذكية بضغطة واحدة
                </p>
              </div>

              {/* Search input in activities */}
              <div className="flex items-center gap-3">
                <div className="relative min-w-[240px]">
                  <input
                    type="text"
                    value={activitySearchQuery}
                    onChange={(e) => setActivitySearchQuery(e.target.value)}
                    placeholder="بحث في أنشطتي المحفوظة..."
                    className="w-full pl-3 pr-9 py-2.5 text-xs font-bold border border-slate-200 rounded-2xl bg-white shadow-xs focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
                </div>

                <button
                  onClick={() => {
                    sound.playClick();
                    setEditingActivity(null);
                    setPreSelectedGameType('team-race');
                    setPreSelectedQuestionSet(null);
                    setIsEditorOpen(true);
                  }}
                  className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-xs rounded-2xl shadow-sm transition-all flex items-center gap-2 cursor-pointer tactile-btn"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>نشاط جديد</span>
                </button>
              </div>
            </div>

            {/* Activities List Cards */}
            {filteredActivities.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-purple-200 flex flex-col items-center gap-3 shadow-xs">
                <BookOpen className="w-12 h-12 text-purple-300 stroke-[1.5]" />
                <h3 className="font-bold text-base text-slate-700">لا توجد أنشطة مطابقة للبحث</h3>
                <p className="text-xs text-slate-500 max-w-sm font-medium">
                  اضغط على زر "نشاط جديد" لاختيار لعبة وإضافة أسئلتك لتكون جاهزة لطلابك.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredActivities.map((act) => {
                  const meta = GAME_TYPE_METADATA[act.gameType] || {
                    name: 'لعبة تفاعلية',
                    color: 'from-indigo-600 to-purple-600',
                    badge: 'نشاط',
                    emoji: '🎯',
                    accentBg: 'bg-indigo-50/50',
                  };

                  return (
                    <div
                      key={act.id}
                      onClick={() => handleLaunchActivity(act)}
                      className="bg-white rounded-3xl p-6 border-2 border-slate-200/90 shadow-sm hover:shadow-lg hover:border-purple-300 transition-all duration-200 flex flex-col justify-between gap-5 cursor-pointer select-none group game-card-hover"
                    >
                      <div>
                        {/* Top tag & type */}
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-black text-purple-800 bg-purple-100/80 border border-purple-200 px-3 py-1 rounded-xl flex items-center gap-1.5">
                            <span>{meta.emoji}</span>
                            <span>{meta.name}</span>
                          </span>
                          <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-lg font-mono">
                            لُعبت {act.playsCount || 0} مرات
                          </span>
                        </div>

                        <h3 className="text-lg sm:text-xl font-black text-slate-900 group-hover:text-purple-700 transition-colors leading-snug">
                          {act.title}
                        </h3>

                        <div className="flex items-center gap-2.5 text-xs text-slate-600 mt-2.5 font-bold">
                          <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg font-mono">
                            {act.questions.length} أسئلة
                          </span>
                          <span>·</span>
                          <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-bold">
                            ✓ جاهز للشاشة الذكية
                          </span>
                        </div>
                      </div>

                      {/* Bottom actions */}
                      <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleLaunchActivity(act);
                          }}
                          className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-500/20 flex items-center gap-2 transition-all cursor-pointer tactile-btn"
                        >
                          <Play className="w-4 h-4 fill-current" />
                          <span>عرض اللعبة للطلاب</span>
                        </button>

                        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => handleEditActivity(act)}
                            className="p-2.5 text-slate-500 hover:text-indigo-700 hover:bg-indigo-50 rounded-xl transition-colors cursor-pointer tactile-btn"
                            title="تعديل الأسئلة"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteActivity(act.id, e)}
                            className="p-2.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer tactile-btn"
                            title="حذف النشاط"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

          </section>
        )}

        {/* SECTION: بنك الأسئلة المفتوح للمعلم */}
        {currentTab === 'home' && (
          <section className="rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-cyan-100/70 via-blue-50/60 to-indigo-100/50 border-2 border-cyan-200/80 shadow-md space-y-6 relative overflow-hidden">
            
            {/* Background sparkle badge */}
            <div className="absolute -top-12 -left-12 w-48 h-48 bg-cyan-300/30 rounded-full blur-2xl pointer-events-none" />

            <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-black uppercase tracking-wider text-cyan-800 bg-cyan-200/80 border border-cyan-300 px-3 py-1 rounded-full flex items-center gap-1.5 shadow-2xs">
                    <Database className="w-3.5 h-3.5 text-cyan-700" />
                    <span>بنك الأسئلة المفتوح للمعلم</span>
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                  <span>مجموعات الأسئلة المخصصة</span>
                </h3>
                <p className="text-xs sm:text-base text-slate-700 mt-1 font-medium">
                  أنشئ مجموعاتك الخاصة بحرية لأي مادة وصف ودرس، واستخدمها في أي لعبة من الألعاب التسع بضغطة زر
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => {
                    sound.playClick();
                    setQuestionBankCreateMode(true);
                    setIsQuestionBankOpen(true);
                  }}
                  className="px-5 py-3 bg-gradient-to-r from-cyan-600 via-teal-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-black text-xs sm:text-sm rounded-2xl shadow-md shadow-cyan-600/20 transition-all cursor-pointer flex items-center gap-2 tactile-btn"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>+ إنشاء مجموعة أسئلة جديدة</span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    setQuestionBankCreateMode(false);
                    setIsQuestionBankOpen(true);
                  }}
                  className="px-4 py-3 bg-white hover:bg-cyan-50 border border-cyan-300 text-cyan-900 font-black text-xs sm:text-sm rounded-2xl shadow-sm transition-all cursor-pointer flex items-center gap-2 tactile-btn"
                >
                  <span>إدارة بنك الأسئلة</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Curriculum notebook cards or empty state */}
            {questionSets.length === 0 ? (
              <div className="bg-white/80 rounded-3xl p-8 text-center border-2 border-dashed border-cyan-300 flex flex-col items-center justify-center gap-3 relative z-10 shadow-xs">
                <div className="w-12 h-12 rounded-2xl bg-cyan-100 text-cyan-700 flex items-center justify-center text-2xl font-bold">
                  📚
                </div>
                <h4 className="font-black text-base text-slate-900">
                  لا توجد مجموعات أسئلة بعد
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 max-w-md font-medium leading-relaxed">
                  النظام مفتوح بالكامل؛ اضغط على زر الإنشاء واكتب اسم المادة والصف والدرس وأسئلتك بحرية تامة دون أي قيود مسبقة.
                </p>
                <button
                  onClick={() => {
                    sound.playClick();
                    setQuestionBankCreateMode(true);
                    setIsQuestionBankOpen(true);
                  }}
                  className="mt-1 px-6 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-black text-xs rounded-xl shadow-md shadow-cyan-600/20 transition-all flex items-center gap-2 cursor-pointer tactile-btn"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>+ إنشاء مجموعة أسئلة جديدة الآن</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative z-10">
                {questionSets.slice(0, 4).map((set) => (
                  <div
                    key={set.id}
                    className="bg-white rounded-3xl p-5 border-2 border-cyan-200/70 shadow-sm flex flex-col justify-between gap-4 hover:border-cyan-400 transition-all game-card-hover"
                  >
                    <div>
                      <span className="text-[11px] font-black text-cyan-900 bg-cyan-100/90 border border-cyan-200 px-3 py-1 rounded-lg">
                        {set.subject} · {set.grade}
                      </span>
                      <h4 className="font-black text-base text-slate-900 mt-3 leading-snug">
                        {set.title}
                      </h4>
                      <span className="text-xs font-mono font-bold text-slate-500 mt-1.5 block">
                        {set.questions.length} أسئلة
                      </span>
                    </div>

                    <button
                      onClick={() => handlePlayWithQuestionSet(set)}
                      className="w-full py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-black text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-cyan-600/20 tactile-btn"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>العب بهذه الأسئلة في لعبة</span>
                    </button>
                  </div>
                ))}
              </div>
            )}

          </section>
        )}

      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-indigo-200/80 bg-white/70 py-8 backdrop-blur-md relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600 font-bold">
          <div className="flex items-center gap-2.5">
            <span className="font-black text-slate-900 text-base">حِصَّتِي</span>
            <span>·</span>
            <span>منصة الألعاب والتحديات الصفية التفاعلية للشاشات الذكية</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (confirm('هل تريد تفريغ الأنشطة ومجموعات الأسئلة والبدء بسجل نظيف جديد؟')) {
                  storage.resetToDefaults();
                  refreshData();
                  sound.playClick();
                }
              }}
              className="text-slate-500 hover:text-rose-600 cursor-pointer transition-colors"
            >
              تفريغ البيانات والبدء بسجل نظيف
            </button>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      <ActivityEditorModal
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        activityToEdit={editingActivity}
        preSelectedGameType={preSelectedGameType}
        preSelectedQuestionSet={preSelectedQuestionSet}
        onSave={handleSaveActivity}
        onRequestCreateQuestionSet={() => {
          setIsEditorOpen(false);
          setQuestionBankCreateMode(true);
          setIsQuestionBankOpen(true);
        }}
      />

      <QuestionBankModal
        isOpen={isQuestionBankOpen}
        onClose={() => {
          setIsQuestionBankOpen(false);
          setQuestionBankCreateMode(false);
          refreshData();
        }}
        onPlayWithSet={handlePlayWithQuestionSet}
        initialCreateMode={questionBankCreateMode}
      />

    </div>
  );
}

function ChevronLeft({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="m15 18-6-6 6-6" />
    </svg>
  );
}
