export type GameType = 
  | 'team-race'        // تحدي الفريقين
  | 'mystery-box'      // الصندوق الغامض
  | 'wheel-of-names'   // عجلة الأسماء
  | 'multiple-choice'  // اختر الإجابة الصحيحة
  | 'flip-card'        // اقلب البطاقة
  | 'matching'         // لعبة المطابقة
  | 'time-attack'      // تحدي الوقت
  | 'class-points'     // نقاط الفصل
  | 'exit-ticket';     // تذكرة الخروج

export interface Question {
  id: string;
  text: string;
  options?: string[]; // for multiple choice
  correctAnswer: string | number; // index or text
  explanation?: string;
  points?: number;
  timeLimit?: number; // seconds
  matchPairs?: { left: string; right: string }[]; // for matching games
}

export interface QuestionSet {
  id: string;
  title: string;       // اسم المجموعة
  subject: string;     // المادة (حرة)
  grade: string;       // الصف الدراسي (حر)
  lesson?: string;     // اسم الدرس أو الوحدة (حر)
  description?: string;
  questions: Question[];
  createdAt: number;
  updatedAt: number;
}

export interface Activity {
  id: string;
  title: string;
  gameType: GameType;
  questionSetId?: string;
  questions: Question[];
  config?: Record<string, any>;
  createdAt: number;
  updatedAt: number;
  playsCount: number;
  lastPlayedAt?: number;
}

export interface StudentProfile {
  id: string;
  name: string;
  avatarSeed?: string;
  points: number;
  badges: string[];
}

export interface TeamProfile {
  id: string;
  name: string;
  color: string;
  score: number;
  position: number; // for race 0 to 100
  avatar: string;
}

export interface StudentListGroup {
  id: string;
  name: string;
  students: string[];
  createdAt: number;
}
