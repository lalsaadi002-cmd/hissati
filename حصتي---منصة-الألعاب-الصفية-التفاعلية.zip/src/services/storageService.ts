import { QuestionSet, Activity, StudentProfile, StudentListGroup } from '../types';
import { INITIAL_QUESTION_SETS, INITIAL_SAVED_ACTIVITIES, INITIAL_STUDENTS_LIST } from '../data/initialData';

const STORAGE_KEYS = {
  QUESTION_SETS: 'hessaty_question_sets_v8',
  ACTIVITIES: 'hessaty_activities_v8',
  STUDENTS: 'hessaty_students_v1',
  STUDENT_LISTS: 'hessaty_student_lists_v1',
  ACTIVE_STUDENT_LIST_ID: 'hessaty_active_student_list_id',
};

const DEFAULT_STUDENT_LISTS: StudentListGroup[] = [
  {
    id: 'list-oman-4-1',
    name: 'الصف الرابع/1',
    students: [
      'أحمد البلوشي',
      'فاطمة المعمرية',
      'محمد الحارثي',
      'سارة الشبيبية',
      'سالم العامري',
      'مريم الرواحية',
      'عبدالله الهنائي',
      'نورة الخروصية',
    ],
    createdAt: Date.now() - 1000 * 60 * 60 * 48,
  },
  {
    id: 'list-oman-7-2',
    name: 'الصف السابع/2',
    students: [
      'خالد السعدي',
      'شهد الغافرية',
      'عمر البوسعيدي',
      'ريان الكندية',
      'حمد اليعربي',
      'آية الفارسية',
      'يوسف المعولي',
      'جنى الهاشمية',
    ],
    createdAt: Date.now() - 1000 * 60 * 60 * 24,
  },
];

// Immediate cleanup of legacy demo caches from prior versions
if (typeof window !== 'undefined' && window.localStorage) {
  try {
    const legacyKeys = [
      'hessaty_question_sets_v1',
      'hessaty_question_sets_v2',
      'hessaty_question_sets_v3',
      'hessaty_question_sets_v4',
      'hessaty_question_sets_v5',
      'hessaty_question_sets_v6',
      'hessaty_question_sets_v7',
      'hessaty_activities_v1',
      'hessaty_activities_v2',
      'hessaty_activities_v3',
      'hessaty_activities_v4',
      'hessaty_activities_v5',
      'hessaty_activities_v6',
      'hessaty_activities_v7',
    ];
    legacyKeys.forEach((key) => {
      localStorage.removeItem(key);
    });
  } catch (e) {
    // Ignore in non-browser env
  }
}

class StorageService {
  // Question Sets - Fully editable/deletable starter examples + open creation
  public getQuestionSets(): QuestionSet[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.QUESTION_SETS);
      if (data === null) {
        this.saveQuestionSets(INITIAL_QUESTION_SETS);
        return INITIAL_QUESTION_SETS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_QUESTION_SETS;
    }
  }

  public saveQuestionSets(sets: QuestionSet[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.QUESTION_SETS, JSON.stringify(sets));
    } catch (e) {
      console.error('Failed to save question sets', e);
    }
  }

  public getQuestionSetById(id: string): QuestionSet | undefined {
    const sets = this.getQuestionSets();
    return sets.find((s) => s.id === id);
  }

  public saveOrUpdateQuestionSet(set: QuestionSet): void {
    const sets = this.getQuestionSets();
    const index = sets.findIndex((s) => s.id === set.id);
    if (index >= 0) {
      sets[index] = { ...set, updatedAt: Date.now() };
    } else {
      sets.unshift({ ...set, createdAt: Date.now(), updatedAt: Date.now() });
    }
    this.saveQuestionSets(sets);
  }

  public deleteQuestionSet(id: string): void {
    const sets = this.getQuestionSets().filter((s) => s.id !== id);
    this.saveQuestionSets(sets);
  }

  // Activities
  public getActivities(): Activity[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACTIVITIES);
      if (data === null) {
        this.saveActivities(INITIAL_SAVED_ACTIVITIES);
        return INITIAL_SAVED_ACTIVITIES;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_SAVED_ACTIVITIES;
    }
  }

  public saveActivities(activities: Activity[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(activities));
    } catch (e) {
      console.error('Failed to save activities', e);
    }
  }

  public getActivityById(id: string): Activity | undefined {
    const list = this.getActivities();
    return list.find((a) => a.id === id);
  }

  public saveOrUpdateActivity(activity: Activity): void {
    const list = this.getActivities();
    const index = list.findIndex((a) => a.id === activity.id);
    if (index >= 0) {
      list[index] = { ...activity, updatedAt: Date.now() };
    } else {
      list.unshift({ ...activity, createdAt: Date.now(), updatedAt: Date.now() });
    }
    this.saveActivities(list);
  }

  public incrementActivityPlay(id: string): void {
    const list = this.getActivities();
    const item = list.find((a) => a.id === id);
    if (item) {
      item.playsCount = (item.playsCount || 0) + 1;
      item.lastPlayedAt = Date.now();
      this.saveActivities(list);
    }
  }

  public deleteActivity(id: string): void {
    const list = this.getActivities().filter((a) => a.id !== id);
    this.saveActivities(list);
  }

  // Multiple Named Student Lists
  public getStudentLists(): StudentListGroup[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.STUDENT_LISTS);
      if (data === null) {
        this.saveStudentLists(DEFAULT_STUDENT_LISTS);
        return DEFAULT_STUDENT_LISTS;
      }
      return JSON.parse(data);
    } catch {
      return DEFAULT_STUDENT_LISTS;
    }
  }

  public saveStudentLists(lists: StudentListGroup[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.STUDENT_LISTS, JSON.stringify(lists));
    } catch (e) {
      console.error('Failed to save student lists', e);
    }
  }

  public getActiveStudentListId(): string | null {
    try {
      return localStorage.getItem(STORAGE_KEYS.ACTIVE_STUDENT_LIST_ID);
    } catch {
      return null;
    }
  }

  public setActiveStudentListId(id: string): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_STUDENT_LIST_ID, id);
    } catch (e) {
      console.error('Failed to set active student list id', e);
    }
  }

  // Students list (legacy compatibility)
  public getStudents(): string[] {
    try {
      const activeId = this.getActiveStudentListId();
      const lists = this.getStudentLists();
      if (activeId) {
        const found = lists.find((l) => l.id === activeId);
        if (found) return found.students;
      }
      if (lists.length > 0) {
        return lists[0].students;
      }
      return [];
    } catch {
      return [];
    }
  }

  public saveStudents(students: string[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    } catch (e) {
      console.error('Failed to save students', e);
    }
  }

  // Reset to initial empty state
  public resetToDefaults(): void {
    this.saveQuestionSets([]);
    this.saveActivities([]);
    this.saveStudentLists(DEFAULT_STUDENT_LISTS);
    this.saveStudents(INITIAL_STUDENTS_LIST);
  }
}

export const storage = new StorageService();
