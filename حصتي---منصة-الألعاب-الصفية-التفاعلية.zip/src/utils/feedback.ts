export const CORRECT_FEEDBACK_PHRASES = [
  'أحسنت! 👏',
  'رائع! 🌟',
  'إجابة صحيحة! 🎉',
  'ممتاز! 🏆',
  'واصلوا الإبداع! ✨',
];

export const INCORRECT_FEEDBACK_PHRASES = [
  'حاول مرة أخرى',
  'قريب! فكّر مرة أخرى',
  'لا بأس، حاول من جديد',
];

export function getRandomCorrectPhrase(): string {
  return CORRECT_FEEDBACK_PHRASES[Math.floor(Math.random() * CORRECT_FEEDBACK_PHRASES.length)];
}

export function getRandomIncorrectPhrase(): string {
  return INCORRECT_FEEDBACK_PHRASES[Math.floor(Math.random() * INCORRECT_FEEDBACK_PHRASES.length)];
}

export function getRandomFeedback(isCorrect: boolean): string {
  return isCorrect ? getRandomCorrectPhrase() : getRandomIncorrectPhrase();
}
