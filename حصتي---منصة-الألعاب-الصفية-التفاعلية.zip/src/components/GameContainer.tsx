import React, { useRef } from 'react';
import { Activity, GameType } from '../types';
import { GAME_TYPE_METADATA } from '../data/initialData';
import { sound } from '../services/soundService';
import { toggleFullScreenElement } from '../utils/confetti';
import {
  ArrowRight,
  Maximize,
  RotateCcw,
  Volume2,
  VolumeX,
  Edit3,
  Sparkles,
} from 'lucide-react';

// Game components
import { TeamRaceGame } from './games/TeamRaceGame';
import { MysteryBoxGame } from './games/MysteryBoxGame';
import { WheelOfNamesGame } from './games/WheelOfNamesGame';
import { MultipleChoiceGame } from './games/MultipleChoiceGame';
import { FlipCardGame } from './games/FlipCardGame';
import { MatchingGame } from './games/MatchingGame';
import { TimeAttackGame } from './games/TimeAttackGame';
import { ClassPointsGame } from './games/ClassPointsGame';
import { ExitTicketGame } from './games/ExitTicketGame';

interface GameContainerProps {
  activity: Activity;
  onBack: () => void;
  onEditActivity: (activity: Activity) => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const GameContainer: React.FC<GameContainerProps> = ({
  activity,
  onBack,
  onEditActivity,
  isMuted,
  onToggleMute,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [restartKey, setRestartKey] = React.useState(0);

  const gameMeta = GAME_TYPE_METADATA[activity.gameType] || {
    name: 'نشاط تفاعلي',
    tagline: 'تجربة تعليمية ذكية',
    color: 'from-indigo-600 to-purple-600',
    badge: 'نشاط صفي',
    emoji: '🎮',
  };

  const handleRestart = () => {
    sound.playClick();
    setRestartKey((prev) => prev + 1);
  };

  const renderGame = () => {
    switch (activity.gameType) {
      case 'team-race':
        return (
          <TeamRaceGame
            key={restartKey}
            questions={activity.questions}
            config={activity.config}
            onRestart={handleRestart}
          />
        );
      case 'mystery-box':
        return (
          <MysteryBoxGame
            key={restartKey}
            questions={activity.questions}
            onRestart={handleRestart}
            onBackToLibrary={onBack}
          />
        );
      case 'wheel-of-names':
        return (
          <WheelOfNamesGame
            key={restartKey}
            questions={activity.questions}
            config={activity.config}
            onRestart={handleRestart}
          />
        );
      case 'multiple-choice':
        return (
          <MultipleChoiceGame
            key={restartKey}
            questions={activity.questions}
            onRestart={handleRestart}
          />
        );
      case 'flip-card':
        return (
          <FlipCardGame
            key={restartKey}
            questions={activity.questions}
            onRestart={handleRestart}
          />
        );
      case 'matching':
        return (
          <MatchingGame
            key={restartKey}
            questions={activity.questions}
            onRestart={handleRestart}
          />
        );
      case 'time-attack':
        return (
          <TimeAttackGame
            key={restartKey}
            questions={activity.questions}
            onRestart={handleRestart}
          />
        );
      case 'class-points':
        return <ClassPointsGame key={restartKey} />;
      case 'exit-ticket':
        return (
          <ExitTicketGame
            key={restartKey}
            questions={activity.questions}
            onRestart={handleRestart}
          />
        );
      default:
        return <div>نوع اللعبة غير متوفر</div>;
    }
  };

  return (
    <div
      ref={containerRef}
      className="min-h-screen bg-slate-900/95 text-slate-100 flex flex-col transition-all relative overflow-x-hidden"
      style={{
        backgroundImage: 'radial-gradient(at 50% 0%, rgba(99, 102, 241, 0.25) 0px, transparent 65%), radial-gradient(at 0% 100%, rgba(168, 85, 247, 0.2) 0px, transparent 50%)',
      }}
    >
      {/* Smartboard Projector Control Bar */}
      <div className="bg-slate-900/80 backdrop-blur-md border-b border-white/10 px-4 sm:px-6 py-3.5 sticky top-0 z-30 shadow-lg flex items-center justify-between">
        
        {/* Left: Back & Title */}
        <div className="flex items-center gap-3.5">
          <button
            onClick={() => {
              sound.playClick();
              onBack();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-black text-white bg-white/10 hover:bg-white/20 rounded-xl transition-all cursor-pointer border border-white/10 tactile-btn"
          >
            <ArrowRight className="w-4 h-4" />
            <span>خروج</span>
          </button>

          <div className="flex items-center gap-2.5">
            <span className="text-2xl p-1 rounded-xl bg-white/10">{gameMeta.emoji}</span>
            <div className="flex flex-col">
              <h2 className="text-base sm:text-lg font-black text-white truncate max-w-xs sm:max-w-md drop-shadow-xs">
                {activity.title}
              </h2>
              <span className="text-[11px] font-bold text-indigo-300">
                {gameMeta.name} · شاشة العرض الصفية
              </span>
            </div>
          </div>
        </div>

        {/* Right: Classroom utilities */}
        <div className="flex items-center gap-2">
          {/* Quick Edit */}
          <button
            onClick={() => {
              sound.playClick();
              onEditActivity(activity);
            }}
            className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 px-3.5 py-2 rounded-xl border border-white/10 transition-colors cursor-pointer tactile-btn"
          >
            <Edit3 className="w-3.5 h-3.5 text-amber-300" />
            <span>تعديل الأسئلة</span>
          </button>

          {/* Restart */}
          <button
            onClick={handleRestart}
            title="إعادة بدء اللعبة"
            className="p-2.5 text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-xl border border-white/10 transition-colors cursor-pointer tactile-btn"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleMute}
            title={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
            className={`p-2.5 rounded-xl border transition-colors cursor-pointer tactile-btn ${
              isMuted
                ? 'bg-rose-500/20 border-rose-500/30 text-rose-400'
                : 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300'
            }`}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Fullscreen for Smartboard / Projector */}
          <button
            onClick={() => {
              sound.playClick();
              toggleFullScreenElement(containerRef.current);
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-xs font-black rounded-xl shadow-md shadow-indigo-500/30 cursor-pointer transition-all tactile-btn"
          >
            <Maximize className="w-4 h-4" />
            <span className="hidden sm:inline">شاشة كاملة للبروجكتر</span>
          </button>
        </div>

      </div>

      {/* Main Game Stage */}
      <div className="flex-1 p-3 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto flex flex-col justify-center animate-fade-in">
        {renderGame()}
      </div>

    </div>
  );
};
