import React from 'react';
import { Check, Lightbulb, ArrowLeft, Sparkles } from 'lucide-react';

interface AnswerFeedbackBannerProps {
  isCorrect: boolean;
  phrase: string;
  correctAnswerText?: string | number;
  explanation?: string;
  onNext?: () => void;
  nextButtonLabel?: string;
}

export const AnswerFeedbackBanner: React.FC<AnswerFeedbackBannerProps> = ({
  isCorrect,
  phrase,
  correctAnswerText,
  explanation,
  onNext,
  nextButtonLabel = 'السؤال التالي',
}) => {
  return (
    <div
      className={`rounded-2xl p-4 sm:p-5 border-2 shadow-md transition-all flex flex-col sm:flex-row items-center justify-between gap-4 animate-pop-in ${
        isCorrect
          ? 'bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border-emerald-300 text-emerald-950'
          : 'bg-gradient-to-r from-rose-50 via-amber-50 to-rose-50 border-rose-300 text-rose-950 animate-shake'
      }`}
    >
      {/* Feedback Text & Details */}
      <div className="flex items-center gap-3.5 text-right w-full sm:w-auto">
        <div
          className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 text-xl shadow-sm ${
            isCorrect
              ? 'bg-emerald-500 text-white shadow-emerald-500/20 ring-4 ring-emerald-200/60'
              : 'bg-rose-500 text-white shadow-rose-500/20 ring-4 ring-rose-200/60'
          }`}
        >
          {isCorrect ? <Check className="w-6 h-6 stroke-[3]" /> : <Lightbulb className="w-6 h-6 stroke-[2.5]" />}
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-base sm:text-lg font-black tracking-tight">
              {phrase}
            </span>
            {isCorrect && <Sparkles className="w-4 h-4 text-emerald-600 animate-spin" style={{ animationDuration: '4s' }} />}
          </div>

          {!isCorrect && correctAnswerText !== undefined && (
            <span className="text-xs sm:text-sm font-bold text-slate-700 mt-0.5">
              الإجابة الصحيحة هي: <strong className="text-emerald-700 font-black">{correctAnswerText}</strong>
            </span>
          )}

          {explanation && (
            <span className="text-xs text-slate-600 font-medium mt-0.5 max-w-xl">
              {explanation}
            </span>
          )}
        </div>
      </div>

      {/* Next Question CTA Button */}
      {onNext && (
        <button
          onClick={onNext}
          className={`w-full sm:w-auto px-6 py-3 rounded-xl font-black text-sm text-white shadow-md cursor-pointer transition-all flex items-center justify-center gap-2 whitespace-nowrap tactile-btn shrink-0 ${
            isCorrect
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-emerald-600/20'
              : 'bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 shadow-indigo-600/20'
          }`}
        >
          <span>{nextButtonLabel}</span>
          <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
        </button>
      )}
    </div>
  );
};
