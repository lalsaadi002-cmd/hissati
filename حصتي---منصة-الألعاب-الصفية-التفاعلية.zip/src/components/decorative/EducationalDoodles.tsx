import React from 'react';

// Ambient floating background doodles
export const BackgroundDoodles: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
      {/* Floating Rocket Top Right */}
      <div className="absolute top-10 left-12 text-sky-500/35 animate-float hidden md:block" style={{ animationDuration: '6s' }}>
        <svg className="w-16 h-16 transform -rotate-45" viewBox="0 0 24 24" fill="currentColor">
          <path d="M13.13 22.19L11.5 18.36C13.07 17.78 14.54 16.9 15.82 15.82L19.65 17.45C19.8 17.5 19.95 17.5 20.09 17.43C20.35 17.3 20.46 17 20.35 16.74L18.72 12.91C19.8 11.63 20.68 10.16 21.26 8.59L22.19 13.13C22.25 13.41 22.11 13.69 21.86 13.82L17.32 16.14C17.06 16.27 16.92 16.55 16.98 16.83L17.91 21.37C17.97 21.65 17.78 21.92 17.5 21.98C17.42 22 17.34 22 17.26 21.98L13.13 22.19Z" opacity="0.6" />
          <path d="M12 2C8 2 4.5 5 4.5 9.5C4.5 12.5 6 15 8 16.5L8.5 20.5L12 18.5L15.5 20.5L16 16.5C18 15 19.5 12.5 19.5 9.5C19.5 5 16 2 12 2ZM12 11C10.9 11 10 10.1 10 9C10 7.9 10.9 7 12 7C13.1 7 14 7.9 14 9C14 10.1 13.1 11 12 11Z" />
        </svg>
      </div>

      {/* Floating Saturn Planet Top Left */}
      <div className="absolute top-24 right-10 text-purple-500/30 animate-float hidden lg:block" style={{ animationDuration: '8s', animationDelay: '1s' }}>
        <svg className="w-20 h-20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <circle cx="12" cy="12" r="6" fill="currentColor" fillOpacity="0.35" />
          <ellipse cx="12" cy="12" rx="11" ry="3.5" transform="rotate(-25 12 12)" stroke="currentColor" strokeWidth="2" />
        </svg>
      </div>

      {/* Floating Lightbulb Mid Left */}
      <div className="absolute top-[42%] left-8 text-amber-500/40 animate-float hidden md:block" style={{ animationDuration: '7s', animationDelay: '2s' }}>
        <svg className="w-14 h-14" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2C8.13 2 5 5.13 5 9C5 11.38 6.19 13.47 8 14.74V17C8 17.55 8.45 18 9 18H15C15.55 18 16 17.55 16 17V14.74C17.81 13.47 19 11.38 19 9C19 5.13 15.87 2 12 2ZM9 21C9 21.55 9.45 22 10 22H14C14.55 22 15 21.55 15 21V20H9V21Z" opacity="0.8" />
        </svg>
      </div>

      {/* Floating Atom Orbit Mid Right */}
      <div className="absolute top-[52%] right-8 text-teal-500/35 animate-float hidden md:block" style={{ animationDuration: '8.5s', animationDelay: '1.2s' }}>
        <svg className="w-16 h-16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="12" cy="12" r="2.5" fill="currentColor" />
          <ellipse cx="12" cy="12" rx="9" ry="3.5" stroke="currentColor" />
          <ellipse cx="12" cy="12" rx="9" ry="3.5" stroke="currentColor" transform="rotate(60 12 12)" />
          <ellipse cx="12" cy="12" rx="9" ry="3.5" stroke="currentColor" transform="rotate(120 12 12)" />
        </svg>
      </div>

      {/* Sparkling Twinkle Stars scattered */}
      <div className="absolute top-1/5 right-1/4 text-amber-500/50 animate-pulse text-2xl select-none">✨</div>
      <div className="absolute top-1/3 left-1/3 text-pink-500/45 animate-pulse text-xl select-none" style={{ animationDelay: '1.5s' }}>⭐</div>
      <div className="absolute top-2/3 right-1/5 text-cyan-600/45 animate-pulse text-2xl select-none" style={{ animationDelay: '2.5s' }}>🌟</div>
      <div className="absolute bottom-1/4 left-1/4 text-purple-600/50 animate-pulse text-xl select-none" style={{ animationDelay: '0.8s' }}>✨</div>

      {/* Floating Open Book Bottom Right */}
      <div className="absolute bottom-20 right-12 text-teal-600/35 animate-float hidden lg:block" style={{ animationDuration: '9s' }}>
        <svg className="w-16 h-16" viewBox="0 0 24 24" fill="currentColor">
          <path d="M21 5C19.89 4.65 18.67 4.5 17.5 4.5C15.55 4.5 13.45 4.9 12 6C10.55 4.9 8.45 4.5 6.5 4.5C4.55 4.5 2.45 4.9 1 6V20.65C1 20.9 1.25 21.15 1.5 21.15C1.6 21.15 1.65 21.1 1.75 21.1C3.1 20.45 5.05 20 6.5 20C8.45 20 10.55 20.4 12 21.5C13.35 20.65 15.8 20 17.5 20C19.15 20 20.85 20.3 22.25 21.05C22.35 21.1 22.4 21.1 22.5 21.1C22.75 21.1 23 20.85 23 20.6V6C22.4 5.55 21.75 5.25 21 5ZM21 18.5C19.9 18.15 18.7 18 17.5 18C15.8 18 13.35 18.65 12 19.5V8C13.35 7.15 15.8 6.5 17.5 6.5C18.7 6.5 19.9 6.65 21 7V18.5Z" />
        </svg>
      </div>

      {/* Pencil Bottom Left */}
      <div className="absolute bottom-28 left-12 text-rose-500/30 animate-float hidden md:block" style={{ animationDuration: '7.5s', animationDelay: '3s' }}>
        <svg className="w-14 h-14 transform rotate-12" viewBox="0 0 24 24" fill="currentColor">
          <path d="M3 17.25V21H6.75L17.81 9.94L14.06 6.19L3 17.25ZM20.71 7.04C21.1 6.65 21.1 6.02 20.71 5.63L18.37 3.29C17.98 2.9 17.35 2.9 16.96 3.29L15.13 5.12L18.88 8.87L20.71 7.04Z" />
        </svg>
      </div>
    </div>
  );
};

// Rich Thematic Illustration Banners for each Game
export const GameIllustrations: Record<string, React.FC<{ className?: string }>> = {
  // 1. Team Race: Turbo racing track with twin futuristic cars
  'team-race': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        {/* Track Curves */}
        <path d="M-20 90 C 80 40, 240 100, 340 50" stroke="#3b82f6" strokeWidth="18" strokeLinecap="round" opacity="0.35" />
        <path d="M-20 90 C 80 40, 240 100, 340 50" stroke="#60a5fa" strokeWidth="3" strokeDasharray="8 8" />
        
        {/* Blue Racer Car */}
        <g transform="translate(190, 48)">
          <ellipse cx="25" cy="18" rx="28" ry="12" fill="#2563eb" />
          <ellipse cx="28" cy="14" rx="16" ry="7" fill="#60a5fa" />
          <circle cx="10" cy="24" r="5" fill="#1e293b" />
          <circle cx="40" cy="24" r="5" fill="#1e293b" />
          {/* Turbo flame */}
          <path d="M-4 18 Q -16 14, -8 18 Q -16 22, -4 18" fill="#f59e0b" />
          <text x="25" y="19" fill="white" fontSize="10" fontWeight="900" textAnchor="middle">1</text>
        </g>

        {/* Green/Cyan Racer Car */}
        <g transform="translate(60, 68)">
          <ellipse cx="25" cy="18" rx="28" ry="12" fill="#059669" />
          <ellipse cx="28" cy="14" rx="16" ry="7" fill="#34d399" />
          <circle cx="10" cy="24" r="5" fill="#1e293b" />
          <circle cx="40" cy="24" r="5" fill="#1e293b" />
          {/* Turbo flame */}
          <path d="M-4 18 Q -16 14, -8 18 Q -16 22, -4 18" fill="#ef4444" />
          <text x="25" y="19" fill="white" fontSize="10" fontWeight="900" textAnchor="middle">2</text>
        </g>

        {/* Checkered Flag */}
        <g transform="translate(270, 20)">
          <rect x="0" y="0" width="3" height="42" fill="#cbd5e1" />
          <rect x="3" y="2" width="24" height="18" fill="#ffffff" rx="2" />
          <rect x="3" y="2" width="6" height="6" fill="#1e293b" />
          <rect x="15" y="2" width="6" height="6" fill="#1e293b" />
          <rect x="9" y="8" width="6" height="6" fill="#1e293b" />
          <rect x="21" y="8" width="6" height="6" fill="#1e293b" />
          <rect x="3" y="14" width="6" height="6" fill="#1e293b" />
          <rect x="15" y="14" width="6" height="6" fill="#1e293b" />
        </g>
      </svg>
    </div>
  ),

  // 2. Mystery Box: Golden glowing treasure box bursting with star magic
  'mystery-box': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        {/* Glow halo */}
        <circle cx="160" cy="65" r="48" fill="#f59e0b" fillOpacity="0.25" />
        
        {/* Magical floating stars & Question marks */}
        <text x="105" y="45" fill="#fbbf24" fontSize="20" fontWeight="bold">✨</text>
        <text x="210" y="40" fill="#fde047" fontSize="22" fontWeight="bold">⭐</text>
        <text x="135" y="28" fill="#ffffff" fontSize="24" fontWeight="900">?</text>
        <text x="180" y="32" fill="#ffffff" fontSize="18" fontWeight="900">?</text>

        {/* 3D Chest base */}
        <g transform="translate(125, 48)">
          {/* Box Bottom */}
          <rect x="0" y="22" width="70" height="44" rx="8" fill="#d97706" />
          <rect x="4" y="25" width="62" height="38" rx="6" fill="#f59e0b" />
          {/* Vertical gold band */}
          <rect x="28" y="22" width="14" height="44" fill="#fbbf24" />
          <circle cx="35" cy="40" r="6" fill="#78350f" />
          <circle cx="35" cy="40" r="3" fill="#fef08a" />
          {/* Open Lid angled */}
          <path d="M -5 18 L 75 18 L 68 0 L 2 0 Z" fill="#b45309" />
          <path d="M -2 16 L 72 16 L 66 3 L 4 3 Z" fill="#d97706" />
          <rect x="28" y="0" width="14" height="18" fill="#fde047" />
        </g>
      </svg>
    </div>
  ),

  // 3. Wheel of Names: Colorful spinning carnival wheel
  'wheel-of-names': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        {/* Glow */}
        <circle cx="160" cy="65" r="50" fill="#ec4899" fillOpacity="0.2" />

        {/* Confetti specs */}
        <circle cx="95" cy="35" r="4" fill="#38bdf8" />
        <circle cx="230" cy="45" r="3.5" fill="#fbbf24" />
        <rect x="110" y="80" width="6" height="6" fill="#ec4899" transform="rotate(25 110 80)" />
        <rect x="215" y="75" width="7" height="4" fill="#10b981" transform="rotate(-15 215 75)" />

        {/* Wheel circle */}
        <g transform="translate(160, 65)">
          <circle cx="0" cy="0" r="42" fill="#ffffff" stroke="#f43f5e" strokeWidth="4" />
          
          {/* Segments */}
          <path d="M0 0 L 0 -40 A 40 40 0 0 1 35 -20 Z" fill="#f43f5e" />
          <path d="M0 0 L 35 -20 A 40 40 0 0 1 38 15 Z" fill="#ec4899" />
          <path d="M0 0 L 38 15 A 40 40 0 0 1 0 40 Z" fill="#8b5cf6" />
          <path d="M0 0 L 0 40 A 40 40 0 0 1 -35 20 Z" fill="#3b82f6" />
          <path d="M0 0 L -35 20 A 40 40 0 0 1 -38 -15 Z" fill="#10b981" />
          <path d="M0 0 L -38 -15 A 40 40 0 0 1 0 -40 Z" fill="#f59e0b" />

          {/* Wheel hub */}
          <circle cx="0" cy="0" r="14" fill="#1e293b" stroke="#ffffff" strokeWidth="3" />
          <circle cx="0" cy="0" r="4" fill="#ffffff" />

          {/* Needle at Top */}
          <polygon points="0,-48 -7,-36 7,-36" fill="#be123c" />
        </g>
      </svg>
    </div>
  ),

  // 4. Multiple Choice: Game show stage with 4 glowing choice podiums
  'multiple-choice': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        {/* Stage lights cones */}
        <polygon points="160,-10 60,120 260,120" fill="#10b981" fillOpacity="0.12" />
        
        {/* Center Target & Checkmark */}
        <g transform="translate(160, 48)">
          <circle cx="0" cy="0" r="28" fill="#047857" />
          <circle cx="0" cy="0" r="22" fill="#10b981" />
          <path d="M -9 0 L -3 6 L 10 -7" stroke="#ffffff" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
        </g>

        {/* 4 Interactive option tags */}
        <g transform="translate(65, 30)">
          <rect width="40" height="24" rx="8" fill="#059669" />
          <text x="20" y="16" fill="white" fontSize="11" fontWeight="bold" textAnchor="middle">أ</text>
        </g>
        <g transform="translate(65, 64)">
          <rect width="40" height="24" rx="8" fill="#0f766e" />
          <text x="20" y="16" fill="white" fontSize="11" fontWeight="bold" textAnchor="middle">ب</text>
        </g>
        <g transform="translate(215, 30)">
          <rect width="40" height="24" rx="8" fill="#059669" />
          <text x="20" y="16" fill="white" fontSize="11" fontWeight="bold" textAnchor="middle">ج</text>
        </g>
        <g transform="translate(215, 64)">
          <rect width="40" height="24" rx="8" fill="#0f766e" />
          <text x="20" y="16" fill="white" fontSize="11" fontWeight="bold" textAnchor="middle">د</text>
        </g>
      </svg>
    </div>
  ),

  // 5. Flip Card: 3D holographic playing cards in mid-flip
  'flip-card': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        <circle cx="160" cy="60" r="50" fill="#7c3aed" fillOpacity="0.2" />

        {/* Left card */}
        <g transform="translate(95, 30) rotate(-14)">
          <rect width="45" height="60" rx="8" fill="#581c87" />
          <rect x="2" y="2" width="41" height="56" rx="6" fill="#7c3aed" />
          <circle cx="22" cy="30" r="10" fill="#a855f7" />
          <text x="22" y="34" fill="white" fontSize="12" fontWeight="bold" textAnchor="middle">1</text>
        </g>

        {/* Center flipping card (perspective skewed) */}
        <g transform="translate(142, 22) skewY(-8)">
          <rect width="46" height="62" rx="8" fill="#4c1d95" />
          <rect x="2" y="2" width="42" height="58" rx="6" fill="#8b5cf6" />
          <path d="M 12 31 Q 23 20, 34 31 Q 23 42, 12 31" fill="#fde047" />
          <text x="23" y="36" fill="#4c1d95" fontSize="14" fontWeight="bold" textAnchor="middle">★</text>
        </g>

        {/* Right card */}
        <g transform="translate(185, 34) rotate(12)">
          <rect width="45" height="60" rx="8" fill="#581c87" />
          <rect x="2" y="2" width="41" height="56" rx="6" fill="#6d28d9" />
          <circle cx="22" cy="30" r="10" fill="#a855f7" />
          <text x="22" y="34" fill="white" fontSize="12" fontWeight="bold" textAnchor="middle">2</text>
        </g>
      </svg>
    </div>
  ),

  // 6. Matching Game: Interlocking puzzle pieces and connective spark
  'matching': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        {/* Glow */}
        <circle cx="160" cy="60" r="45" fill="#0284c7" fillOpacity="0.2" />

        {/* Left Node card */}
        <g transform="translate(90, 40)">
          <rect width="56" height="42" rx="10" fill="#0369a1" />
          <rect x="2" y="2" width="52" height="38" rx="8" fill="#0284c7" />
          <circle cx="28" cy="21" r="9" fill="#38bdf8" />
          <text x="28" y="25" fill="white" fontSize="11" fontWeight="bold" textAnchor="middle">A</text>
        </g>

        {/* Connecting lightning/laser spark */}
        <path d="M 148 61 Q 160 48, 172 61" stroke="#38bdf8" strokeWidth="5" strokeLinecap="round" />
        <circle cx="160" cy="55" r="5" fill="#ffffff" />
        <text x="160" y="40" fill="#38bdf8" fontSize="12" textAnchor="middle">⚡</text>

        {/* Right Matched Node card */}
        <g transform="translate(174, 40)">
          <rect width="56" height="42" rx="10" fill="#0284c7" />
          <rect x="2" y="2" width="52" height="38" rx="8" fill="#38bdf8" />
          <circle cx="28" cy="21" r="9" fill="#0284c7" />
          <text x="28" y="25" fill="white" fontSize="11" fontWeight="bold" textAnchor="middle">B</text>
        </g>
      </svg>
    </div>
  ),

  // 7. Time Attack: Turbo stopwatch with lightning speed trails
  'time-attack': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        <circle cx="160" cy="65" r="48" fill="#ef4444" fillOpacity="0.25" />

        {/* Speed motion lines */}
        <line x1="70" y1="45" x2="105" y2="45" stroke="#f87171" strokeWidth="3" strokeLinecap="round" />
        <line x1="60" y1="65" x2="100" y2="65" stroke="#f87171" strokeWidth="4" strokeLinecap="round" />
        <line x1="75" y1="85" x2="110" y2="85" stroke="#f87171" strokeWidth="3" strokeLinecap="round" />

        {/* Stopwatch */}
        <g transform="translate(160, 65)">
          {/* Top Button */}
          <rect x="-6" y="-48" width="12" height="8" rx="2" fill="#991b1b" />
          <circle cx="0" cy="0" r="38" fill="#b91c1c" />
          <circle cx="0" cy="0" r="32" fill="#ef4444" />
          <circle cx="0" cy="0" r="28" fill="#ffffff" />
          
          {/* Clock Ticks */}
          <line x1="0" y1="-24" x2="0" y2="-20" stroke="#1e293b" strokeWidth="2" />
          <line x1="24" y1="0" x2="20" y2="0" stroke="#1e293b" strokeWidth="2" />
          <line x1="0" y1="24" x2="0" y2="20" stroke="#1e293b" strokeWidth="2" />
          <line x1="-24" y1="0" x2="-20" y2="0" stroke="#1e293b" strokeWidth="2" />

          {/* Clock hands pointing fast */}
          <line x1="0" y1="0" x2="12" y2="-12" stroke="#dc2626" strokeWidth="3" strokeLinecap="round" />
          <circle cx="0" cy="0" r="4" fill="#991b1b" />
        </g>

        {/* Fire sparks */}
        <text x="215" y="55" fill="#f59e0b" fontSize="20">🔥</text>
        <text x="210" y="85" fill="#f97316" fontSize="16">⚡</text>
      </svg>
    </div>
  ),

  // 8. Class Points: Golden trophy, stars constellation, and medal ribbons
  'class-points': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        <circle cx="160" cy="62" r="50" fill="#f59e0b" fillOpacity="0.25" />

        {/* Orbiting stars */}
        <text x="95" y="45" fill="#f59e0b" fontSize="18">⭐</text>
        <text x="220" y="45" fill="#f59e0b" fontSize="18">⭐</text>
        <text x="110" y="85" fill="#fbbf24" fontSize="16">🌟</text>
        <text x="205" y="85" fill="#fbbf24" fontSize="16">🌟</text>

        {/* Golden Trophy Cup */}
        <g transform="translate(136, 28)">
          {/* Handles */}
          <path d="M 4 20 C -12 20, -12 40, 6 42" stroke="#d97706" strokeWidth="5" fill="none" />
          <path d="M 44 20 C 60 20, 60 40, 42 42" stroke="#d97706" strokeWidth="5" fill="none" />
          {/* Cup Bowl */}
          <path d="M 4 12 L 44 12 C 44 38, 36 50, 24 52 C 12 50, 4 38, 4 12 Z" fill="#f59e0b" />
          <path d="M 8 16 L 40 16 C 40 36, 33 46, 24 48 C 15 46, 8 36, 8 16 Z" fill="#fbbf24" />
          {/* Star on Trophy */}
          <text x="24" y="36" fill="#b45309" fontSize="15" textAnchor="middle">★</text>
          {/* Stem & Base */}
          <rect x="20" y="52" width="8" height="10" fill="#d97706" />
          <rect x="10" y="62" width="28" height="8" rx="2" fill="#78350f" />
        </g>
      </svg>
    </div>
  ),

  // 9. Exit Ticket: Stamped departure pass with pencil, checkmark, and sparkles
  'exit-ticket': ({ className = 'w-full h-32' }) => (
    <div className={`relative overflow-hidden flex items-center justify-center ${className}`}>
      <svg className="w-full h-full" viewBox="0 0 320 120" fill="none" preserveAspectRatio="xMidYMid slice">
        <circle cx="160" cy="60" r="48" fill="#0d9488" fillOpacity="0.2" />

        {/* Golden celebratory stars */}
        <text x="90" y="50" fill="#f59e0b" fontSize="18">🎓</text>
        <text x="220" y="70" fill="#14b8a6" fontSize="18">✨</text>

        {/* Ticket Body */}
        <g transform="translate(115, 35)">
          <rect width="90" height="52" rx="8" fill="#0f766e" />
          <rect x="2" y="2" width="86" height="48" rx="6" fill="#14b8a6" />
          {/* Notches */}
          <circle cx="0" cy="26" r="6" fill="#134e4a" />
          <circle cx="90" cy="26" r="6" fill="#134e4a" />
          <line x1="28" y1="6" x2="28" y2="46" stroke="#0f766e" strokeWidth="2" strokeDasharray="3 3" />
          
          {/* Stamp */}
          <circle cx="58" cy="26" r="14" fill="#0f766e" />
          <path d="M 52 26 L 56 30 L 65 21" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  ),
};

// Grand Hero Educational Illustration (Rocket + Books + Graduation cap + Stars)
export const HeroEducationalIllustration: React.FC = () => {
  return (
    <div className="relative w-full max-w-sm sm:max-w-md mx-auto aspect-4/3 flex items-center justify-center">
      {/* Radiant Glow in background */}
      <div className="absolute inset-0 bg-gradient-to-tr from-amber-400/25 via-indigo-500/25 to-pink-500/25 rounded-full blur-3xl" />

      <svg className="w-full h-full drop-shadow-2xl" viewBox="0 0 400 320" fill="none">
        
        {/* Orbital Atom Ring */}
        <ellipse cx="200" cy="180" rx="140" ry="45" stroke="#818cf8" strokeWidth="2" strokeDasharray="6 6" transform="rotate(-18 200 180)" opacity="0.6" />
        <circle cx="80" cy="145" r="7" fill="#fbbf24" />
        <circle cx="315" cy="210" r="6" fill="#38bdf8" />

        {/* Cloud / Platform below book */}
        <ellipse cx="200" cy="275" rx="120" ry="25" fill="#1e1b4b" fillOpacity="0.4" />
        <path d="M 120 270 Q 200 290, 280 270 Q 250 250, 150 250 Z" fill="#312e81" opacity="0.5" />

        {/* Big Open Book */}
        <g transform="translate(100, 210)">
          {/* Left Book Page */}
          <path d="M 100 35 C 50 35, 15 25, 0 20 L 0 55 C 15 60, 50 70, 100 70 Z" fill="#e0e7ff" />
          <path d="M 100 30 C 50 30, 15 20, 5 16 L 5 50 C 15 54, 50 64, 100 64 Z" fill="#ffffff" />
          {/* Right Book Page */}
          <path d="M 100 35 C 150 35, 185 25, 200 20 L 200 55 C 185 60, 150 70, 100 70 Z" fill="#c7d2fe" />
          <path d="M 100 30 C 150 30, 185 20, 195 16 L 195 50 C 185 54, 150 64, 100 64 Z" fill="#f8fafc" />
          {/* Text lines on book */}
          <line x1="25" y1="28" x2="80" y2="35" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />
          <line x1="25" y1="36" x2="70" y2="43" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />
          <line x1="120" y1="35" x2="175" y2="28" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />
          <line x1="125" y1="43" x2="170" y2="36" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />
        </g>

        {/* Rocket blasting off from center */}
        <g transform="translate(165, 50)">
          {/* Exhaust Flame */}
          <path d="M 25 155 Q 35 210, 35 210 Q 45 155, 45 155 Z" fill="#ef4444" />
          <path d="M 28 155 Q 35 190, 35 190 Q 42 155, 42 155 Z" fill="#f59e0b" />
          <path d="M 31 155 Q 35 175, 35 175 Q 39 155, 39 155 Z" fill="#fde047" />

          {/* Rocket Wings */}
          <path d="M 12 110 L 0 145 L 24 135 Z" fill="#be185d" />
          <path d="M 58 110 L 70 145 L 46 135 Z" fill="#be185d" />

          {/* Rocket Body */}
          <path d="M 35 10 C 18 45, 18 120, 22 145 L 48 145 C 52 120, 52 45, 35 10 Z" fill="#f8fafc" />
          <path d="M 35 10 C 26 30, 25 55, 25 70 L 45 70 C 45 55, 44 30, 35 10 Z" fill="#f43f5e" />

          {/* Porthole Window */}
          <circle cx="35" cy="95" r="12" fill="#3b82f6" stroke="#cbd5e1" strokeWidth="3" />
          <circle cx="35" cy="95" r="8" fill="#60a5fa" />
          <circle cx="38" cy="92" r="3" fill="#ffffff" />
        </g>

        {/* Floating Lightbulb */}
        <g transform="translate(60, 80)">
          <circle cx="15" cy="15" r="14" fill="#fbbf24" />
          <rect x="10" y="27" width="10" height="5" rx="1" fill="#78350f" />
          <text x="15" y="20" fill="#78350f" fontSize="16" fontWeight="bold" textAnchor="middle">💡</text>
        </g>

        {/* Floating Graduation Cap Top Right */}
        <g transform="translate(280, 75)">
          <polygon points="25,5 45,15 25,25 5,15" fill="#1e1b4b" />
          <polygon points="25,5 45,15 25,25 5,15" stroke="#f59e0b" strokeWidth="1.5" fill="none" />
          <rect x="16" y="20" width="18" height="10" rx="3" fill="#312e81" />
          <line x1="45" y1="15" x2="48" y2="28" stroke="#f59e0b" strokeWidth="2" />
          <circle cx="48" cy="28" r="2.5" fill="#f59e0b" />
        </g>

        {/* Sparkles around */}
        <text x="135" y="65" fill="#fde047" fontSize="20">✨</text>
        <text x="245" y="145" fill="#f43f5e" fontSize="22">⭐</text>
        <text x="110" y="160" fill="#38bdf8" fontSize="24">✦</text>

      </svg>
    </div>
  );
};
