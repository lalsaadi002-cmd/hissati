import React, { useState, useEffect } from 'react';
import { Activity, GameType, Question, QuestionSet } from '../types';
import { GAME_TYPE_METADATA } from '../data/initialData';
import { sound } from '../services/soundService';
import { storage } from '../services/storageService';
import {
  Sparkles,
  Plus,
  Trash2,
  Database,
  Check,
  Play,
  RotateCcw,
  BookOpen,
  ArrowRight,
  Settings,
} from 'lucide-react';

interface ActivityEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activityToEdit?: Activity | null;
  preSelectedGameType?: GameType;
  preSelectedQuestionSet?: QuestionSet | null;
  onSave: (activity: Activity, launchImmediately?: boolean) => void;
  onRequestCreateQuestionSet?: () => void;
}

export const ActivityEditorModal: React.FC<ActivityEditorModalProps> = ({
  isOpen,
  onClose,
  activityToEdit,
  preSelectedGameType,
  preSelectedQuestionSet,
  onSave,
  onRequestCreateQuestionSet,
}) => {
  const [questionSets, setQuestionSets] = useState<QuestionSet[]>(() => storage.getQuestionSets());
  
  const [title, setTitle] = useState('');
  const [gameType, setGameType] = useState<GameType>('team-race');
  const [selectedSetId, setSelectedSetId] = useState<string>('');
  const [questions, setQuestions] = useState<Question[]>([]);

  // Specific game configs
  const [team1Name, setTeam1Name] = useState('صقور المعرفة');
  const [team2Name, setTeam2Name] = useState('فرسان التحدي');
  const [boxCount, setBoxCount] = useState<number>(8);
  const [timePerQuestion, setTimePerQuestion] = useState<number>(15);
  const [enable5050, setEnable5050] = useState<boolean>(true);
  const [pointsMode, setPointsMode] = useState<'teams' | 'students'>('teams');

  // Manual new question form toggle
  const [showAddQuestion, setShowAddQuestion] = useState(false);
  const [newQText, setNewQText] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [opt4, setOpt4] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('');
  const [explanation, setExplanation] = useState('');

  // Flag to know if game was preselected from library
  const isDirectGameFlow = Boolean(preSelectedGameType || activityToEdit);

  useEffect(() => {
    if (!isOpen) return;

    const availableSets = storage.getQuestionSets();
    setQuestionSets(availableSets);

    if (activityToEdit) {
      setTitle(activityToEdit.title);
      setGameType(activityToEdit.gameType);
      setSelectedSetId(activityToEdit.questionSetId || '');
      setQuestions([...activityToEdit.questions]);
      if (activityToEdit.config?.team1Name) setTeam1Name(activityToEdit.config.team1Name);
      if (activityToEdit.config?.team2Name) setTeam2Name(activityToEdit.config.team2Name);
      if (activityToEdit.config?.boxCount) setBoxCount(activityToEdit.config.boxCount);
      if (activityToEdit.config?.timePerQuestion) setTimePerQuestion(activityToEdit.config.timePerQuestion);
      if (activityToEdit.config?.enable5050 !== undefined) setEnable5050(activityToEdit.config.enable5050);
      if (activityToEdit.config?.pointsMode) setPointsMode(activityToEdit.config.pointsMode);
    } else {
      const activeType = preSelectedGameType || 'team-race';
      setGameType(activeType);

      if (preSelectedQuestionSet) {
        setTitle(`${GAME_TYPE_METADATA[activeType].name} - ${preSelectedQuestionSet.title}`);
        setSelectedSetId(preSelectedQuestionSet.id);
        setQuestions([...preSelectedQuestionSet.questions]);
      } else if (availableSets.length > 0) {
        const first = availableSets[0];
        setTitle(`${GAME_TYPE_METADATA[activeType].name} - ${first.title}`);
        setSelectedSetId(first.id);
        setQuestions([...first.questions]);
      } else {
        setTitle(`نشاط ${GAME_TYPE_METADATA[activeType].name}`);
        setSelectedSetId('');
        setQuestions([]);
      }
    }
  }, [isOpen, activityToEdit, preSelectedGameType, preSelectedQuestionSet]);

  if (!isOpen) return null;

  const currentMeta = GAME_TYPE_METADATA[gameType];

  // When teacher picks a set from dropdown
  const handleSelectQuestionSet = (setId: string) => {
    sound.playClick();
    setSelectedSetId(setId);
    const found = questionSets.find((s) => s.id === setId);
    if (found) {
      setQuestions([...found.questions]);
      if (!title || title.startsWith(currentMeta.name)) {
        setTitle(`${currentMeta.name} - ${found.title}`);
      }
    }
  };

  const handleAddManualQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQText.trim()) return;
    sound.playClick();

    const options = [opt1, opt2, opt3, opt4].filter((o) => o.trim().length > 0);
    const finalCorrect = correctAnswer.trim() || options[0] || 'الإجابة النموذجية';

    const newQ: Question = {
      id: `q-manual-${Date.now()}`,
      text: newQText.trim(),
      options: options.length > 0 ? options : undefined,
      correctAnswer: finalCorrect,
      explanation: explanation.trim() || undefined,
      points: 10,
      timeLimit: 15,
    };

    setQuestions((prev) => [...prev, newQ]);
    setShowAddQuestion(false);
    setNewQText('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setOpt4('');
    setCorrectAnswer('');
    setExplanation('');
  };

  const handleDeleteQuestion = (qId: string) => {
    sound.playClick();
    setQuestions((prev) => prev.filter((q) => q.id !== qId));
  };

  const handleSaveActivity = (launchImmediately = false) => {
    if (!title.trim()) return;
    sound.playClick();

    const updatedActivity: Activity = {
      id: activityToEdit?.id || `act-${Date.now()}`,
      title: title.trim(),
      gameType,
      questionSetId: selectedSetId || undefined,
      questions,
      config: {
        team1Name,
        team2Name,
        boxCount,
        timePerQuestion,
        enable5050,
        pointsMode,
      },
      createdAt: activityToEdit?.createdAt || Date.now(),
      updatedAt: Date.now(),
      playsCount: activityToEdit?.playsCount || 0,
      lastPlayedAt: activityToEdit?.lastPlayedAt,
    };

    storage.saveOrUpdateActivity(updatedActivity);
    onSave(updatedActivity, launchImmediately);
    onClose();
  };

  // Launch CTA text tailored to each game
  const getLaunchButtonLabel = () => {
    switch (gameType) {
      case 'team-race':
        return 'ابدأ التحدي 🚀';
      case 'mystery-box':
        return 'ابدأ مغامرة الصناديق 🚀';
      case 'wheel-of-names':
        return 'ابدأ تدوير العجلة 🚀';
      case 'multiple-choice':
        return 'ابدأ مسابقة التحدي 🚀';
      case 'flip-card':
        return 'ابدأ تحدي البطاقات 🚀';
      case 'matching':
        return 'ابدأ لعبة المطابقة 🚀';
      case 'time-attack':
        return 'ابدأ سباق الوقت 🚀';
      case 'class-points':
        return 'افتح لوحة النقاط 🚀';
      case 'exit-ticket':
        return 'ابدأ تذكرة الخروج 🚀';
      default:
        return 'ابدأ اللعبة الآن 🚀';
    }
  };

  const gameTypesList: GameType[] = [
    'team-race',
    'mystery-box',
    'wheel-of-names',
    'multiple-choice',
    'flip-card',
    'matching',
    'time-attack',
    'class-points',
    'exit-ticket',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="bg-gradient-to-b from-white via-indigo-50/30 to-sky-50/30 rounded-3xl max-w-3xl w-full max-h-[92vh] shadow-2xl border border-indigo-200 flex flex-col overflow-hidden">
        
        {/* Dedicated Game Header Banner */}
        <div className={`px-6 py-5 border-b border-indigo-100 flex items-center justify-between bg-gradient-to-r ${currentMeta.color} text-white`}>
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-3xl shadow-inner">
              {currentMeta.emoji}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white drop-shadow-xs">
                  إعداد {currentMeta.name}
                </h2>
                <span className="text-[11px] font-black bg-black/25 px-2.5 py-0.5 rounded-full text-white/90">
                  {currentMeta.badge}
                </span>
              </div>
              <p className="text-xs text-indigo-100 font-medium mt-0.5">
                {currentMeta.tagline}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Form Body: Direct settings for this game only */}
        <div className="flex-1 p-6 sm:p-8 overflow-y-auto flex flex-col gap-6 bg-slate-50/40">
          
          {/* If opened from generic navbar without game preselected, allow quick switch */}
          {!isDirectGameFlow && (
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
              <label className="text-xs font-bold text-slate-700 block">اختر نوع اللعبة:</label>
              <div className="grid grid-cols-3 gap-2">
                {gameTypesList.map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setGameType(type);
                    }}
                    className={`p-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                      gameType === type
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <span>{GAME_TYPE_METADATA[type].emoji}</span>
                    <span className="truncate">{GAME_TYPE_METADATA[type].name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 1. عنوان النشاط */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
            <label className="text-xs font-black text-slate-800 block">
              عنوان النشاط (يظهر للطلاب على الشاشة الذكية)
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={`مثال: ${currentMeta.name} - مراجعة الدرس`}
              className="w-full p-3.5 border-2 border-slate-200 rounded-xl text-base font-bold text-slate-900 focus:border-indigo-500 focus:outline-none transition-colors"
            />
          </div>

          {/* 2. اختيار مجموعة الأسئلة من بنك الأسئلة */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <label className="text-xs font-black text-slate-800 block">
                  مجموعة الأسئلة من بنك الأسئلة
                </label>
                <span className="text-[11px] text-slate-500 font-medium">
                  اختر مجموعة جاهزة لاستخدام أسئلتها دون إعادة كتابة
                </span>
              </div>

              {/* Set selector dropdown & create button */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-cyan-600" />
                  <select
                    value={selectedSetId}
                    onChange={(e) => handleSelectQuestionSet(e.target.value)}
                    className="p-2.5 border-2 border-slate-200 rounded-xl text-xs font-black bg-slate-50 text-slate-800 focus:outline-none focus:border-indigo-500 max-w-[280px]"
                  >
                    <option value="">-- تخصيص يدوي بدون مجموعة --</option>
                    {questionSets.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.title} [{s.subject} · {s.grade}] ({s.questions.length} أسئلة)
                      </option>
                    ))}
                  </select>
                </div>

                {onRequestCreateQuestionSet && (
                  <button
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      onRequestCreateQuestionSet();
                    }}
                    className="px-3 py-2 bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border border-cyan-300 rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                    title="إنشاء مجموعة أسئلة جديدة في بنك الأسئلة"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[3]" />
                    <span>+ إنشاء مجموعة جديدة</span>
                  </button>
                )}
              </div>
            </div>

            {questionSets.length === 0 && (
              <div className="p-3 bg-cyan-50/70 border border-cyan-200 rounded-xl flex items-center justify-between text-xs text-cyan-900">
                <span>لا توجد مجموعات بعد في بنك الأسئلة. يمكنك إنشاء مجموعتك الأولى أو كتابة أسئلة يدوية لهذا النشاط.</span>
                {onRequestCreateQuestionSet && (
                  <button
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      onRequestCreateQuestionSet();
                    }}
                    className="font-black text-cyan-700 hover:text-cyan-900 underline cursor-pointer shrink-0 mr-2"
                  >
                    + إنشاء مجموعة الآن
                  </button>
                )}
              </div>
            )}

            {/* Questions preview summary */}
            <div className="flex items-center justify-between text-xs bg-slate-50 border border-slate-200/80 p-3 rounded-xl">
              <span className="font-bold text-slate-700">
                عدد الأسئلة الجاهزة للعب: <strong className="text-indigo-600 font-mono text-sm">{questions.length}</strong> سؤال
              </span>
              <button
                type="button"
                onClick={() => setShowAddQuestion(!showAddQuestion)}
                className="text-xs font-bold text-indigo-700 hover:text-indigo-900 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{showAddQuestion ? 'إغلاق الإضافة' : 'إضافة سؤال يدوي'}</span>
              </button>
            </div>

            {/* Inline add question form */}
            {showAddQuestion && (
              <form onSubmit={handleAddManualQuestion} className="bg-indigo-50/50 border border-indigo-200 rounded-2xl p-4 flex flex-col gap-3 animate-fade-in">
                <span className="text-xs font-black text-indigo-950">إضافة سؤال جديد</span>
                <input
                  type="text"
                  required
                  value={newQText}
                  onChange={(e) => setNewQText(e.target.value)}
                  placeholder="نص السؤال..."
                  className="w-full p-2.5 text-xs font-bold border border-slate-200 rounded-xl bg-white"
                />

                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={opt1}
                    onChange={(e) => setOpt1(e.target.value)}
                    placeholder="الخيار الأول..."
                    className="p-2 text-xs border border-slate-200 rounded-lg bg-white"
                  />
                  <input
                    type="text"
                    value={opt2}
                    onChange={(e) => setOpt2(e.target.value)}
                    placeholder="الخيار الثاني..."
                    className="p-2 text-xs border border-slate-200 rounded-lg bg-white"
                  />
                  <input
                    type="text"
                    value={opt3}
                    onChange={(e) => setOpt3(e.target.value)}
                    placeholder="الخيار الثالث..."
                    className="p-2 text-xs border border-slate-200 rounded-lg bg-white"
                  />
                  <input
                    type="text"
                    value={opt4}
                    onChange={(e) => setOpt4(e.target.value)}
                    placeholder="الخيار الرابع..."
                    className="p-2 text-xs border border-slate-200 rounded-lg bg-white"
                  />
                </div>

                <input
                  type="text"
                  required
                  value={correctAnswer}
                  onChange={(e) => setCorrectAnswer(e.target.value)}
                  placeholder="الإجابة الصحيحة بالضبط..."
                  className="p-2 text-xs border-2 border-emerald-400 rounded-lg bg-white font-bold"
                />

                <button
                  type="submit"
                  className="self-end px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                >
                  حفظ السؤال في النشاط
                </button>
              </form>
            )}
          </div>

          {/* 3. الإعدادات الخاصة باللعبة المختارة فقط */}
          
          {/* إعدادات تحدي الفريقين */}
          {gameType === 'team-race' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <label className="text-xs font-black text-blue-900 block flex items-center gap-2">
                <span>🏎️</span>
                <span>أسماء الفريقين المتنافسين</span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-[11px] font-bold text-blue-700 block mb-1">اسم الفريق الأول (الأزرق)</span>
                  <input
                    type="text"
                    value={team1Name}
                    onChange={(e) => setTeam1Name(e.target.value)}
                    placeholder="صقور المعرفة"
                    className="w-full p-3 border-2 border-blue-200 rounded-xl text-sm font-black text-slate-800 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <span className="text-[11px] font-bold text-emerald-700 block mb-1">اسم الفريق الثاني (الأخضر)</span>
                  <input
                    type="text"
                    value={team2Name}
                    onChange={(e) => setTeam2Name(e.target.value)}
                    placeholder="فرسان التحدي"
                    className="w-full p-3 border-2 border-emerald-200 rounded-xl text-sm font-black text-slate-800 focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* إعدادات الصندوق الغامض */}
          {gameType === 'mystery-box' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <label className="text-xs font-black text-amber-900 block flex items-center gap-2">
                <span>🎁</span>
                <span>عدد الصناديق في اللعبة</span>
              </label>
              <div className="flex items-center gap-3">
                {[6, 8, 12].map((count) => (
                  <button
                    key={count}
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setBoxCount(count);
                    }}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-black border-2 transition-all ${
                      boxCount === count
                        ? 'bg-amber-100 border-amber-500 text-amber-900 shadow-xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    {count} صناديق
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* إعدادات عجلة الأسماء */}
          {gameType === 'wheel-of-names' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-black text-rose-900 flex items-center gap-2">
                  <span>🎡</span>
                  <span>عجلة الأسماء والقرعة الصفية</span>
                </label>
                <span className="text-[11px] font-bold text-slate-500">
                  قائمة طلاب الفصل جاهزة للتناوب
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                العجلة ستستخدم أسماء طلاب الفصل المعتمدة، مع ربط سؤال التحدي للبطل من المجموعة المختارة أعلاه.
              </p>
            </div>
          )}

          {/* إعدادات اختر الإجابة الصحيحة */}
          {gameType === 'multiple-choice' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <label className="text-xs font-black text-emerald-900 block flex items-center gap-2">
                <span>🎯</span>
                <span>خيارات مسابقة التحدي الكبرى</span>
              </label>
              <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={enable5050}
                  onChange={(e) => setEnable5050(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                />
                <span>تفعيل وسيلة المساعدة (حذف إجابتين 50:50) للطلاب</span>
              </label>
            </div>
          )}

          {/* إعدادات تحدي الوقت */}
          {gameType === 'time-attack' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <label className="text-xs font-black text-rose-900 block flex items-center gap-2">
                <span>⏱️</span>
                <span>الوقت المخصص لكل سؤال</span>
              </label>
              <div className="flex items-center gap-3">
                {[10, 15, 20].map((seconds) => (
                  <button
                    key={seconds}
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setTimePerQuestion(seconds);
                    }}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-black border-2 transition-all ${
                      timePerQuestion === seconds
                        ? 'bg-rose-100 border-rose-500 text-rose-900 shadow-xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    {seconds} ثانية
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* إعدادات نقاط الفصل */}
          {gameType === 'class-points' && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <label className="text-xs font-black text-amber-900 block flex items-center gap-2">
                <span>⭐</span>
                <span>طريقة احتساب النقاط</span>
              </label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setPointsMode('teams')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-black border-2 transition-all ${
                    pointsMode === 'teams'
                      ? 'bg-amber-100 border-amber-500 text-amber-900'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  الفرق الصفية (صقور، فرسان، نجوم، عباقرة)
                </button>
                <button
                  type="button"
                  onClick={() => setPointsMode('students')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-black border-2 transition-all ${
                    pointsMode === 'students'
                      ? 'bg-amber-100 border-amber-500 text-amber-900'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  الطلاب فردياً
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions with prominent "ابدأ التحدي" */}
        <div className="px-6 py-4 border-t border-indigo-100 bg-white flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="px-5 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
          >
            إلغاء
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => handleSaveActivity(false)}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              حفظ في أنشطتي
            </button>

            {/* Direct Launch Button */}
            <button
              type="button"
              onClick={() => handleSaveActivity(true)}
              className={`px-8 py-3 bg-gradient-to-r ${currentMeta.btnGradient} text-white font-black text-sm rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer tactile-btn`}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{getLaunchButtonLabel()}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
