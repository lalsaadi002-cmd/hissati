import React, { useState, useEffect } from 'react';
import { Question } from '../../types';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti, fireGrandWinnerConfetti } from '../../utils/confetti';
import { Timer, RotateCcw, Zap, Award, Check, X, AlertTriangle } from 'lucide-react';
import { getRandomFeedback } from '../../utils/feedback';
import { AnswerFeedbackBanner } from '../common/AnswerFeedbackBanner';

interface TimeAttackGameProps {
  questions: Question[];
  onRestart: () => void;
}

const DEFAULT_TIME = 15; // 15 seconds per question

export const TimeAttackGame: React.FC<TimeAttackGameProps> = ({
  questions,
  onRestart,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(DEFAULT_TIME);
  const [timerRunning, setTimerRunning] = useState(true);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isRevealed, setIsRevealed] = useState(false);
  const [feedbackPhrase, setFeedbackPhrase] = useState('');
  const [isTimeout, setIsTimeout] = useState(false);
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);

  const currentQ = questions[currentIndex];
  const maxTime = currentQ?.timeLimit || DEFAULT_TIME;

  // Countdown timer
  useEffect(() => {
    if (!timerRunning || isRevealed || isGameOver) return;

    if (timeLeft <= 0) {
      // Time is up!
      setTimerRunning(false);
      setIsTimeout(true);
      setIsRevealed(true);
      setFeedbackPhrase('انتهى الوقت المحدد! فكّر وحاول في السؤال القادم');
      sound.playIncorrect();
      return;
    }

    if (timeLeft <= 5) {
      sound.playTick();
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [timeLeft, timerRunning, isRevealed, isGameOver]);

  const handleSelectOption = (opt: string) => {
    if (isRevealed || isGameOver) return;
    sound.playClick();
    setTimerRunning(false);
    setSelectedOption(opt);
    setIsRevealed(true);

    const isCorrect = String(opt).trim() === String(currentQ.correctAnswer).trim();
    setFeedbackPhrase(getRandomFeedback(isCorrect));

    if (isCorrect) {
      sound.playCorrect();
      fireCelebrationConfetti();
      // Speed bonus: if answered with more than half time remaining, 2x points
      const isSpeedy = timeLeft >= maxTime / 2;
      const points = (currentQ.points || 10) * (isSpeedy ? 2 : 1);
      setScore((prev) => prev + points);
    } else {
      sound.playIncorrect();
    }
  };

  const handleNext = () => {
    sound.playClick();
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      const nextLimit = questions[currentIndex + 1]?.timeLimit || DEFAULT_TIME;
      setTimeLeft(nextLimit);
      setSelectedOption(null);
      setIsRevealed(false);
      setIsTimeout(false);
      setTimerRunning(true);
    } else {
      setIsGameOver(true);
      sound.playWin();
      fireGrandWinnerConfetti();
    }
  };

  const handleReset = () => {
    sound.playClick();
    setCurrentIndex(0);
    setTimeLeft(questions[0]?.timeLimit || DEFAULT_TIME);
    setSelectedOption(null);
    setIsRevealed(false);
    setIsTimeout(false);
    setTimerRunning(true);
    setScore(0);
    setIsGameOver(false);
    onRestart();
  };

  // SVG circle calculations
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const progressPercent = Math.max(0, timeLeft / maxTime);
  const strokeDashoffset = circumference - progressPercent * circumference;

  let timerColor = '#10b981'; // green
  if (timeLeft <= 5) {
    timerColor = '#ef4444'; // red
  } else if (timeLeft <= 10) {
    timerColor = '#f59e0b'; // amber
  }

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto py-2">
      
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-xl">
            <Timer className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">تحدي السرعة وعقارب الساعة</h3>
            <p className="text-xs text-slate-500">أجب قبل انتهاء الوقت واحصل على مضاعف السرعة</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-red-50 text-red-700 px-3.5 py-1.5 rounded-xl border border-red-200 text-xs font-bold">
            <Award className="w-4 h-4" />
            <span>النقاط:</span>
            <span className="font-mono text-base font-black">{score}</span>
          </div>

          <button
            onClick={handleReset}
            className="p-2 text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            title="إعادة التحدي"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Game Over Result */}
      {isGameOver ? (
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-md text-center flex flex-col items-center gap-4 animate-fade-in">
          <div className="w-20 h-20 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-4xl shadow-inner">
            ⚡
          </div>
          <h2 className="text-3xl font-black text-slate-900">
            انتهى سباق الوقت بنجاح!
          </h2>
          <p className="text-slate-600 font-medium">
            أثبت الفصل سرعة بديهة استثنائية بحصد:
          </p>
          <div className="text-5xl font-black text-red-600 font-mono my-2">
            {score} نقطة
          </div>
          <button
            onClick={handleReset}
            className="px-8 py-3.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-md cursor-pointer transition-colors"
          >
            بدء سباق وقت جديد
          </button>
        </div>
      ) : (
        /* Question Arena */
        currentQ && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col gap-6 relative overflow-hidden">
            
            {/* Timer Ring Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <span className="text-xs font-bold text-slate-500">
                السؤال {currentIndex + 1} من {questions.length}
              </span>

              {/* Circular SVG Timer */}
              <div className="flex items-center gap-3">
                <div className="relative w-16 h-16 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r={radius}
                      className="text-slate-100"
                      strokeWidth="8"
                      stroke="currentColor"
                      fill="transparent"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r={radius}
                      stroke={timerColor}
                      strokeWidth="8"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      fill="transparent"
                      className="transition-all duration-1000 ease-linear"
                    />
                  </svg>
                  <span
                    className={`absolute text-lg font-black font-mono ${
                      timeLeft <= 5 ? 'text-red-600 animate-ping-once' : 'text-slate-800'
                    }`}
                  >
                    {timeLeft}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[11px] font-bold text-slate-400 block">الوقت المتبقي</span>
                  <span className="text-xs font-black text-slate-700">{timeLeft} ثانية</span>
                </div>
              </div>
            </div>

            {/* Question Text */}
            <div className="min-h-[80px] flex items-center justify-center text-center px-4">
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 leading-relaxed text-wrap-balance">
                {currentQ.text}
              </h2>
            </div>

            {/* Timeout warning */}
            {isTimeout && (
              <div className="bg-red-50 border border-red-200 p-3 rounded-xl flex items-center justify-center gap-2 text-red-800 font-bold text-sm animate-bounce">
                <AlertTriangle className="w-4 h-4" />
                <span>انتهى الوقت المحدد للإجابة!</span>
              </div>
            )}

            {/* Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(currentQ.options || ['أ', 'ب', 'ج', 'د']).map((opt, idx) => {
                const isSelected = selectedOption === opt;
                const isCorrect = String(opt).trim() === String(currentQ.correctAnswer).trim();

                let style = 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800';
                if (isRevealed) {
                  if (isCorrect) {
                    style = 'bg-emerald-500 text-white border-emerald-600 shadow-md';
                  } else if (isSelected) {
                    style = 'bg-rose-500 text-white border-rose-600 shadow-sm';
                  } else {
                    style = 'bg-slate-100 text-slate-400 opacity-60';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(opt)}
                    disabled={isRevealed}
                    className={`p-4 rounded-xl border-2 text-right font-bold text-base transition-all duration-200 flex items-center justify-between gap-3 cursor-pointer ${style}`}
                  >
                    <span className="flex-1">{opt}</span>
                    <div className="w-7 h-7 rounded-lg bg-black/10 flex items-center justify-center text-xs font-mono">
                      {['أ', 'ب', 'ج', 'د'][idx] || idx + 1}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Reveal & Next button with feedback */}
            {isRevealed && (
              <div className="mt-2">
                <AnswerFeedbackBanner
                  isCorrect={!isTimeout && String(selectedOption).trim() === String(currentQ.correctAnswer).trim()}
                  phrase={feedbackPhrase}
                  correctAnswerText={currentQ.correctAnswer}
                  explanation={currentQ.explanation}
                  onNext={handleNext}
                  nextButtonLabel={currentIndex < questions.length - 1 ? 'السؤال التالي' : 'عرض النتيجة النهائية'}
                />
              </div>
            )}

          </div>
        )
      )}

    </div>
  );
};
