import React, { useState, useEffect } from 'react';
import { Question } from '../../types';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti, fireGrandWinnerConfetti } from '../../utils/confetti';
import { Trophy, Flag, RotateCcw, Check, X, Shield, Zap, ArrowLeft } from 'lucide-react';
import { getRandomFeedback } from '../../utils/feedback';
import { AnswerFeedbackBanner } from '../common/AnswerFeedbackBanner';

interface TeamRaceGameProps {
  questions: Question[];
  config?: {
    team1Name?: string;
    team2Name?: string;
    targetScore?: number;
  };
  onRestart: () => void;
}

export const TeamRaceGame: React.FC<TeamRaceGameProps> = ({
  questions,
  config,
  onRestart,
}) => {
  const [team1Name, setTeam1Name] = useState(config?.team1Name || 'صقور المعرفة');
  const [team2Name, setTeam2Name] = useState(config?.team2Name || 'فرسان التحدي');
  
  const [team1Progress, setTeam1Progress] = useState(0); // 0 to 100
  const [team2Progress, setTeam2Progress] = useState(0);
  const [team1Score, setTeam1Score] = useState(0);
  const [team2Score, setTeam2Score] = useState(0);

  const [currentTeamTurn, setCurrentTeamTurn] = useState<1 | 2>(1);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerRevealed, setIsAnswerRevealed] = useState(false);
  const [feedbackPhrase, setFeedbackPhrase] = useState('');
  const [winner, setWinner] = useState<1 | 2 | null>(null);

  const currentQ = questions[currentQuestionIndex % questions.length];

  // Check victory
  useEffect(() => {
    if (team1Progress >= 100 && !winner) {
      setWinner(1);
      sound.playWin();
      fireGrandWinnerConfetti();
    } else if (team2Progress >= 100 && !winner) {
      setWinner(2);
      sound.playWin();
      fireGrandWinnerConfetti();
    }
  }, [team1Progress, team2Progress, winner]);

  const handleSelectOption = (opt: string) => {
    if (isAnswerRevealed || winner) return;
    sound.playClick();
    setSelectedOption(opt);
    setIsAnswerRevealed(true);

    const isCorrect = String(opt).trim() === String(currentQ.correctAnswer).trim();
    setFeedbackPhrase(getRandomFeedback(isCorrect));
    const stepIncrement = Math.max(15, Math.floor(100 / Math.max(3, questions.length)));

    if (isCorrect) {
      sound.playCorrect();
      fireCelebrationConfetti();
      if (currentTeamTurn === 1) {
        setTeam1Score((prev) => prev + (currentQ.points || 10));
        setTeam1Progress((prev) => Math.min(100, prev + stepIncrement));
      } else {
        setTeam2Score((prev) => prev + (currentQ.points || 10));
        setTeam2Progress((prev) => Math.min(100, prev + stepIncrement));
      }
    } else {
      sound.playIncorrect();
    }
  };

  const handleNextQuestion = () => {
    sound.playClick();
    setSelectedOption(null);
    setIsAnswerRevealed(false);
    setCurrentTeamTurn((prev) => (prev === 1 ? 2 : 1));
    setCurrentQuestionIndex((prev) => (prev + 1) % questions.length);
  };

  const handleResetGame = () => {
    sound.playClick();
    setTeam1Progress(0);
    setTeam2Progress(0);
    setTeam1Score(0);
    setTeam2Score(0);
    setCurrentTeamTurn(1);
    setCurrentQuestionIndex(0);
    setSelectedOption(null);
    setIsAnswerRevealed(false);
    setWinner(null);
    onRestart();
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-2 sm:px-4 py-2 flex flex-col gap-4 animate-fade-in">
      
      {/* COMPACT & ELEGANT TOP RACE STRIP: Teams side-by-side without taking big space */}
      <div className="bg-white/95 backdrop-blur-md rounded-2xl p-3.5 sm:p-4 border-2 border-slate-200/90 shadow-sm flex flex-col gap-2.5">
        
        {/* Strip utility top row */}
        <div className="flex items-center justify-between text-xs font-bold border-b border-slate-100 pb-2">
          <div className="flex items-center gap-2 text-slate-800">
            <Trophy className="w-4 h-4 text-amber-500 fill-amber-400" />
            <span className="font-black text-sm">ميدان سباق الفريقين</span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-500 font-mono">سؤال {currentQuestionIndex + 1} من {questions.length}</span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-slate-100 px-2.5 py-1 rounded-lg">
              <span className="text-slate-500">الدور:</span>
              <span className={currentTeamTurn === 1 ? 'text-blue-700 font-black' : 'text-emerald-700 font-black'}>
                {currentTeamTurn === 1 ? team1Name : team2Name}
              </span>
            </div>

            <button
              onClick={handleResetGame}
              className="flex items-center gap-1 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
              title="إعادة بدء السباق"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="text-[11px]">إعادة</span>
            </button>
          </div>
        </div>

        {/* Both Teams Side-by-Side in Compact Lanes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          
          {/* Team 1 Lane (Blue) */}
          <div className={`p-2.5 rounded-xl border transition-all ${
            currentTeamTurn === 1 && !winner
              ? 'bg-blue-50/80 border-blue-400 ring-2 ring-blue-300/50 shadow-2xs'
              : 'bg-slate-50/70 border-slate-200'
          }`}>
            <div className="flex items-center justify-between text-xs font-black mb-1.5">
              <div className="flex items-center gap-1.5 text-blue-900 truncate">
                <span className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center text-xs shrink-0">
                  🏎️
                </span>
                <span className="truncate">{team1Name}</span>
                {currentTeamTurn === 1 && !winner && (
                  <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.2 rounded-full font-bold animate-pulse">
                    دورك
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px] shrink-0">
                <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded font-black">{team1Score} نقطة</span>
                <span className="text-slate-500 font-bold">{team1Progress}%</span>
              </div>
            </div>

            {/* Short & Clean Race Track */}
            <div className="h-6 bg-white rounded-full relative overflow-hidden border border-slate-200 p-0.5 flex items-center shadow-inner">
              {/* Progress background fill */}
              <div
                className="absolute inset-y-0 right-0 bg-gradient-to-l from-blue-500 to-indigo-500 transition-all duration-700 ease-out rounded-full"
                style={{ width: `${team1Progress}%` }}
              />

              {/* Moving Racer */}
              <div
                className="absolute transition-all duration-700 ease-out z-10 flex items-center justify-center"
                style={{
                  right: `calc(${team1Progress}% - ${team1Progress > 85 ? '24px' : '10px'})`,
                }}
              >
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs shadow-md border-2 border-white ring-2 ring-blue-300">
                  🏎️
                </div>
              </div>

              {/* Finish Line Flag */}
              <div className="absolute left-1.5 flex items-center text-slate-400 z-5">
                <Flag className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
              </div>
            </div>
          </div>

          {/* Team 2 Lane (Emerald) */}
          <div className={`p-2.5 rounded-xl border transition-all ${
            currentTeamTurn === 2 && !winner
              ? 'bg-emerald-50/80 border-emerald-400 ring-2 ring-emerald-300/50 shadow-2xs'
              : 'bg-slate-50/70 border-slate-200'
          }`}>
            <div className="flex items-center justify-between text-xs font-black mb-1.5">
              <div className="flex items-center gap-1.5 text-emerald-900 truncate">
                <span className="w-5 h-5 rounded-md bg-emerald-600 text-white flex items-center justify-center text-xs shrink-0">
                  ⚡
                </span>
                <span className="truncate">{team2Name}</span>
                {currentTeamTurn === 2 && !winner && (
                  <span className="text-[10px] bg-emerald-600 text-white px-1.5 py-0.2 rounded-full font-bold animate-pulse">
                    دورك
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px] shrink-0">
                <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-black">{team2Score} نقطة</span>
                <span className="text-slate-500 font-bold">{team2Progress}%</span>
              </div>
            </div>

            {/* Short & Clean Race Track */}
            <div className="h-6 bg-white rounded-full relative overflow-hidden border border-slate-200 p-0.5 flex items-center shadow-inner">
              {/* Progress background fill */}
              <div
                className="absolute inset-y-0 right-0 bg-gradient-to-l from-emerald-500 to-teal-500 transition-all duration-700 ease-out rounded-full"
                style={{ width: `${team2Progress}%` }}
              />

              {/* Moving Racer */}
              <div
                className="absolute transition-all duration-700 ease-out z-10 flex items-center justify-center"
                style={{
                  right: `calc(${team2Progress}% - ${team2Progress > 85 ? '24px' : '10px'})`,
                }}
              >
                <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs shadow-md border-2 border-white ring-2 ring-emerald-300">
                  ⚡
                </div>
              </div>

              {/* Finish Line Flag */}
              <div className="absolute left-1.5 flex items-center text-slate-400 z-5">
                <Flag className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* WINNER CELEBRATION MODAL (Shows in center on victory) */}
      {winner && (
        <div className="bg-gradient-to-b from-amber-50 via-yellow-50 to-orange-50 border-4 border-amber-400 rounded-3xl p-8 sm:p-12 text-center shadow-2xl relative overflow-hidden animate-fade-in my-4">
          <div className="inline-flex p-4 rounded-full bg-amber-100 text-amber-800 mb-3 shadow-inner ring-4 ring-amber-300/50">
            <Trophy className="w-14 h-14 stroke-[2.5] animate-bounce" />
          </div>
          <span className="text-xs font-black uppercase tracking-widest text-amber-800 bg-amber-200/90 px-4 py-1 rounded-full mb-2 inline-block">
            بطل سباق الفصل
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-slate-900 mb-3 tracking-tight">
            مبروك فوز {winner === 1 ? team1Name : team2Name}! 🏆
          </h2>
          <p className="text-base sm:text-lg text-slate-700 mb-8 font-bold max-w-md mx-auto leading-relaxed">
            وصل الفريق إلى خط النهاية بنجاح وتفوق بجدارة في الإجابة على الأسئلة!
          </p>
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={handleResetGame}
              className="px-8 py-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-base rounded-2xl shadow-xl shadow-amber-500/30 cursor-pointer transition-all tactile-btn flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4 stroke-[2.5]" />
              <span>لعب جولة سباق جديدة</span>
            </button>
          </div>
        </div>
      )}

      {/* MAIN QUESTION & CHOICES ARENA (Occupies the primary spacious area) */}
      {!winner && currentQ && (
        <div className="bg-white rounded-3xl p-6 sm:p-10 border-2 border-slate-200 shadow-md flex flex-col justify-between gap-6 min-h-[440px]">
          
          {/* Turn Header Banner */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <span className={`px-4 py-2 text-xs sm:text-sm font-black rounded-xl flex items-center gap-2 shadow-2xs ${
                currentTeamTurn === 1
                  ? 'bg-blue-600 text-white'
                  : 'bg-emerald-600 text-white'
              }`}>
                <span>{currentTeamTurn === 1 ? '🏎️' : '⚡'}</span>
                <span>سؤال موجه لـ: {currentTeamTurn === 1 ? team1Name : team2Name}</span>
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs font-bold">
              <span className="bg-amber-100 text-amber-900 px-3 py-1.5 rounded-lg font-mono text-xs">
                +{currentQ.points || 10} نقطة وخطوة سباق
              </span>
            </div>
          </div>

          {/* Big, Clear Question Text for Classroom Smartboards */}
          <div className="py-4 text-center">
            <h3 className="text-2xl sm:text-4xl lg:text-5xl font-black text-slate-900 leading-snug sm:leading-snug drop-shadow-2xs">
              {currentQ.text}
            </h3>
          </div>

          {/* Large Choices Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            {(currentQ.options && currentQ.options.length > 0
              ? currentQ.options
              : ['نعم', 'لا', 'محتمل', 'غير ذلك']
            ).map((opt, idx) => {
              const isSelected = selectedOption === opt;
              const isCorrectAnswer = String(opt).trim() === String(currentQ.correctAnswer).trim();

              let btnStyle = 'bg-slate-50 hover:bg-indigo-50/60 border-slate-200 text-slate-800 hover:border-indigo-300';
              if (isAnswerRevealed) {
                if (isCorrectAnswer) {
                  btnStyle = 'bg-emerald-500 text-white border-emerald-600 shadow-lg shadow-emerald-500/20 scale-[1.02] font-black';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-500 text-white border-rose-600 shadow-md font-bold';
                } else {
                  btnStyle = 'bg-slate-100 text-slate-400 border-slate-200 opacity-50';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(opt)}
                  disabled={isAnswerRevealed}
                  className={`p-5 sm:p-6 rounded-2xl border-2 text-right text-lg sm:text-xl font-black transition-all duration-200 flex items-center justify-between gap-4 cursor-pointer tactile-btn ${btnStyle}`}
                >
                  <span className="flex-1 leading-snug">{opt}</span>
                  <div className="w-10 h-10 rounded-xl bg-black/10 flex items-center justify-center shrink-0 text-base font-black font-mono">
                    {isAnswerRevealed && isCorrectAnswer ? (
                      <Check className="w-6 h-6 text-white stroke-[3]" />
                    ) : isAnswerRevealed && isSelected ? (
                      <X className="w-6 h-6 text-white stroke-[3]" />
                    ) : (
                      ['أ', 'ب', 'ج', 'د'][idx] || idx + 1
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Explanation & Next Question Banner with Feedback */}
          {isAnswerRevealed && (
            <div className="mt-2">
              <AnswerFeedbackBanner
                isCorrect={String(selectedOption).trim() === String(currentQ.correctAnswer).trim()}
                phrase={feedbackPhrase}
                correctAnswerText={currentQ.correctAnswer}
                explanation={currentQ.explanation}
                onNext={handleNextQuestion}
                nextButtonLabel={`السؤال التالي (دور ${currentTeamTurn === 1 ? team2Name : team1Name})`}
              />
            </div>
          )}

        </div>
      )}

    </div>
  );
};
