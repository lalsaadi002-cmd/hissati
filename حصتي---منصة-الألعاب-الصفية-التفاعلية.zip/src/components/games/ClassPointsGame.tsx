import React, { useState } from 'react';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti, fireGrandWinnerConfetti } from '../../utils/confetti';
import { Star, Plus, Minus, Trophy, Users, Sparkles, RotateCcw, Shield, Award } from 'lucide-react';
import { storage } from '../../services/storageService';

interface StudentItem {
  id: string;
  name: string;
  points: number;
  badges: string[];
}

interface TeamItem {
  id: string;
  name: string;
  color: string;
  points: number;
  badges: string[];
}

export const ClassPointsGame: React.FC = () => {
  const [mode, setMode] = useState<'students' | 'teams'>('teams');

  // Initial teams
  const [teams, setTeams] = useState<TeamItem[]>([
    { id: 't1', name: 'فريق الصقور', color: 'from-blue-500 to-indigo-600', points: 15, badges: ['🌟 تميز'] },
    { id: 't2', name: 'فريق الفرسان', color: 'from-emerald-500 to-teal-600', points: 20, badges: ['⚡ سرعة'] },
    { id: 't3', name: 'فريق النجوم', color: 'from-amber-500 to-orange-600', points: 10, badges: ['🤝 تعاون'] },
    { id: 't4', name: 'فريق العباقرة', color: 'from-purple-500 to-pink-600', points: 25, badges: ['💡 إبداع'] },
  ]);

  // Initial students
  const [students, setStudents] = useState<StudentItem[]>(() => {
    const list = storage.getStudents();
    return list.slice(0, 10).map((name, i) => ({
      id: `s-${i}`,
      name,
      points: (i * 3) % 15,
      badges: i % 2 === 0 ? ['🌟 إجابة صحيحة'] : ['🛡️ انضباط'],
    }));
  });

  const [newEntryName, setNewEntryName] = useState('');
  const [selectedBadge, setSelectedBadge] = useState('🌟 إجابة مميزة');

  const BADGE_OPTIONS = [
    '🌟 إجابة مميزة',
    '🤝 تعاون فريقي',
    '🛡️ انضباط وهدوء',
    '⚡ سرعة إنجاز',
    '💡 تفكير إبداعي',
  ];

  const handleAddPoints = (id: string, amount: number, isTeam: boolean) => {
    if (amount > 0) {
      sound.playCorrect();
      fireCelebrationConfetti();
    } else {
      sound.playIncorrect();
    }

    if (isTeam) {
      setTeams((prev) =>
        prev.map((t) => (t.id === id ? { ...t, points: Math.max(0, t.points + amount) } : t))
      );
    } else {
      setStudents((prev) =>
        prev.map((s) => (s.id === id ? { ...s, points: Math.max(0, s.points + amount) } : s))
      );
    }
  };

  const handleAwardBadge = (id: string, badge: string, isTeam: boolean) => {
    sound.playClick();
    if (isTeam) {
      setTeams((prev) =>
        prev.map((t) =>
          t.id === id
            ? { ...t, badges: t.badges.includes(badge) ? t.badges : [...t.badges, badge] }
            : t
        )
      );
    } else {
      setStudents((prev) =>
        prev.map((s) =>
          s.id === id
            ? { ...s, badges: s.badges.includes(badge) ? s.badges : [...s.badges, badge] }
            : s
        )
      );
    }
  };

  const handleResetPoints = () => {
    sound.playClick();
    if (mode === 'teams') {
      setTeams((prev) => prev.map((t) => ({ ...t, points: 0, badges: [] })));
    } else {
      setStudents((prev) => prev.map((s) => ({ ...s, points: 0, badges: [] })));
    }
  };

  const handleAddEntry = () => {
    if (!newEntryName.trim()) return;
    sound.playClick();
    if (mode === 'teams') {
      const newTeam: TeamItem = {
        id: `t-${Date.now()}`,
        name: newEntryName.trim(),
        color: 'from-indigo-500 to-purple-600',
        points: 0,
        badges: [],
      };
      setTeams((prev) => [...prev, newTeam]);
    } else {
      const newStudent: StudentItem = {
        id: `s-${Date.now()}`,
        name: newEntryName.trim(),
        points: 0,
        badges: [],
      };
      setStudents((prev) => [...prev, newStudent]);
    }
    setNewEntryName('');
  };

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto py-2">
      
      {/* Top Header & Mode Toggle */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-50 border border-amber-200 text-amber-600 rounded-xl">
            <Star className="w-6 h-6 stroke-[2.2] fill-amber-400" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">لوحة نقاط الفصل والنجوم</h3>
            <p className="text-xs text-slate-500">إدارة صفية فورية وتحفيز تفاعلي للطلاب والفرق</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Mode Switcher */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              onClick={() => {
                sound.playClick();
                setMode('teams');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mode === 'teams'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الفرق الصفية
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setMode('students');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mode === 'students'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الطلاب فردياً
            </button>
          </div>

          <button
            onClick={handleResetPoints}
            className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors cursor-pointer"
            title="تصفير النقاط"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>تصفير</span>
          </button>
        </div>
      </div>

      {/* Quick Add Form & Badge Palette */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 flex-1 min-w-[260px]">
          <input
            type="text"
            value={newEntryName}
            onChange={(e) => setNewEntryName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddEntry()}
            placeholder={mode === 'teams' ? 'اسم فريق جديد...' : 'اسم طالب جديد...'}
            className="flex-1 p-2.5 text-xs font-medium border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
          />
          <button
            onClick={handleAddEntry}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>إضافة</span>
          </button>
        </div>

        {/* Selected badge info */}
        <div className="flex items-center gap-2 overflow-x-auto py-1">
          <span className="text-[11px] font-bold text-slate-400">وسام التحفيز السريع:</span>
          {BADGE_OPTIONS.map((badge) => (
            <button
              key={badge}
              onClick={() => {
                sound.playClick();
                setSelectedBadge(badge);
              }}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
                selectedBadge === badge
                  ? 'bg-amber-100 border-amber-300 text-amber-900 font-bold'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {badge}
            </button>
          ))}
        </div>
      </div>

      {/* TEAMS GRID */}
      {mode === 'teams' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {teams.map((team) => (
            <div
              key={team.id}
              className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative overflow-hidden"
            >
              {/* Top Banner with Team Name */}
              <div className="flex items-center justify-between mb-4">
                <span className="text-base font-black text-slate-900">
                  {team.name}
                </span>
                <div className="w-3 h-3 rounded-full bg-indigo-500" />
              </div>

              {/* Huge Points Display */}
              <div className="text-center py-3">
                <div className="text-5xl font-black text-slate-900 font-mono tracking-tight flex items-center justify-center gap-1">
                  <span>{team.points}</span>
                  <Star className="w-6 h-6 text-amber-500 fill-amber-400" />
                </div>
                <span className="text-xs font-bold text-slate-400 mt-1 block">
                  نقطة معتمدة
                </span>
              </div>

              {/* Badges List */}
              <div className="min-h-[38px] flex flex-wrap gap-1.5 my-3 items-center">
                {team.badges.length > 0 ? (
                  team.badges.map((b, i) => (
                    <span
                      key={i}
                      className="text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200/80 px-2 py-0.5 rounded-md"
                    >
                      {b}
                    </span>
                  ))
                ) : (
                  <span className="text-[11px] text-slate-300">لا توجد أوسمة بعد</span>
                )}
              </div>

              {/* Quick Actions Bar */}
              <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
                <div className="grid grid-cols-4 gap-1.5">
                  <button
                    onClick={() => handleAddPoints(team.id, 1, true)}
                    className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    title="+1 نقطة"
                  >
                    +1
                  </button>
                  <button
                    onClick={() => handleAddPoints(team.id, 2, true)}
                    className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    title="+2 نقطة"
                  >
                    +2
                  </button>
                  <button
                    onClick={() => handleAddPoints(team.id, 5, true)}
                    className="p-2 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    title="+5 نقاط"
                  >
                    +5
                  </button>
                  <button
                    onClick={() => handleAddPoints(team.id, -1, true)}
                    className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    title="-1 نقطة"
                  >
                    -1
                  </button>
                </div>

                <button
                  onClick={() => handleAwardBadge(team.id, selectedBadge, true)}
                  className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                >
                  منح {selectedBadge}
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* INDIVIDUAL STUDENTS GRID */}
      {mode === 'students' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
          {students.map((student) => (
            <div
              key={student.id}
              className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col justify-between hover:border-indigo-300 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-sm text-slate-900 truncate" title={student.name}>
                  {student.name}
                </span>
                <span className="text-base font-black text-amber-600 font-mono flex items-center">
                  {student.points} ⭐
                </span>
              </div>

              {/* Badges preview */}
              <div className="text-[10px] text-slate-400 mb-3 truncate">
                {student.badges.join(' · ') || 'مستعد للمشاركة'}
              </div>

              {/* Point Controls */}
              <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100">
                <button
                  onClick={() => handleAddPoints(student.id, 1, false)}
                  className="flex-1 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs rounded-lg cursor-pointer"
                >
                  +1
                </button>
                <button
                  onClick={() => handleAddPoints(student.id, 2, false)}
                  className="flex-1 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs rounded-lg cursor-pointer"
                >
                  +2
                </button>
                <button
                  onClick={() => handleAddPoints(student.id, -1, false)}
                  className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-lg cursor-pointer"
                >
                  -1
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
