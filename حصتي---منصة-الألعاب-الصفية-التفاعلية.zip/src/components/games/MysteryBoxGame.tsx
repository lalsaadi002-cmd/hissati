import React, { useState, useEffect, useRef } from 'react';
import { Question } from '../../types';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti, fireGrandWinnerConfetti } from '../../utils/confetti';
import { Package, Sparkles, Check, X, RotateCcw, Award, Star, Trophy, ArrowLeft, ArrowRight } from 'lucide-react';
import { getRandomFeedback } from '../../utils/feedback';
import { AnswerFeedbackBanner } from '../common/AnswerFeedbackBanner';

interface MysteryBoxGameProps {
  questions: Question[];
  onRestart: () => void;
  onBackToLibrary?: () => void;
}

interface BoxState {
  id: number;
  questionIndex: number;
  isOpened: boolean;
  isCorrect: boolean | null;
  bonusPoints: number;
}

const ENCOURAGING_PHRASES = [
  'رائع! أبدعتم اليوم 🌟',
  'ممتاز! أنتم أبطال التحدي 🏆',
  'عمل مذهل! أحسنتم 👏',
  'يا لها من نتيجة رائعة! 🎉',
];

export const MysteryBoxGame: React.FC<MysteryBoxGameProps> = ({
  questions,
  onRestart,
  onBackToLibrary,
}) => {
  const boxCount = Math.max(6, Math.min(12, questions.length));
  
  const [boxes, setBoxes] = useState<BoxState[]>(() => {
    return Array.from({ length: boxCount }, (_, i) => ({
      id: i + 1,
      questionIndex: i % questions.length,
      isOpened: false,
      isCorrect: null,
      bonusPoints: (i % 3 === 0) ? 20 : 10,
    }));
  });

  const [activeBoxIndex, setActiveBoxIndex] = useState<number | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerRevealed, setIsAnswerRevealed] = useState(false);
  const [boxFeedbackPhrase, setBoxFeedbackPhrase] = useState('');
  const [totalScore, setTotalScore] = useState(0);

  // Final Celebration State
  const [isGameFinished, setIsGameFinished] = useState(false);
  const [encouragingPhrase, setEncouragingPhrase] = useState('');
  const autoFinishTimerRef = useRef<NodeJS.Timeout | null>(null);

  const activeBox = activeBoxIndex !== null ? boxes[activeBoxIndex] : null;
  const currentQuestion = activeBox !== null ? questions[activeBox.questionIndex] : null;

  // Clear auto timer on unmount
  useEffect(() => {
    return () => {
      if (autoFinishTimerRef.current) {
        clearTimeout(autoFinishTimerRef.current);
      }
    };
  }, []);

  // When game completes, play celebratory sound & double confetti
  useEffect(() => {
    if (isGameFinished) {
      sound.playApplause();
      fireGrandWinnerConfetti();
      const t1 = setTimeout(() => {
        fireCelebrationConfetti();
      }, 700);
      const t2 = setTimeout(() => {
        fireCelebrationConfetti();
      }, 1500);

      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
      };
    }
  }, [isGameFinished]);

  const handleOpenBox = (index: number) => {
    if (boxes[index].isOpened || isGameFinished) return;
    sound.playBoxOpen();
    setActiveBoxIndex(index);
    setSelectedOption(null);
    setIsAnswerRevealed(false);
  };

  const handleSelectOption = (opt: string) => {
    if (isAnswerRevealed || activeBoxIndex === null || !currentQuestion) return;
    sound.playClick();
    setSelectedOption(opt);
    setIsAnswerRevealed(true);

    const isCorrect = String(opt).trim() === String(currentQuestion.correctAnswer).trim();
    setBoxFeedbackPhrase(getRandomFeedback(isCorrect));
    if (isCorrect) {
      sound.playCorrect();
      fireCelebrationConfetti();
      const pts = boxes[activeBoxIndex].bonusPoints;
      setTotalScore((prev) => prev + pts);
    } else {
      sound.playIncorrect();
    }

    const updatedBoxes = boxes.map((box, idx) => {
      if (idx === activeBoxIndex) {
        return {
          ...box,
          isOpened: true,
          isCorrect,
        };
      }
      return box;
    });

    setBoxes(updatedBoxes);

    // Check if this was the last unopened box
    const allOpened = updatedBoxes.every((b) => b.isOpened);
    if (allOpened) {
      const allCorrect = updatedBoxes.every((b) => b.isCorrect === true);
      const finalPhrase = allCorrect
        ? 'إجابات كاملة! أداء استثنائي 🏆🌟'
        : ENCOURAGING_PHRASES[Math.floor(Math.random() * ENCOURAGING_PHRASES.length)];
      setEncouragingPhrase(finalPhrase);

      // Auto-transition to grand celebration after short reading delay (2.5 seconds)
      if (autoFinishTimerRef.current) {
        clearTimeout(autoFinishTimerRef.current);
      }
      autoFinishTimerRef.current = setTimeout(() => {
        setActiveBoxIndex(null);
        setIsGameFinished(true);
      }, 2500);
    }
  };

  const handleCloseQuestionModal = () => {
    sound.playClick();
    if (autoFinishTimerRef.current) {
      clearTimeout(autoFinishTimerRef.current);
    }

    const allOpened = boxes.every((b) => b.isOpened);
    if (allOpened) {
      // Transition immediately to the grand celebration
      setActiveBoxIndex(null);
      setSelectedOption(null);
      setIsAnswerRevealed(false);
      setIsGameFinished(true);
    } else {
      setActiveBoxIndex(null);
      setSelectedOption(null);
      setIsAnswerRevealed(false);
    }
  };

  const handleReset = () => {
    sound.playClick();
    if (autoFinishTimerRef.current) {
      clearTimeout(autoFinishTimerRef.current);
    }
    setBoxes((prev) =>
      prev.map((b) => ({
        ...b,
        isOpened: false,
        isCorrect: null,
      }))
    );
    setActiveBoxIndex(null);
    setSelectedOption(null);
    setIsAnswerRevealed(false);
    setTotalScore(0);
    setIsGameFinished(false);
    setEncouragingPhrase('');
    onRestart();
  };

  const handleReturnToLibrary = () => {
    sound.playClick();
    if (onBackToLibrary) {
      onBackToLibrary();
    } else {
      onRestart();
    }
  };

  const openedCount = boxes.filter((b) => b.isOpened).length;
  const correctCount = boxes.filter((b) => b.isCorrect === true).length;
  const allOpened = boxes.length > 0 && boxes.every((b) => b.isOpened);
  const allCorrect = allOpened && boxes.every((b) => b.isCorrect === true);

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto py-2 relative">
      
      {/* Top Controls & Scoreboard */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-50 border border-amber-200 text-amber-600 rounded-xl">
            <Package className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">مغامرة الصندوق الغامض</h3>
            <p className="text-xs text-slate-500">اختر صندوقاً لكشف السؤال الذهبي وحصد النقاط</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-amber-50 px-4 py-2 rounded-xl border border-amber-200">
            <Award className="w-5 h-5 text-amber-600" />
            <span className="text-xs font-bold text-slate-600">مجموع نقاط الفصل:</span>
            <span className="text-lg font-black text-amber-700 font-mono">{totalScore}</span>
          </div>

          <div className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-2 rounded-xl">
            الصناديق المفتوحة: <span className="text-indigo-600 font-mono">{openedCount} / {boxes.length}</span>
          </div>

          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>إعادة تعبئة الصناديق</span>
          </button>
        </div>
      </div>

      {/* Boxes Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6">
        {boxes.map((box, index) => {
          return (
            <button
              key={box.id}
              onClick={() => handleOpenBox(index)}
              disabled={box.isOpened || isGameFinished}
              className={`relative h-44 rounded-2xl border-2 transition-all duration-300 flex flex-col items-center justify-center gap-2 p-4 cursor-pointer select-none group ${
                box.isOpened
                  ? box.isCorrect
                    ? 'bg-emerald-50/70 border-emerald-300 text-emerald-800 shadow-xs'
                    : 'bg-slate-100 border-slate-300 text-slate-400 opacity-70'
                  : 'bg-gradient-to-b from-amber-400 via-amber-500 to-amber-600 border-amber-300 text-white shadow-md hover:shadow-lg hover:-translate-y-1.5 active:scale-95'
              }`}
            >
              {/* Box Number Badge */}
              <div className="absolute top-2.5 right-2.5 w-7 h-7 rounded-lg bg-black/20 flex items-center justify-center text-xs font-black font-mono">
                #{box.id}
              </div>

              {/* Box Icon or Result */}
              {box.isOpened ? (
                <div className="flex flex-col items-center gap-1">
                  {box.isCorrect ? (
                    <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-md animate-bounce">
                      <Check className="w-7 h-7 stroke-[3]" />
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-slate-300 text-slate-600 flex items-center justify-center">
                      <X className="w-7 h-7 stroke-[3]" />
                    </div>
                  )}
                  <span className="text-xs font-bold mt-1">
                    {box.isCorrect ? `+${box.bonusPoints} نقطة` : 'مفتوح'}
                  </span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 transition-transform">
                    🎁
                  </div>
                  <span className="text-sm font-black tracking-wide drop-shadow-xs">
                    صندوق رقم {box.id}
                  </span>
                  <span className="text-[11px] font-bold text-amber-100 bg-black/20 px-2 py-0.5 rounded-full">
                    مفاجأة {box.bonusPoints} نقطة
                  </span>
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Question Modal on Smartboard */}
      {activeBox !== null && currentQuestion && !isGameFinished && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-100 flex flex-col gap-6 relative">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-amber-100 text-amber-800 text-xs font-bold rounded-lg flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  الصندوق رقم {activeBox.id}
                </span>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-md">
                  القيمة: {activeBox.bonusPoints} نقطة
                </span>
              </div>
              <button
                onClick={handleCloseQuestionModal}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Question Text */}
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 leading-relaxed text-right">
              {currentQuestion.text}
            </h3>

            {/* Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {(currentQuestion.options && currentQuestion.options.length > 0
                ? currentQuestion.options
                : ['نعم', 'لا', 'ممكن', 'غير ذلك']
              ).map((opt, idx) => {
                const isSelected = selectedOption === opt;
                const isCorrect = String(opt).trim() === String(currentQuestion.correctAnswer).trim();

                let style = 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800';
                if (isAnswerRevealed) {
                  if (isCorrect) {
                    style = 'bg-emerald-500 text-white border-emerald-600 shadow-md font-bold';
                  } else if (isSelected) {
                    style = 'bg-rose-500 text-white border-rose-600 shadow-sm';
                  } else {
                    style = 'bg-slate-100/70 text-slate-400 opacity-60 border-slate-200';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(opt)}
                    disabled={isAnswerRevealed}
                    className={`p-4 rounded-xl border text-right font-bold text-base transition-all duration-200 flex items-center justify-between gap-2 cursor-pointer ${style}`}
                  >
                    <span>{opt}</span>
                    <div className="w-7 h-7 rounded-md bg-black/10 flex items-center justify-center text-xs font-mono">
                      {['أ', 'ب', 'ج', 'د'][idx] || idx + 1}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Explanation and feedback */}
            {isAnswerRevealed && (
              <AnswerFeedbackBanner
                isCorrect={String(selectedOption).trim() === String(currentQuestion.correctAnswer).trim()}
                phrase={boxFeedbackPhrase}
                correctAnswerText={currentQuestion.correctAnswer}
                explanation={currentQuestion.explanation}
                onNext={handleCloseQuestionModal}
                nextButtonLabel={allOpened ? 'عرض الاحتفال والنتيجة الكبرى 🎉' : 'العودة للصناديق'}
              />
            )}

          </div>
        </div>
      )}

      {/* GRAND FINAL CELEBRATION MODAL IN CENTER OF SCREEN */}
      {isGameFinished && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          
          {/* Celebratory Modal Card */}
          <div className={`relative max-w-xl w-full rounded-3xl p-8 sm:p-10 shadow-2xl border-4 flex flex-col items-center text-center overflow-hidden animate-scale-up ${
            allCorrect
              ? 'bg-gradient-to-b from-amber-50 via-yellow-50 to-orange-50 border-amber-400 shadow-amber-500/30'
              : 'bg-gradient-to-b from-amber-50 via-white to-sky-50 border-amber-300 shadow-indigo-500/20'
          }`}>
            
            {/* Animated Floating Star Background Accents */}
            <div className="absolute top-4 left-6 text-amber-400 text-2xl animate-spin pointer-events-none opacity-80" style={{ animationDuration: '6s' }}>
              ✨
            </div>
            <div className="absolute top-8 right-8 text-amber-500 text-3xl animate-bounce pointer-events-none opacity-80">
              ⭐
            </div>
            <div className="absolute bottom-6 left-10 text-yellow-400 text-xl animate-pulse pointer-events-none opacity-70">
              🌟
            </div>
            <div className="absolute bottom-10 right-12 text-amber-400 text-2xl animate-bounce pointer-events-none opacity-70" style={{ animationDelay: '0.4s' }}>
              ✨
            </div>

            {/* Main Trophy / Crown Icon with Twinkling Stars */}
            <div className="relative mb-4">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-amber-400 via-yellow-400 to-amber-500 text-amber-950 flex items-center justify-center text-5xl sm:text-6xl shadow-xl ring-8 ring-amber-200/70 animate-bounce">
                {allCorrect ? '🏆' : '🎁'}
              </div>
              <div className="absolute -top-2 -right-2 text-2xl animate-pulse">
                🌟
              </div>
              <div className="absolute -bottom-2 -left-2 text-2xl animate-pulse" style={{ animationDelay: '0.3s' }}>
                ✨
              </div>
            </div>

            {/* Special Badge if 100% correct */}
            {allCorrect && (
              <span className="text-xs font-black tracking-widest uppercase bg-amber-400/90 text-amber-950 px-4 py-1.5 rounded-full mb-3 shadow-sm flex items-center gap-1.5">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span>أداء أسطوري ١٠٠٪ دون أي خطأ</span>
                <Star className="w-3.5 h-3.5 fill-current" />
              </span>
            )}

            {/* Main Encouraging Heading Phrase */}
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 mb-2 leading-tight tracking-tight drop-shadow-2xs">
              {encouragingPhrase || (allCorrect ? 'إجابات كاملة! أداء استثنائي 🏆🌟' : 'رائع! أبدعتم اليوم 🌟')}
            </h2>

            <p className="text-sm sm:text-base font-bold text-slate-600 mb-6 max-w-md">
              تم فتح جميع الصناديق واختتام مغامرة التحدي بنجاح وتألق كبير من الفصل!
            </p>

            {/* Prominent Score Card */}
            <div className="w-full bg-white/90 border-2 border-amber-200/90 rounded-2xl p-5 shadow-inner mb-8 flex items-center justify-around gap-4">
              <div className="text-center">
                <span className="text-xs font-black text-slate-500 block mb-1">
                  مجموع النقاط النهائي
                </span>
                <span className="text-3xl sm:text-4xl font-black font-mono text-amber-600 drop-shadow-xs">
                  {totalScore} <span className="text-lg">نقطة</span>
                </span>
              </div>

              <div className="w-px h-12 bg-amber-200" />

              <div className="text-center">
                <span className="text-xs font-black text-slate-500 block mb-1">
                  الإجابات الصحيحة
                </span>
                <span className="text-2xl sm:text-3xl font-black font-mono text-emerald-600">
                  {correctCount} <span className="text-base font-normal text-slate-400">/ {boxes.length}</span>
                </span>
              </div>
            </div>

            {/* Action Buttons: Play Again & Return to Library */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 w-full">
              <button
                onClick={handleReset}
                className="w-full sm:w-auto px-7 py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 active:scale-98 text-white font-black text-base rounded-2xl shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all tactile-btn"
              >
                <RotateCcw className="w-5 h-5 stroke-[2.5]" />
                <span>العب مرة أخرى</span>
              </button>

              <button
                onClick={handleReturnToLibrary}
                className="w-full sm:w-auto px-7 py-4 bg-white hover:bg-slate-100 active:scale-98 text-slate-800 border-2 border-slate-300 font-black text-base rounded-2xl shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-all tactile-btn"
              >
                <ArrowRight className="w-5 h-5 stroke-[2.5]" />
                <span>العودة إلى مكتبة الألعاب</span>
              </button>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
