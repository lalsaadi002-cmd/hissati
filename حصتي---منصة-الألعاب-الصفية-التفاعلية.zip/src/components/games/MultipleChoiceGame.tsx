import React, { useState } from 'react';
import { Question } from '../../types';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti, fireGrandWinnerConfetti } from '../../utils/confetti';
import { CheckCircle2, RotateCcw, Flame, HelpCircle, EyeOff, Award, ChevronLeft } from 'lucide-react';
import { getRandomFeedback } from '../../utils/feedback';
import { AnswerFeedbackBanner } from '../common/AnswerFeedbackBanner';

interface MultipleChoiceGameProps {
  questions: Question[];
  onRestart: () => void;
}

export const MultipleChoiceGame: React.FC<MultipleChoiceGameProps> = ({
  questions,
  onRestart,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isRevealed, setIsRevealed] = useState(false);
  const [feedbackPhrase, setFeedbackPhrase] = useState('');
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [eliminatedOptions, setEliminatedOptions] = useState<string[]>([]);
  const [used5050, setUsed5050] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);

  const currentQ = questions[currentIndex];

  const handleSelectOption = (opt: string) => {
    if (isRevealed || isGameOver) return;
    sound.playClick();
    setSelectedOption(opt);
    setIsRevealed(true);

    const isCorrect = String(opt).trim() === String(currentQ.correctAnswer).trim();
    setFeedbackPhrase(getRandomFeedback(isCorrect));

    if (isCorrect) {
      sound.playCorrect();
      fireCelebrationConfetti();
      const streakBonus = streak * 2;
      const pointsEarned = (currentQ.points || 10) + streakBonus;
      setScore((prev) => prev + pointsEarned);
      setStreak((prev) => prev + 1);
    } else {
      sound.playIncorrect();
      setStreak(0);
    }
  };

  const handleNext = () => {
    sound.playClick();
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsRevealed(false);
      setEliminatedOptions([]);
    } else {
      setIsGameOver(true);
      sound.playWin();
      fireGrandWinnerConfetti();
    }
  };

  const handle5050 = () => {
    if (used5050 || isRevealed || !currentQ.options || currentQ.options.length < 4) return;
    sound.playClick();
    setUsed5050(true);
    const incorrect = currentQ.options.filter(
      (opt) => String(opt).trim() !== String(currentQ.correctAnswer).trim()
    );
    // Shuffle and pick 2 to eliminate
    const toEliminate = incorrect.slice(0, 2);
    setEliminatedOptions(toEliminate);
  };

  const handleReset = () => {
    sound.playClick();
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsRevealed(false);
    setScore(0);
    setStreak(0);
    setEliminatedOptions([]);
    setUsed5050(false);
    setIsGameOver(false);
    onRestart();
  };

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto py-2">
      
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-600 rounded-xl">
            <CheckCircle2 className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">تحدي الاختيار الذكي</h3>
            <p className="text-xs text-slate-500">اختر الإجابة الصحيحة وحافظ على سلسلة الإجابات</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Streak indicator */}
          <div className="flex items-center gap-1.5 bg-orange-50 text-orange-700 px-3 py-1.5 rounded-xl border border-orange-200 text-xs font-bold">
            <Flame className="w-4 h-4 fill-orange-500 text-orange-500 animate-pulse" />
            <span>السلسلة:</span>
            <span className="font-mono text-sm">{streak} 🔥</span>
          </div>

          {/* Score */}
          <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 px-3.5 py-1.5 rounded-xl border border-emerald-200 text-xs font-bold">
            <Award className="w-4 h-4" />
            <span>النقاط:</span>
            <span className="font-mono text-sm font-black">{score}</span>
          </div>

          <button
            onClick={handleReset}
            className="p-2 text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            title="إعادة التحدي"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Game Over Screen */}
      {isGameOver ? (
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-md text-center flex flex-col items-center gap-4 animate-fade-in">
          <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-4xl shadow-inner">
            🏆
          </div>
          <h2 className="text-3xl font-black text-slate-900">
            أكملت جميع الأسئلة بنجاح!
          </h2>
          <p className="text-slate-600 font-medium">
            مجموع نقاطك النهائية في هذا التحدي:
          </p>
          <div className="text-5xl font-black text-emerald-600 font-mono my-2">
            {score} نقطة
          </div>
          <button
            onClick={handleReset}
            className="px-8 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md cursor-pointer transition-colors"
          >
            بدء التحدي من جديد
          </button>
        </div>
      ) : (
        /* Question Arena */
        currentQ && (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-sm flex flex-col gap-6">
            
            {/* Question Header & 50:50 Lifeline */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <span className="text-xs font-bold text-slate-500">
                السؤال {currentIndex + 1} من {questions.length}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={handle5050}
                  disabled={used5050 || isRevealed}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    used5050
                      ? 'bg-slate-100 text-slate-400 line-through cursor-not-allowed'
                      : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200'
                  }`}
                  title="حذف خيارين خاطئين"
                >
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>وسيلة مساعدة (50:50)</span>
                </button>
              </div>
            </div>

            {/* Question Text */}
            <div className="min-h-[90px] flex items-center justify-center text-center px-4">
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 leading-relaxed text-wrap-balance">
                {currentQ.text}
              </h2>
            </div>

            {/* 4 Choices */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {(currentQ.options || ['أ', 'ب', 'ج', 'د']).map((opt, idx) => {
                const isEliminated = eliminatedOptions.includes(opt);
                const isSelected = selectedOption === opt;
                const isCorrect = String(opt).trim() === String(currentQ.correctAnswer).trim();

                if (isEliminated) {
                  return (
                    <div
                      key={idx}
                      className="p-5 rounded-2xl border border-dashed border-slate-200 bg-slate-50/50 opacity-30 flex items-center justify-between"
                    >
                      <span className="text-slate-400 font-medium">تم استبعاد هذا الخيار</span>
                      <span className="text-xs text-slate-400 font-mono">✕</span>
                    </div>
                  );
                }

                let style = 'bg-slate-50 hover:bg-slate-100/90 border-slate-200 text-slate-800 hover:border-indigo-300';
                if (isRevealed) {
                  if (isCorrect) {
                    style = 'bg-emerald-500 text-white border-emerald-600 shadow-md scale-[1.01]';
                  } else if (isSelected) {
                    style = 'bg-rose-500 text-white border-rose-600 shadow-sm';
                  } else {
                    style = 'bg-slate-100 text-slate-400 border-slate-200 opacity-60';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(opt)}
                    disabled={isRevealed}
                    className={`p-5 rounded-2xl border-2 text-right font-bold text-lg transition-all duration-200 flex items-center justify-between gap-4 cursor-pointer select-none ${style}`}
                  >
                    <span className="flex-1">{opt}</span>
                    <div className="w-9 h-9 rounded-xl bg-black/10 flex items-center justify-center text-sm font-mono shrink-0">
                      {['أ', 'ب', 'ج', 'د'][idx] || idx + 1}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Explanation & Next Button with Feedback */}
            {isRevealed && (
              <div className="mt-2">
                <AnswerFeedbackBanner
                  isCorrect={String(selectedOption).trim() === String(currentQ.correctAnswer).trim()}
                  phrase={feedbackPhrase}
                  correctAnswerText={currentQ.correctAnswer}
                  explanation={currentQ.explanation}
                  onNext={handleNext}
                  nextButtonLabel={currentIndex < questions.length - 1 ? 'السؤال التالي' : 'عرض النتيجة النهائية'}
                />
              </div>
            )}

          </div>
        )
      )}

    </div>
  );
};
