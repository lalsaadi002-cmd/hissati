import React, { useState } from 'react';
import { Question } from '../../types';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti } from '../../utils/confetti';
import { Ticket, RotateCcw, Check, Users, Sparkles, BarChart2, Heart, Award } from 'lucide-react';

interface ExitTicketGameProps {
  questions: Question[];
  onRestart: () => void;
}

export const ExitTicketGame: React.FC<ExitTicketGameProps> = ({
  questions,
  onRestart,
}) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  
  // Comprehension self-eval votes tally
  const [votes, setVotes] = useState({
    mastered: 18,   // فهمت بامتياز
    good: 7,        // فهمت جيداً
    needHelp: 2,    // أحتاج مراجعة
  });

  const [hasVoted, setHasVoted] = useState<string | null>(null);

  // Quick exit question responses
  const [questionVotes, setQuestionVotes] = useState<Record<number, number>>({
    0: 15,
    1: 4,
    2: 3,
    3: 1,
  });

  const currentQ = questions[currentQuestionIndex] || {
    id: 'exit-default',
    text: 'ما هو أهم مفهوم استوعبته اليوم في الحصة؟',
    options: ['المفهوم الأساسي وتطبيقاته', 'أمثلة وتجارب الدرس', 'المعلومات الإثرائية', 'أحتاج توضيحاً إضافياً'],
    correctAnswer: 'المفهوم الأساسي وتطبيقاته',
  };

  const totalComprehensionVotes = votes.mastered + votes.good + votes.needHelp;
  const masteredPercent = Math.round((votes.mastered / totalComprehensionVotes) * 100);
  const goodPercent = Math.round((votes.good / totalComprehensionVotes) * 100);
  const helpPercent = Math.round((votes.needHelp / totalComprehensionVotes) * 100);

  const handleVoteComprehension = (type: 'mastered' | 'good' | 'needHelp') => {
    sound.playClick();
    sound.playCorrect();
    fireCelebrationConfetti();
    setVotes((prev) => ({
      ...prev,
      [type]: prev[type] + 1,
    }));
    setHasVoted(type);
  };

  const handleVoteOption = (index: number) => {
    sound.playClick();
    setQuestionVotes((prev) => ({
      ...prev,
      [index]: (prev[index] || 0) + 1,
    }));
  };

  const handleReset = () => {
    sound.playClick();
    setVotes({ mastered: 0, good: 0, needHelp: 0 });
    setQuestionVotes({});
    setHasVoted(null);
    onRestart();
  };

  const totalQuestionVotes = Object.values(questionVotes).reduce((a, b) => a + b, 0);

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto py-2">
      
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-teal-50 border border-teal-200 text-teal-600 rounded-xl">
            <Ticket className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">تذكرة الخروج والتقويم الختامي</h3>
            <p className="text-xs text-slate-500">تقييم سريع ومباشر لقياس مدى استيعاب الطلاب لنواتج تعلم الحصة</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-teal-50 border border-teal-200 px-3.5 py-1.5 rounded-xl text-xs font-bold text-teal-800">
            <Users className="w-4 h-4" />
            <span>إجمالي الاستجابات:</span>
            <span className="font-mono text-base font-black">{totalComprehensionVotes}</span>
          </div>

          <button
            onClick={handleReset}
            className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>تصفير الاستجابات</span>
          </button>
        </div>
      </div>

      {/* Part 1: Comprehension Pulse Bar */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col gap-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h4 className="font-bold text-base text-slate-800 flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-indigo-600" />
            <span>مقياس الفهم الذاتي للطلاب في ختام الحصة</span>
          </h4>
          <span className="text-xs font-bold text-slate-400">انقر لتسجيل صوت طالب</span>
        </div>

        {/* 3 Voting Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          <button
            onClick={() => handleVoteComprehension('mastered')}
            className={`p-5 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 text-center cursor-pointer ${
              hasVoted === 'mastered'
                ? 'bg-emerald-50 border-emerald-500 shadow-md ring-2 ring-emerald-300'
                : 'bg-slate-50 hover:bg-emerald-50/50 border-slate-200 hover:border-emerald-300'
            }`}
          >
            <span className="text-3xl">🌟</span>
            <span className="font-bold text-slate-900 text-sm">فهمت تماماً وأستطيع الشرح</span>
            <span className="text-2xl font-black text-emerald-600 font-mono mt-1">
              {votes.mastered} <span className="text-xs text-slate-400 font-sans">طالب</span>
            </span>
          </button>

          <button
            onClick={() => handleVoteComprehension('good')}
            className={`p-5 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 text-center cursor-pointer ${
              hasVoted === 'good'
                ? 'bg-blue-50 border-blue-500 shadow-md ring-2 ring-blue-300'
                : 'bg-slate-50 hover:bg-blue-50/50 border-slate-200 hover:border-blue-300'
            }`}
          >
            <span className="text-3xl">👍</span>
            <span className="font-bold text-slate-900 text-sm">فهمت معظم الدرس وبحاجة لتطبيق</span>
            <span className="text-2xl font-black text-blue-600 font-mono mt-1">
              {votes.good} <span className="text-xs text-slate-400 font-sans">طالب</span>
            </span>
          </button>

          <button
            onClick={() => handleVoteComprehension('needHelp')}
            className={`p-5 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 text-center cursor-pointer ${
              hasVoted === 'needHelp'
                ? 'bg-amber-50 border-amber-500 shadow-md ring-2 ring-amber-300'
                : 'bg-slate-50 hover:bg-amber-50/50 border-slate-200 hover:border-amber-300'
            }`}
          >
            <span className="text-3xl">💡</span>
            <span className="font-bold text-slate-900 text-sm">لدي تساؤلات وأحتاج دعماً</span>
            <span className="text-2xl font-black text-amber-600 font-mono mt-1">
              {votes.needHelp} <span className="text-xs text-slate-400 font-sans">طالب</span>
            </span>
          </button>

        </div>

        {/* Live Visual Ratio Progress Bar */}
        <div className="space-y-2 pt-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>نسبة الاستيعاب الكلية للفصل:</span>
            <span className="font-mono text-emerald-600 font-black">{masteredPercent}% استيعاب كامل</span>
          </div>

          <div className="h-5 bg-slate-100 rounded-full overflow-hidden flex p-0.5 border border-slate-200/80">
            <div
              style={{ width: `${masteredPercent}%` }}
              className="bg-emerald-500 rounded-full transition-all duration-500"
              title={`فهم كامل: ${masteredPercent}%`}
            />
            <div
              style={{ width: `${goodPercent}%` }}
              className="bg-blue-500 rounded-full transition-all duration-500 mx-0.5"
              title={`فهم جيد: ${goodPercent}%`}
            />
            <div
              style={{ width: `${helpPercent}%` }}
              className="bg-amber-500 rounded-full transition-all duration-500"
              title={`بحاجة دعم: ${helpPercent}%`}
            />
          </div>
        </div>
      </div>

      {/* Part 2: Quick Final Reflection Question */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col gap-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-md">
            سؤال التثبيت الختامي
          </span>
          {questions.length > 1 && (
            <div className="flex items-center gap-1">
              {questions.map((_, qIdx) => (
                <button
                  key={qIdx}
                  onClick={() => setCurrentQuestionIndex(qIdx)}
                  className={`w-7 h-7 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    currentQuestionIndex === qIdx
                      ? 'bg-teal-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {qIdx + 1}
                </button>
              ))}
            </div>
          )}
        </div>

        <h3 className="text-xl font-bold text-slate-900 leading-relaxed text-right">
          {currentQ.text}
        </h3>

        {/* Options with vote counts */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {(currentQ.options || ['نعم', 'لا']).map((opt, oIdx) => {
            const votesCount = questionVotes[oIdx] || 0;
            const percentage = totalQuestionVotes > 0 ? Math.round((votesCount / totalQuestionVotes) * 100) : 0;

            return (
              <button
                key={oIdx}
                onClick={() => handleVoteOption(oIdx)}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-teal-50/50 hover:border-teal-300 transition-all text-right cursor-pointer flex flex-col gap-2 relative overflow-hidden"
              >
                {/* Background vote progress bar */}
                <div
                  className="absolute inset-y-0 right-0 bg-teal-100/40 pointer-events-none transition-all duration-300"
                  style={{ width: `${percentage}%` }}
                />

                <div className="flex items-center justify-between relative z-10">
                  <span className="font-bold text-slate-900 text-sm flex-1">{opt}</span>
                  <span className="font-mono font-black text-xs text-teal-700 bg-white px-2 py-0.5 rounded shadow-xs border border-teal-100">
                    {votesCount} صوت ({percentage}%)
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

    </div>
  );
};
