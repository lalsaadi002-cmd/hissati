import React, { useState } from 'react';
import { Question } from '../../types';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti } from '../../utils/confetti';
import { Layers, RotateCcw, Check, Sparkles, HelpCircle } from 'lucide-react';

interface FlipCardGameProps {
  questions: Question[];
  onRestart: () => void;
}

export const FlipCardGame: React.FC<FlipCardGameProps> = ({ questions, onRestart }) => {
  const [flippedCards, setFlippedCards] = useState<Record<number, boolean>>({});
  const [solvedCards, setSolvedCards] = useState<Record<number, boolean>>({});
  const [showAnswerFor, setShowAnswerFor] = useState<Record<number, boolean>>({});

  const handleFlip = (idx: number) => {
    sound.playCardFlip();
    setFlippedCards((prev) => ({
      ...prev,
      [idx]: !prev[idx],
    }));
  };

  const handleMarkSolved = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playCorrect();
    fireCelebrationConfetti();
    setSolvedCards((prev) => ({
      ...prev,
      [idx]: true,
    }));
  };

  const handleToggleAnswer = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playClick();
    setShowAnswerFor((prev) => ({
      ...prev,
      [idx]: !prev[idx],
    }));
  };

  const handleReset = () => {
    sound.playClick();
    setFlippedCards({});
    setSolvedCards({});
    setShowAnswerFor({});
    onRestart();
  };

  const solvedCount = Object.values(solvedCards).filter(Boolean).length;

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto py-2">
      
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-violet-50 border border-violet-200 text-violet-600 rounded-xl">
            <Layers className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">بطاقات التحدي ثلاثية الأبعاد</h3>
            <p className="text-xs text-slate-500">اقلب البطاقة لاكتشاف التحدي واختبار مهارات التفكير</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-violet-50 border border-violet-200 px-4 py-1.5 rounded-xl text-xs font-bold text-violet-800">
            البطاقات المكتملة: <span className="font-mono text-sm">{solvedCount} / {questions.length}</span>
          </div>

          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>إعادة قلب جميع البطاقات</span>
          </button>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {questions.map((q, idx) => {
          const isFlipped = flippedCards[idx] || false;
          const isSolved = solvedCards[idx] || false;
          const isAnswerShown = showAnswerFor[idx] || false;

          return (
            <div
              key={q.id}
              onClick={() => handleFlip(idx)}
              className="h-80 perspective-1000 cursor-pointer group select-none"
            >
              <div
                className={`relative w-full h-full duration-500 transform-style-3d rounded-3xl transition-transform shadow-sm hover:shadow-md ${
                  isFlipped ? 'rotate-y-180' : ''
                }`}
              >
                
                {/* FRONT FACE */}
                <div
                  className={`absolute inset-0 backface-hidden rounded-3xl p-6 border-2 flex flex-col justify-between items-center text-center transition-all ${
                    isSolved
                      ? 'bg-emerald-50 border-emerald-300'
                      : 'bg-gradient-to-br from-violet-600 via-indigo-600 to-purple-700 border-violet-400 text-white'
                  }`}
                >
                  <div className="w-full flex items-center justify-between">
                    <span className={`text-xs font-black font-mono px-2.5 py-1 rounded-lg ${isSolved ? 'bg-emerald-200 text-emerald-800' : 'bg-black/20 text-white'}`}>
                      بطاقة #{idx + 1}
                    </span>
                    {isSolved ? (
                      <span className="text-xs font-bold bg-emerald-500 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Check className="w-3 h-3 stroke-[3]" /> تم الإنجاز
                      </span>
                    ) : (
                      <Sparkles className="w-5 h-5 text-amber-300" />
                    )}
                  </div>

                  <div className="flex flex-col items-center gap-2">
                    <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-xs flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                      {isSolved ? '✅' : '🃏'}
                    </div>
                    <span className="text-xl font-bold tracking-tight">
                      {isSolved ? 'أحسنت الإجابة!' : 'انقر لكشف السؤال'}
                    </span>
                    <span className="text-xs text-white/80">
                      تحدي {q.points || 10} نقاط
                    </span>
                  </div>

                  <span className="text-xs font-semibold bg-white/15 px-3 py-1 rounded-full">
                    اقلب للمواجهة ↻
                  </span>
                </div>

                {/* BACK FACE */}
                <div className="absolute inset-0 backface-hidden rotate-y-180 rounded-3xl p-6 bg-white border-2 border-slate-200 text-slate-800 flex flex-col justify-between shadow-lg overflow-y-auto">
                  
                  <div>
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3">
                      <span className="text-xs font-bold text-violet-600">
                        سؤال #{idx + 1}
                      </span>
                      <span className="text-[11px] text-slate-400 font-semibold">
                        انقر للقلب مجدداً
                      </span>
                    </div>

                    <p className="text-base font-bold text-slate-900 leading-relaxed text-right mb-3">
                      {q.text}
                    </p>

                    {q.options && q.options.length > 0 && !isAnswerShown && (
                      <div className="space-y-1.5 text-right">
                        {q.options.map((opt, oIdx) => (
                          <div
                            key={oIdx}
                            className="text-xs bg-slate-50 border border-slate-200/80 p-2 rounded-lg text-slate-700 font-medium"
                          >
                            {opt}
                          </div>
                        ))}
                      </div>
                    )}

                    {isAnswerShown && (
                      <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-right animate-fade-in">
                        <span className="text-xs font-bold text-emerald-800 block mb-0.5">
                          💡 الإجابة الصحيحة:
                        </span>
                        <p className="text-sm font-black text-emerald-950">
                          {q.correctAnswer}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Actions on Back */}
                  <div className="flex items-center justify-between pt-3 border-t border-slate-100 mt-2 gap-2" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={(e) => handleToggleAnswer(idx, e)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                    >
                      {isAnswerShown ? 'إخفاء الحل' : 'كشف الحل'}
                    </button>

                    <button
                      onClick={(e) => handleMarkSolved(idx, e)}
                      className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 cursor-pointer ${
                        isSolved
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{isSolved ? 'مكتمل' : 'تمت الإجابة'}</span>
                    </button>
                  </div>

                </div>

              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
