import React, { useState, useEffect, useRef } from 'react';
import { Question, StudentListGroup } from '../../types';
import { sound } from '../../services/soundService';
import { fireGrandWinnerConfetti, fireCelebrationConfetti } from '../../utils/confetti';
import {
  CircleDashed,
  Users,
  RotateCcw,
  Shuffle,
  Sparkles,
  HelpCircle,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  ClipboardList,
  FolderPlus,
  UserX,
  UserCheck,
} from 'lucide-react';
import { storage } from '../../services/storageService';
import { getRandomFeedback } from '../../utils/feedback';
import { AnswerFeedbackBanner } from '../common/AnswerFeedbackBanner';

interface WheelOfNamesGameProps {
  questions?: Question[];
  config?: {
    studentNames?: string[];
  };
  onRestart: () => void;
}

const WHEEL_COLORS = [
  '#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6',
  '#06b6d4', '#f97316', '#14b8a6', '#6366f1', '#e11d48',
  '#84cc16', '#a855f7'
];

export const WheelOfNamesGame: React.FC<WheelOfNamesGameProps> = ({
  questions = [],
  config,
  onRestart,
}) => {
  // Saved Student Lists from storage
  const [lists, setLists] = useState<StudentListGroup[]>(() => storage.getStudentLists());
  
  // Active selected list ID
  const [activeListId, setActiveListId] = useState<string>(() => {
    const savedActiveId = storage.getActiveStudentListId();
    if (savedActiveId && lists.some((l) => l.id === savedActiveId)) {
      return savedActiveId;
    }
    return lists.length > 0 ? lists[0].id : '';
  });

  // Current active list
  const activeList = lists.find((l) => l.id === activeListId) || lists[0] || null;

  // Active names in the wheel round (can be temporarily removed from current round)
  const [names, setNames] = useState<string[]>(() => {
    if (config?.studentNames && config.studentNames.length > 0) {
      return config.studentNames;
    }
    return activeList ? activeList.students : [];
  });

  // Modal controls
  const [showRosterModal, setShowRosterModal] = useState(false);
  const [showBulkPaste, setShowBulkPaste] = useState(false);
  const [bulkInput, setBulkInput] = useState('');
  const [newStudentName, setNewStudentName] = useState('');
  const [editingStudentIndex, setEditingStudentIndex] = useState<number | null>(null);
  const [editingStudentValue, setEditingStudentValue] = useState('');

  // New list creation
  const [isCreatingList, setIsCreatingList] = useState(false);
  const [newListName, setNewListName] = useState('');

  // Spin state
  const [isSpinning, setIsSpinning] = useState(false);
  const [selectedWinner, setSelectedWinner] = useState<string | null>(null);

  // Question challenge for winner
  const [showQuestionChallenge, setShowQuestionChallenge] = useState(false);
  const [challengeQuestionIndex, setChallengeQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isChallengeRevealed, setIsChallengeRevealed] = useState(false);

  // Removed from round banner notice
  const [roundNotice, setRoundNotice] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rotationAngleRef = useRef<number>(0);
  const animationFrameRef = useRef<number | null>(null);

  // Sync when active list switches
  const handleSwitchList = (listId: string) => {
    sound.playClick();
    setActiveListId(listId);
    storage.setActiveStudentListId(listId);
    const target = lists.find((l) => l.id === listId);
    if (target) {
      setNames([...target.students]);
      setRoundNotice(null);
    }
  };

  // Draw wheel on canvas
  const drawWheel = (angle: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(centerX, centerY) - 15;

    ctx.clearRect(0, 0, width, height);

    if (names.length === 0) {
      ctx.fillStyle = '#64748b';
      ctx.font = 'bold 16px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('لا توجد أسماء في العجلة حالياً', centerX, centerY - 12);
      ctx.font = 'normal 13px Cairo, sans-serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('أضف أسماء أو أعد تعيين الجولة', centerX, centerY + 14);
      return;
    }

    const arcSize = (2 * Math.PI) / names.length;

    names.forEach((name, i) => {
      const sliceStart = angle + i * arcSize;
      const sliceEnd = sliceStart + arcSize;

      // Slice background
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, sliceStart, sliceEnd);
      ctx.closePath();
      ctx.fillStyle = WHEEL_COLORS[i % WHEEL_COLORS.length];
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      // Text label
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(sliceStart + arcSize / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px Cairo, sans-serif';
      ctx.shadowColor = 'rgba(0,0,0,0.4)';
      ctx.shadowBlur = 3;
      
      const displayName = name.length > 15 ? name.substring(0, 15) + '...' : name;
      ctx.fillText(displayName, radius - 20, 5);
      ctx.restore();
    });

    // Center hub
    ctx.beginPath();
    ctx.arc(centerX, centerY, 34, 0, 2 * Math.PI);
    ctx.fillStyle = '#1e293b';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#ffffff';
    ctx.stroke();

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 13px Cairo, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('حِصَّتِي', centerX, centerY);
  };

  useEffect(() => {
    drawWheel(rotationAngleRef.current);
  }, [names]);

  const spinWheel = () => {
    if (isSpinning || names.length === 0) return;
    sound.playClick();
    setIsSpinning(true);
    setSelectedWinner(null);
    setShowQuestionChallenge(false);
    setRoundNotice(null);

    // Random rotations: between 5 and 9 full turns + random slice offset
    const fullSpins = 6 + Math.random() * 4;
    const additionalAngle = Math.random() * (2 * Math.PI);
    const totalRotation = fullSpins * 2 * Math.PI + additionalAngle;

    const startAngle = rotationAngleRef.current;
    const duration = 4500; // 4.5 seconds
    const startTime = performance.now();

    let lastTickTime = 0;

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Ease out cubic
      const ease = 1 - Math.pow(1 - progress, 3.5);
      const currentAngle = startAngle + totalRotation * ease;
      rotationAngleRef.current = currentAngle;

      // Play tick sound every slice crossing
      if (currentTime - lastTickTime > 70 && progress < 0.9) {
        sound.playSpinTick();
        lastTickTime = currentTime;
      }

      drawWheel(currentAngle);

      if (progress < 1) {
        animationFrameRef.current = requestAnimationFrame(animate);
      } else {
        setIsSpinning(false);
        // Calculate which slice the needle (at top 3*PI/2) points to
        const normalizedAngle = (currentAngle % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);
        const arcSize = (2 * Math.PI) / names.length;
        const pointerAngle = (1.5 * Math.PI - normalizedAngle + 2 * Math.PI) % (2 * Math.PI);
        const winningIndex = Math.floor(pointerAngle / arcSize) % names.length;
        const winner = names[winningIndex];

        setSelectedWinner(winner);
        sound.playWin();
        fireGrandWinnerConfetti();
      }
    };

    animationFrameRef.current = requestAnimationFrame(animate);
  };

  const handleShuffle = () => {
    sound.playClick();
    const shuffled = [...names].sort(() => Math.random() - 0.5);
    setNames(shuffled);
  };

  // Reset current round back to full list
  const handleResetRound = () => {
    sound.playClick();
    if (activeList) {
      setNames([...activeList.students]);
    }
    setSelectedWinner(null);
    setRoundNotice(null);
  };

  // Action: Remove student from round
  const handleRemoveFromRound = () => {
    if (!selectedWinner) return;
    sound.playClick();
    const winnerToRemove = selectedWinner;
    const remaining = names.filter((n) => n !== winnerToRemove);
    setNames(remaining);
    setSelectedWinner(null);
    setRoundNotice(`تم استبعاد (${winnerToRemove}) من هذه الجولة حتى لا يتكرر اختيارها`);
    setTimeout(() => setRoundNotice(null), 4000);
  };

  // Action: Keep student in round
  const handleKeepInRound = () => {
    sound.playClick();
    setSelectedWinner(null);
  };

  // 1. Add single student to active list
  const handleAddSingleStudent = () => {
    const trimmed = newStudentName.trim();
    if (!trimmed || !activeList) return;
    sound.playClick();

    const updatedStudents = [...activeList.students, trimmed];
    const updatedLists = lists.map((l) =>
      l.id === activeList.id ? { ...l, students: updatedStudents } : l
    );

    setLists(updatedLists);
    storage.saveStudentLists(updatedLists);
    setNames((prev) => [...prev, trimmed]);
    setNewStudentName('');
  };

  // 2. Edit existing student
  const handleSaveEditStudent = (index: number) => {
    const trimmed = editingStudentValue.trim();
    if (!trimmed || !activeList) return;
    sound.playClick();

    const oldName = activeList.students[index];
    const updatedStudents = [...activeList.students];
    updatedStudents[index] = trimmed;

    const updatedLists = lists.map((l) =>
      l.id === activeList.id ? { ...l, students: updatedStudents } : l
    );

    setLists(updatedLists);
    storage.saveStudentLists(updatedLists);
    setNames((prev) => prev.map((n) => (n === oldName ? trimmed : n)));
    setEditingStudentIndex(null);
    setEditingStudentValue('');
  };

  // 3. Delete single student
  const handleDeleteStudent = (index: number) => {
    if (!activeList) return;
    sound.playClick();

    const studentToDelete = activeList.students[index];
    const updatedStudents = activeList.students.filter((_, idx) => idx !== index);

    const updatedLists = lists.map((l) =>
      l.id === activeList.id ? { ...l, students: updatedStudents } : l
    );

    setLists(updatedLists);
    storage.saveStudentLists(updatedLists);
    setNames((prev) => prev.filter((n) => n !== studentToDelete));
  };

  // 4. Clear all students in active list
  const handleClearAllStudents = () => {
    if (!activeList) return;
    if (!window.confirm('هل أنت متأكد من مسح جميع الأسماء في هذه القائمة؟')) return;
    sound.playClick();

    const updatedLists = lists.map((l) =>
      l.id === activeList.id ? { ...l, students: [] } : l
    );

    setLists(updatedLists);
    storage.saveStudentLists(updatedLists);
    setNames([]);
  };

  // 5. Bulk paste students
  const handleInsertBulkStudents = () => {
    if (!bulkInput.trim() || !activeList) return;
    sound.playClick();

    const lines = bulkInput
      .split('\n')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (lines.length === 0) return;

    // Merge with existing avoiding empty
    const updatedStudents = [...activeList.students, ...lines];
    const updatedLists = lists.map((l) =>
      l.id === activeList.id ? { ...l, students: updatedStudents } : l
    );

    setLists(updatedLists);
    storage.saveStudentLists(updatedLists);
    setNames((prev) => [...prev, ...lines]);
    setBulkInput('');
    setShowBulkPaste(false);
  };

  // 6. Create new named list
  const handleCreateNewList = () => {
    const trimmed = newListName.trim();
    if (!trimmed) return;
    sound.playClick();

    const newList: StudentListGroup = {
      id: `list-${Date.now()}`,
      name: trimmed,
      students: [],
      createdAt: Date.now(),
    };

    const updatedLists = [...lists, newList];
    setLists(updatedLists);
    storage.saveStudentLists(updatedLists);
    setActiveListId(newList.id);
    storage.setActiveStudentListId(newList.id);
    setNames([]);
    setNewListName('');
    setIsCreatingList(false);
  };

  // 7. Delete entire list
  const handleDeleteList = (listId: string) => {
    if (lists.length <= 1) {
      alert('يجب أن تبقى قائمة واحدة على الأقل');
      return;
    }
    if (!window.confirm('هل أنت متأكد من حذف هذه القائمة بالكامل؟')) return;
    sound.playClick();

    const updatedLists = lists.filter((l) => l.id !== listId);
    setLists(updatedLists);
    storage.saveStudentLists(updatedLists);

    if (activeListId === listId) {
      const nextList = updatedLists[0];
      setActiveListId(nextList.id);
      storage.setActiveStudentListId(nextList.id);
      setNames([...nextList.students]);
    }
  };

  // Question Challenge
  const handleStartQuestionChallenge = () => {
    sound.playClick();
    if (questions.length === 0) return;
    setChallengeQuestionIndex(Math.floor(Math.random() * questions.length));
    setSelectedAnswer(null);
    setIsChallengeRevealed(false);
    setShowQuestionChallenge(true);
  };

  const handleAnswerChallenge = (opt: string) => {
    if (isChallengeRevealed) return;
    sound.playClick();
    setSelectedAnswer(opt);
    setIsChallengeRevealed(true);

    const q = questions[challengeQuestionIndex];
    if (String(opt).trim() === String(q.correctAnswer).trim()) {
      sound.playCorrect();
      fireCelebrationConfetti();
    } else {
      sound.playIncorrect();
    }
  };

  return (
    <div className="flex flex-col gap-5 max-w-5xl mx-auto py-2">
      
      {/* Top Bar Controls & Roster Selector */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        
        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl">
            <CircleDashed className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">عجلة الأسماء الذكية</h3>
            <p className="text-xs text-slate-500">اختر طالباً عشوائياً للمشاركة والتفاعل الإيجابي</p>
          </div>
        </div>

        {/* List Switcher & Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          
          {/* Active List Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-100/90 border border-slate-200 rounded-xl px-3 py-1.5 shadow-2xs">
            <Users className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-bold text-slate-500">القائمة:</span>
            <select
              value={activeListId}
              onChange={(e) => handleSwitchList(e.target.value)}
              disabled={isSpinning}
              className="bg-transparent font-black text-xs sm:text-sm text-slate-800 cursor-pointer focus:outline-none"
            >
              {lists.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name} ({l.students.length} طالب)
                </option>
              ))}
            </select>
          </div>

          {/* Manage Roster Button */}
          <button
            onClick={() => setShowRosterModal(true)}
            className="flex items-center gap-1.5 text-xs font-black text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-3 py-2 rounded-xl transition-colors cursor-pointer"
          >
            <Users className="w-4 h-4" />
            <span>إدارة وتعديل الأسماء</span>
          </button>

          {/* Shuffle button */}
          <button
            onClick={handleShuffle}
            disabled={isSpinning || names.length <= 1}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors cursor-pointer disabled:opacity-50"
            title="خلط ترتيب الأسماء في العجلة"
          >
            <Shuffle className="w-4 h-4 text-amber-600" />
            <span className="hidden sm:inline">خلط عشوائي</span>
          </button>

          {/* Reset round button if some students were removed */}
          {activeList && names.length !== activeList.students.length && (
            <button
              onClick={handleResetRound}
              className="flex items-center gap-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3 py-2 rounded-xl transition-colors cursor-pointer"
              title="إعادة تعيين الجولة وإرجاع جميع الأسماء"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إرجاع الجميع ({activeList.students.length})</span>
            </button>
          )}

        </div>
      </div>

      {/* Temporary Notice Banner (e.g. after removing student from round) */}
      {roundNotice && (
        <div className="bg-amber-50 border-2 border-amber-300 text-amber-900 rounded-2xl px-5 py-3 text-xs sm:text-sm font-bold flex items-center justify-between animate-fade-in shadow-2xs">
          <span>{roundNotice}</span>
          <button
            onClick={() => setRoundNotice(null)}
            className="text-amber-700 hover:text-amber-900 font-black cursor-pointer text-xs"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* Main Wheel Area */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col items-center justify-center relative min-h-[480px]">
        
        {/* Needle / Pointer at Top */}
        <div className="z-20 -mb-5 flex flex-col items-center">
          <div className="w-0 h-0 border-l-[18px] border-l-transparent border-r-[18px] border-r-transparent border-t-[34px] border-t-rose-600 drop-shadow-md" />
        </div>

        {/* Canvas Wheel */}
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={430}
            height={430}
            className="max-w-full drop-shadow-2xl rounded-full"
          />
        </div>

        {/* Wheel Status or Spin CTA */}
        <div className="mt-8 flex flex-col items-center gap-3">
          {names.length === 0 ? (
            <div className="flex flex-col items-center gap-2">
              <span className="text-sm font-bold text-slate-500">
                تم اختيار جميع الطلاب في هذه الجولة أو القائمة فارغة!
              </span>
              <div className="flex gap-2">
                {activeList && activeList.students.length > 0 && (
                  <button
                    onClick={handleResetRound}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-sm rounded-xl shadow-md cursor-pointer transition-colors"
                  >
                    إعادة تعيين الجولة (إرجاع {activeList.students.length} طالب)
                  </button>
                )}
                <button
                  onClick={() => setShowRosterModal(true)}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm rounded-xl shadow-md cursor-pointer transition-colors"
                >
                  إضافة أسماء للقائمة
                </button>
              </div>
            </div>
          ) : (
            <>
              <button
                onClick={spinWheel}
                disabled={isSpinning || names.length === 0}
                className={`px-10 py-4 rounded-2xl font-black text-xl text-white shadow-xl transition-all duration-200 cursor-pointer flex items-center gap-3 tactile-btn ${
                  isSpinning
                    ? 'bg-slate-400 cursor-not-allowed scale-95 opacity-80'
                    : 'bg-gradient-to-r from-rose-500 via-pink-600 to-indigo-600 hover:scale-105 active:scale-95 shadow-rose-300'
                }`}
              >
                <Sparkles className="w-6 h-6 animate-spin" />
                <span>{isSpinning ? 'جاري السحب العشوائي...' : 'تدوير العجلة الآن!'}</span>
              </button>

              <span className="text-xs font-bold text-slate-500">
                الأسماء المتبقية في هذه الجولة: <strong className="text-indigo-600 font-mono text-sm">{names.length}</strong> طالب
              </span>
            </>
          )}
        </div>

      </div>

      {/* WINNER SPOTLIGHT POPUP: Clear & Cheerful with "إزالة الاسم من الجولة" and "إبقاؤه في العجلة" */}
      {selectedWinner && !showQuestionChallenge && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-8 text-center shadow-2xl border-2 border-rose-200 flex flex-col items-center gap-4 relative animate-scale-up">
            
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-rose-500 to-pink-500 text-white flex items-center justify-center text-4xl shadow-lg ring-6 ring-rose-100 animate-bounce">
              ⭐
            </div>
            
            <div>
              <span className="text-xs font-black text-rose-600 uppercase tracking-widest bg-rose-50 px-3 py-1 rounded-full inline-block mb-1">
                وقع الاختيار على البطل
              </span>
              <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-1 tracking-tight drop-shadow-2xs">
                {selectedWinner}
              </h2>
            </div>

            <p className="text-sm text-slate-600 font-medium">
              حان دورك يا بطل للمشاركة والإجابة وإبهار الفصل!
            </p>

            {/* If questions are attached to this activity */}
            {questions.length > 0 && (
              <button
                onClick={handleStartQuestionChallenge}
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-black rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 transition-all tactile-btn text-sm"
              >
                <HelpCircle className="w-4 h-4 stroke-[2.5]" />
                <span>طرح سؤال التحدي على الطالب 💡</span>
              </button>
            )}

            {/* The two required choices: إزالة الاسم من الجولة vs إبقاؤه في العجلة */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full mt-2 pt-2 border-t border-slate-100">
              
              {/* 1. إزالة الاسم من الجولة */}
              <button
                onClick={handleRemoveFromRound}
                className="py-3 px-3 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 font-black rounded-xl cursor-pointer transition-colors text-xs flex items-center justify-center gap-1.5"
                title="لن يتم اختياره مجدداً في هذه الجولة"
              >
                <UserX className="w-4 h-4 text-amber-700" />
                <span>إزالة الاسم من الجولة</span>
              </button>

              {/* 2. إبقاؤه في العجلة */}
              <button
                onClick={handleKeepInRound}
                className="py-3 px-3 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 font-black rounded-xl cursor-pointer transition-colors text-xs flex items-center justify-center gap-1.5"
                title="إبقاء الاسم قابلاً للاختيار في الجولات القادمة"
              >
                <UserCheck className="w-4 h-4 text-emerald-600" />
                <span>إبقاؤه في العجلة</span>
              </button>

            </div>

          </div>
        </div>
      )}

      {/* Question Challenge Modal for Winner */}
      {showQuestionChallenge && questions.length > 0 && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-100 flex flex-col gap-5 relative">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="text-sm font-black text-indigo-700 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                سؤال التحدي للبطل: {selectedWinner}
              </span>
              <button
                onClick={() => setShowQuestionChallenge(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <h3 className="text-xl font-black text-slate-900 leading-relaxed text-right">
              {questions[challengeQuestionIndex].text}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {(questions[challengeQuestionIndex].options || ['نعم', 'لا']).map((opt, i) => {
                const isSelected = selectedAnswer === opt;
                const isCorrect = String(opt).trim() === String(questions[challengeQuestionIndex].correctAnswer).trim();

                let style = 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800';
                if (isChallengeRevealed) {
                  if (isCorrect) style = 'bg-emerald-500 text-white border-emerald-600 shadow-md font-bold';
                  else if (isSelected) style = 'bg-rose-500 text-white border-rose-600 shadow-sm font-bold';
                  else style = 'bg-slate-100 text-slate-400 opacity-60';
                }

                return (
                  <button
                    key={i}
                    onClick={() => handleAnswerChallenge(opt)}
                    disabled={isChallengeRevealed}
                    className={`p-3.5 rounded-xl border-2 text-right font-bold text-sm transition-all duration-200 flex items-center justify-between gap-2 cursor-pointer ${style}`}
                  >
                    <span>{opt}</span>
                    <div className="w-6 h-6 rounded bg-black/10 flex items-center justify-center text-xs font-mono">
                      {['أ', 'ب', 'ج', 'د'][i] || i + 1}
                    </div>
                  </button>
                );
              })}
            </div>

            {isChallengeRevealed && (
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 animate-fade-in">
                <div className="text-sm font-bold text-slate-800">
                  {String(selectedAnswer).trim() === String(questions[challengeQuestionIndex].correctAnswer).trim()
                    ? '🌟 أحسنت يا بطل! إجابة صحيحة وموفقة!'
                    : '💡 الإجابة الصحيحة هي: ' + questions[challengeQuestionIndex].correctAnswer}
                </div>
                <button
                  onClick={() => {
                    setShowQuestionChallenge(false);
                  }}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-lg transition-colors cursor-pointer"
                >
                  العودة للخيارات
                </button>
              </div>
            )}

          </div>
        </div>
      )}

      {/* COMPREHENSIVE ROSTER & LIST MANAGEMENT MODAL */}
      {showRosterModal && activeList && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl border border-slate-100 flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                <h3 className="font-black text-lg text-slate-900">
                  إدارة قوائم وأسماء الطلاب
                </h3>
              </div>
              <button
                onClick={() => setShowRosterModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* 1. SELECTION & CREATION OF NAMED LISTS */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-700">
                  اختر القائمة أو أنشئ قائمة جديدة:
                </span>
                {!isCreatingList && (
                  <button
                    onClick={() => setIsCreatingList(true)}
                    className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                  >
                    <FolderPlus className="w-3.5 h-3.5" />
                    <span>+ إنشاء قائمة جديدة (مثل: الصف الرابع/1)</span>
                  </button>
                )}
              </div>

              {/* Form: Create new list */}
              {isCreatingList && (
                <div className="flex items-center gap-2 bg-white p-2.5 rounded-xl border-2 border-indigo-200 animate-fade-in">
                  <input
                    type="text"
                    value={newListName}
                    onChange={(e) => setNewListName(e.target.value)}
                    placeholder="اسم القائمة (مثال: الصف الرابع/1 أو المجموعة الذهبية)"
                    className="flex-1 p-2 border border-slate-200 rounded-lg text-xs font-bold focus:outline-none focus:border-indigo-500"
                    autoFocus
                  />
                  <button
                    onClick={handleCreateNewList}
                    className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg cursor-pointer transition-colors"
                  >
                    إنشاء
                  </button>
                  <button
                    onClick={() => {
                      setIsCreatingList(false);
                      setNewListName('');
                    }}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-lg cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              )}

              {/* List Pills */}
              <div className="flex flex-wrap gap-2 pt-1">
                {lists.map((l) => {
                  const isActive = l.id === activeListId;
                  return (
                    <div
                      key={l.id}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <button
                        onClick={() => handleSwitchList(l.id)}
                        className="cursor-pointer font-bold flex items-center gap-1"
                      >
                        <span>{l.name}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                          isActive ? 'bg-indigo-800 text-indigo-100' : 'bg-slate-100 text-slate-500'
                        }`}>
                          {l.students.length}
                        </span>
                      </button>

                      {lists.length > 1 && (
                        <button
                          onClick={() => handleDeleteList(l.id)}
                          className={`p-0.5 rounded hover:bg-black/10 cursor-pointer ${
                            isActive ? 'text-indigo-200 hover:text-white' : 'text-slate-400 hover:text-rose-600'
                          }`}
                          title="حذف هذه القائمة"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 2. ADD SINGLE STUDENT TO CURRENT LIST */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newStudentName}
                onChange={(e) => setNewStudentName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddSingleStudent()}
                placeholder="أدخل اسم طالب جديد واضغط إضافة..."
                className="flex-1 p-3 border-2 border-slate-200 rounded-xl text-sm font-bold bg-slate-50 focus:bg-white focus:border-indigo-500 focus:outline-none transition-colors"
              />
              <button
                onClick={handleAddSingleStudent}
                disabled={!newStudentName.trim()}
                className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors shrink-0"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>إضافة طالب</span>
              </button>
            </div>

            {/* 3. BULK PASTE TOGGLE & CLEAR BUTTONS */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-y border-slate-100 py-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowBulkPaste(!showBulkPaste)}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <ClipboardList className="w-3.5 h-3.5" />
                  <span>{showBulkPaste ? 'إخفاء حقل اللصق' : 'لصق عدة أسماء دفعة واحدة'}</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                {activeList.students.length > 0 && (
                  <button
                    onClick={handleClearAllStudents}
                    className="text-xs font-bold text-rose-600 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>مسح جميع الأسماء</span>
                  </button>
                )}
              </div>
            </div>

            {/* Bulk Paste Area */}
            {showBulkPaste && (
              <div className="bg-indigo-50/70 border border-indigo-200 rounded-2xl p-4 flex flex-col gap-2.5 animate-fade-in">
                <label className="text-xs font-bold text-indigo-900">
                  الصق قائمة الأسماء هنا (اسم واحد في كل سطر):
                </label>
                <textarea
                  rows={5}
                  value={bulkInput}
                  onChange={(e) => setBulkInput(e.target.value)}
                  placeholder={`أحمد البلوشي\nفاطمة المعمرية\nمحمد الحارثي\nسارة الشبيبية...`}
                  className="w-full p-3 border border-indigo-200 rounded-xl text-xs sm:text-sm font-bold bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setShowBulkPaste(false)}
                    className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:bg-white rounded-lg cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    onClick={handleInsertBulkStudents}
                    disabled={!bulkInput.trim()}
                    className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg cursor-pointer transition-colors shadow-2xs"
                  >
                    إدراج الأسماء للقائمة
                  </button>
                </div>
              </div>
            )}

            {/* 4. STUDENTS LIST DISPLAY (EDIT & DELETE INDIVIDUAL NAMES) */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 px-1">
                <span>أسماء الطلاب الحالية في ({activeList.name}):</span>
                <span className="font-mono">{activeList.students.length} طالب</span>
              </div>

              {activeList.students.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl text-xs font-bold text-slate-400">
                  لا توجد أسماء في هذه القائمة حتى الآن. أضف أسماء الطلاب أعلاه للبدء.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto p-1">
                  {activeList.students.map((student, idx) => {
                    const isEditing = editingStudentIndex === idx;

                    return (
                      <div
                        key={idx}
                        className="flex items-center justify-between bg-slate-50 hover:bg-slate-100/80 border border-slate-200 rounded-xl p-2 px-3 transition-colors"
                      >
                        {isEditing ? (
                          <div className="flex items-center gap-1.5 w-full">
                            <input
                              type="text"
                              value={editingStudentValue}
                              onChange={(e) => setEditingStudentValue(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleSaveEditStudent(idx)}
                              className="flex-1 p-1 px-2 text-xs font-bold border border-indigo-300 rounded bg-white focus:outline-none"
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveEditStudent(idx)}
                              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded cursor-pointer"
                              title="حفظ"
                            >
                              <Check className="w-4 h-4 stroke-[3]" />
                            </button>
                            <button
                              onClick={() => setEditingStudentIndex(null)}
                              className="p-1 text-slate-400 hover:bg-slate-200 rounded cursor-pointer"
                              title="إلغاء"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <>
                            <span className="text-xs font-bold text-slate-800 truncate">
                              {student}
                            </span>
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                onClick={() => {
                                  setEditingStudentIndex(idx);
                                  setEditingStudentValue(student);
                                }}
                                className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded cursor-pointer transition-colors"
                                title="تعديل الاسم"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteStudent(idx)}
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded cursor-pointer transition-colors"
                                title="حذف الاسم"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between border-t border-slate-100 pt-4">
              <span className="text-[11px] text-slate-400 font-bold">
                يتم حفظ جميع التعديلات تلقائياً للمرات القادمة
              </span>
              <button
                onClick={() => setShowRosterModal(false)}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
              >
                إغلاق وتطبيق على العجلة
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
