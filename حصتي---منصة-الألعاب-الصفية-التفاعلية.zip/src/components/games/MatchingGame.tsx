import React, { useState, useEffect } from 'react';
import { Question } from '../../types';
import { sound } from '../../services/soundService';
import { fireCelebrationConfetti, fireGrandWinnerConfetti } from '../../utils/confetti';
import { GitCommit, RotateCcw, Check, Sparkles, Award } from 'lucide-react';

interface MatchingGameProps {
  questions: Question[];
  onRestart: () => void;
}

interface PairItem {
  id: string;
  pairId: string;
  text: string;
  isMatched: boolean;
}

export const MatchingGame: React.FC<MatchingGameProps> = ({ questions, onRestart }) => {
  // Extract matching pairs
  const [leftItems, setLeftItems] = useState<PairItem[]>([]);
  const [rightItems, setRightItems] = useState<PairItem[]>([]);
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [selectedRight, setSelectedRight] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  const initGame = () => {
    let rawPairs: { left: string; right: string; id: string }[] = [];

    // Find if questions have matchPairs
    questions.forEach((q, qIdx) => {
      if (q.matchPairs && q.matchPairs.length > 0) {
        q.matchPairs.forEach((pair, pIdx) => {
          rawPairs.push({
            id: `pair-${qIdx}-${pIdx}`,
            left: pair.left,
            right: pair.right,
          });
        });
      } else {
        // Fallback: use question text as left and correct answer as right
        rawPairs.push({
          id: `pair-${qIdx}`,
          left: q.text,
          right: String(q.correctAnswer),
        });
      }
    });

    // Take max 6 pairs for a clean classroom layout
    const activePairs = rawPairs.slice(0, 6);

    const left: PairItem[] = activePairs.map((p) => ({
      id: `l-${p.id}`,
      pairId: p.id,
      text: p.left,
      isMatched: false,
    }));

    const right: PairItem[] = activePairs.map((p) => ({
      id: `r-${p.id}`,
      pairId: p.id,
      text: p.right,
      isMatched: false,
    }));

    // Shuffle both columns
    setLeftItems([...left].sort(() => Math.random() - 0.5));
    setRightItems([...right].sort(() => Math.random() - 0.5));
    setSelectedLeft(null);
    setSelectedRight(null);
    setScore(0);
    setIsCompleted(false);
  };

  useEffect(() => {
    initGame();
  }, [questions]);

  // Check matching whenever both are selected
  useEffect(() => {
    if (selectedLeft && selectedRight) {
      const leftObj = leftItems.find((item) => item.id === selectedLeft);
      const rightObj = rightItems.find((item) => item.id === selectedRight);

      if (leftObj && rightObj) {
        if (leftObj.pairId === rightObj.pairId) {
          // Success match!
          sound.playCorrect();
          fireCelebrationConfetti();
          setScore((prev) => prev + 15);

          setLeftItems((prev) =>
            prev.map((it) => (it.id === selectedLeft ? { ...it, isMatched: true } : it))
          );
          setRightItems((prev) =>
            prev.map((it) => (it.id === selectedRight ? { ...it, isMatched: true } : it))
          );
        } else {
          // Mismatch
          sound.playIncorrect();
        }
      }

      // Reset selection after brief feedback
      const timer = setTimeout(() => {
        setSelectedLeft(null);
        setSelectedRight(null);
      }, 400);

      return () => clearTimeout(timer);
    }
  }, [selectedLeft, selectedRight]);

  // Check victory
  useEffect(() => {
    if (leftItems.length > 0 && leftItems.every((it) => it.isMatched) && !isCompleted) {
      setIsCompleted(true);
      sound.playWin();
      fireGrandWinnerConfetti();
    }
  }, [leftItems, isCompleted]);

  const handleSelectLeft = (id: string) => {
    const item = leftItems.find((it) => it.id === id);
    if (!item || item.isMatched) return;
    sound.playClick();
    setSelectedLeft(id);
  };

  const handleSelectRight = (id: string) => {
    const item = rightItems.find((it) => it.id === id);
    if (!item || item.isMatched) return;
    sound.playClick();
    setSelectedRight(id);
  };

  const matchedCount = leftItems.filter((it) => it.isMatched).length;

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto py-2">
      
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-cyan-50 border border-cyan-200 text-cyan-600 rounded-xl">
            <GitCommit className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-slate-800">لعبة المطابقة والربط</h3>
            <p className="text-xs text-slate-500">اختر عنصراً من العمود الأيمن ثم طابقه مع ما يناسبه في العمود الأيسر</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-cyan-50 border border-cyan-200 px-4 py-1.5 rounded-xl text-xs font-bold text-cyan-800">
            <Award className="w-4 h-4" />
            <span>النقاط:</span>
            <span className="font-mono text-base font-black">{score}</span>
          </div>

          <div className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1.5 rounded-xl">
            التطابقات: <span className="font-mono text-indigo-600">{matchedCount} / {leftItems.length}</span>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              initGame();
              onRestart();
            }}
            className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>إعادة الترتيب</span>
          </button>
        </div>
      </div>

      {/* Completion Banner */}
      {isCompleted && (
        <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border-2 border-emerald-300 rounded-2xl p-6 text-center shadow-md animate-fade-in">
          <h2 className="text-2xl font-black text-emerald-900 mb-1">
            🎉 مذهل! تمت مطابقة جميع العناصر بنجاح تام!
          </h2>
          <p className="text-sm text-emerald-700 font-medium mb-3">
            حصد الفصل مجموع {score} نقطة في التفكير والربط المنطقي.
          </p>
          <button
            onClick={initGame}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors"
          >
            جولة جديدة
          </button>
        </div>
      )}

      {/* Matching Columns Dual Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        
        {/* Column 1: Concepts / Terms */}
        <div className="flex flex-col gap-3">
          <div className="text-xs font-bold text-slate-400 bg-slate-100/80 px-3 py-1.5 rounded-lg text-center">
            العمود الأول (المفهوم أو المصطلح)
          </div>

          {leftItems.map((item) => {
            const isSelected = selectedLeft === item.id;
            let style = 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800';
            if (item.isMatched) {
              style = 'bg-emerald-50 border-emerald-300 text-emerald-800 opacity-80 cursor-default';
            } else if (isSelected) {
              style = 'bg-cyan-50 border-cyan-500 text-cyan-900 shadow-md ring-2 ring-cyan-400 scale-[1.01]';
            }

            return (
              <button
                key={item.id}
                onClick={() => handleSelectLeft(item.id)}
                disabled={item.isMatched}
                className={`p-4 rounded-2xl border-2 text-right font-bold text-base transition-all duration-200 flex items-center justify-between gap-3 cursor-pointer min-h-[64px] ${style}`}
              >
                <span className="leading-snug flex-1">{item.text}</span>
                {item.isMatched ? (
                  <div className="w-7 h-7 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4 stroke-[3]" />
                  </div>
                ) : (
                  <div className="w-3 h-3 rounded-full bg-slate-300 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Column 2: Definitions / Answers */}
        <div className="flex flex-col gap-3">
          <div className="text-xs font-bold text-slate-400 bg-slate-100/80 px-3 py-1.5 rounded-lg text-center">
            العمود الثاني (التعريف أو الإجابة المطابقة)
          </div>

          {rightItems.map((item) => {
            const isSelected = selectedRight === item.id;
            let style = 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800';
            if (item.isMatched) {
              style = 'bg-emerald-50 border-emerald-300 text-emerald-800 opacity-80 cursor-default';
            } else if (isSelected) {
              style = 'bg-cyan-50 border-cyan-500 text-cyan-900 shadow-md ring-2 ring-cyan-400 scale-[1.01]';
            }

            return (
              <button
                key={item.id}
                onClick={() => handleSelectRight(item.id)}
                disabled={item.isMatched}
                className={`p-4 rounded-2xl border-2 text-right font-bold text-base transition-all duration-200 flex items-center justify-between gap-3 cursor-pointer min-h-[64px] ${style}`}
              >
                <span className="leading-snug flex-1">{item.text}</span>
                {item.isMatched ? (
                  <div className="w-7 h-7 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4 stroke-[3]" />
                  </div>
                ) : (
                  <div className="w-3 h-3 rounded-full bg-slate-300 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

      </div>

    </div>
  );
};
