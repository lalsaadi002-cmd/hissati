import React, { useState, useEffect } from 'react';
import { QuestionSet, Question, GameType } from '../types';
import { GAME_TYPE_METADATA } from '../data/initialData';
import { sound } from '../services/soundService';
import { storage } from '../services/storageService';
import {
  Database,
  Plus,
  Trash2,
  Edit,
  Play,
  Search,
  BookOpen,
  Check,
  X,
  Layers,
  Sparkles,
  BookMarked,
  GraduationCap,
  ChevronLeft,
} from 'lucide-react';

interface QuestionBankModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPlayWithSet: (questionSet: QuestionSet, gameType?: GameType) => void;
  initialCreateMode?: boolean;
}

export const QuestionBankModal: React.FC<QuestionBankModalProps> = ({
  isOpen,
  onClose,
  onPlayWithSet,
  initialCreateMode = false,
}) => {
  const [sets, setSets] = useState<QuestionSet[]>(() => storage.getQuestionSets());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSet, setSelectedSet] = useState<QuestionSet | null>(() => {
    const list = storage.getQuestionSets();
    return list.length > 0 ? list[0] : null;
  });

  // Create / Edit Group State
  const [isCreatingSet, setIsCreatingSet] = useState(false);
  const [editingSetId, setEditingSetId] = useState<string | null>(null);
  const [groupTitle, setGroupTitle] = useState('');
  const [groupSubject, setGroupSubject] = useState('');
  const [groupGrade, setGroupGrade] = useState('');
  const [groupLesson, setGroupLesson] = useState('');
  const [groupDesc, setGroupDesc] = useState('');

  // Add Question State
  const [isAddingQuestion, setIsAddingQuestion] = useState(false);
  const [qText, setQText] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [opt4, setOpt4] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('');
  const [qExplanation, setQExplanation] = useState('');

  // Choose Game Popup
  const [showGamePicker, setShowGamePicker] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const currentSets = storage.getQuestionSets();
    setSets(currentSets);

    if (initialCreateMode || currentSets.length === 0) {
      handleStartCreateSet();
    } else if (!selectedSet || !currentSets.find((s) => s.id === selectedSet.id)) {
      setSelectedSet(currentSets[0] || null);
      setIsCreatingSet(false);
    }
    setShowGamePicker(false);
  }, [isOpen, initialCreateMode]);

  if (!isOpen) return null;

  const reloadSets = () => {
    const list = storage.getQuestionSets();
    setSets(list);
    if (selectedSet) {
      const refreshed = list.find((s) => s.id === selectedSet.id) || null;
      setSelectedSet(refreshed);
    } else if (list.length > 0) {
      setSelectedSet(list[0]);
    }
  };

  const handleStartCreateSet = () => {
    sound.playClick();
    setEditingSetId(null);
    setGroupTitle('');
    setGroupSubject('');
    setGroupGrade('');
    setGroupLesson('');
    setGroupDesc('');
    setIsCreatingSet(true);
    setIsAddingQuestion(false);
    setShowGamePicker(false);
  };

  const handleStartEditSet = (set: QuestionSet) => {
    sound.playClick();
    setEditingSetId(set.id);
    setGroupTitle(set.title);
    setGroupSubject(set.subject);
    setGroupGrade(set.grade);
    setGroupLesson(set.lesson || '');
    setGroupDesc(set.description || '');
    setIsCreatingSet(true);
    setIsAddingQuestion(false);
    setShowGamePicker(false);
  };

  const handleSaveSet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupTitle.trim()) return;
    sound.playClick();

    if (editingSetId) {
      // Update existing
      const existing = sets.find((s) => s.id === editingSetId);
      if (existing) {
        const updated: QuestionSet = {
          ...existing,
          title: groupTitle.trim(),
          subject: groupSubject.trim() || 'عام',
          grade: groupGrade.trim() || 'جميع الصفوف',
          lesson: groupLesson.trim() || undefined,
          description: groupDesc.trim() || undefined,
          updatedAt: Date.now(),
        };
        storage.saveOrUpdateQuestionSet(updated);
        reloadSets();
        setSelectedSet(updated);
      }
    } else {
      // Create new
      const newSet: QuestionSet = {
        id: `qs-${Date.now()}`,
        title: groupTitle.trim(),
        subject: groupSubject.trim() || 'مادة دراسية',
        grade: groupGrade.trim() || 'صف دراسي',
        lesson: groupLesson.trim() || undefined,
        description: groupDesc.trim() || undefined,
        questions: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      storage.saveOrUpdateQuestionSet(newSet);
      reloadSets();
      setSelectedSet(newSet);
      setIsAddingQuestion(true); // Automatically invite teacher to add first question!
    }

    setIsCreatingSet(false);
    setEditingSetId(null);
  };

  const handleDeleteSet = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('هل أنت متأكد من حذف مجموعة الأسئلة هذه بالكامل؟')) {
      sound.playClick();
      storage.deleteQuestionSet(id);
      const remaining = sets.filter((s) => s.id !== id);
      setSets(remaining);
      if (selectedSet?.id === id) {
        setSelectedSet(remaining.length > 0 ? remaining[0] : null);
      }
      reloadSets();
    }
  };

  const handleAddQuestionToSet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSet || !qText.trim()) return;
    sound.playClick();

    const options = [opt1, opt2, opt3, opt4].filter((o) => o.trim().length > 0);
    const finalCorrect = correctAnswer.trim() || options[0] || 'الإجابة الأولى';

    const newQuestion: Question = {
      id: `q-${Date.now()}`,
      text: qText.trim(),
      options: options.length > 0 ? options : undefined,
      correctAnswer: finalCorrect,
      explanation: qExplanation.trim() || undefined,
      points: 10,
      timeLimit: 15,
    };

    const updatedSet: QuestionSet = {
      ...selectedSet,
      questions: [...selectedSet.questions, newQuestion],
      updatedAt: Date.now(),
    };

    storage.saveOrUpdateQuestionSet(updatedSet);
    reloadSets();
    setSelectedSet(updatedSet);
    setIsAddingQuestion(false);
    setQText('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setOpt4('');
    setCorrectAnswer('');
    setQExplanation('');
  };

  const handleDeleteQuestion = (qId: string) => {
    if (!selectedSet) return;
    sound.playClick();
    const updatedQuestions = selectedSet.questions.filter((q) => q.id !== qId);
    const updatedSet = {
      ...selectedSet,
      questions: updatedQuestions,
      updatedAt: Date.now(),
    };
    storage.saveOrUpdateQuestionSet(updatedSet);
    reloadSets();
    setSelectedSet(updatedSet);
  };

  const handleLaunchGameWithSet = (gameType: GameType) => {
    if (!selectedSet) return;
    sound.playClick();
    setShowGamePicker(false);
    onPlayWithSet(selectedSet, gameType);
    onClose();
  };

  const allGameTypesList: GameType[] = [
    'team-race',
    'mystery-box',
    'wheel-of-names',
    'multiple-choice',
    'flip-card',
    'matching',
    'time-attack',
    'class-points',
    'exit-ticket',
  ];

  const filteredSets = sets.filter((s) =>
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.grade.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (s.lesson && s.lesson.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="bg-gradient-to-b from-white via-cyan-50/30 to-blue-50/30 rounded-3xl max-w-5xl w-full h-[90vh] shadow-2xl border border-cyan-200 flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="px-6 py-5 border-b border-cyan-100 flex items-center justify-between bg-gradient-to-r from-cyan-600 via-teal-600 to-blue-600 text-white shadow-xs">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-white shadow-inner">
              <Database className="w-6 h-6 stroke-[2.4]" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">
                بنك الأسئلة المفتوح للمعلم
              </h2>
              <p className="text-xs text-cyan-100 font-medium mt-0.5">
                اكتب مادتك وصفك ودرسك وأسئلتك بحرية كاملة دون أي اختيارات أو قيود مسبقة
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-slate-50/40">
          
          {/* SIDEBAR: Sets List & Permanent "+ إنشاء مجموعة" button */}
          <div className="w-full md:w-84 border-b md:border-b-0 md:border-l border-slate-200 p-4 flex flex-col gap-3 bg-white/70 overflow-y-auto">
            
            {/* Clear Primary CTA Button */}
            <button
              onClick={handleStartCreateSet}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-cyan-600 via-teal-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white rounded-2xl text-xs font-black flex items-center justify-center gap-2 shadow-md shadow-cyan-600/20 cursor-pointer transition-all tactile-btn"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>+ إنشاء مجموعة أسئلة جديدة</span>
            </button>

            {/* Search */}
            {sets.length > 0 && (
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="بحث في مجموعاتك..."
                  className="w-full pl-3 pr-9 py-2.5 text-xs font-bold border border-slate-200 bg-white rounded-xl focus:ring-2 focus:ring-cyan-500 focus:outline-none shadow-2xs"
                />
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
              </div>
            )}

            {/* Sets list cards */}
            <div className="flex flex-col gap-2.5 pt-1">
              {sets.length === 0 ? (
                <div className="text-center py-8 px-3 text-slate-500 bg-slate-50/80 border-2 border-dashed border-cyan-200 rounded-2xl text-xs">
                  <span className="text-xl block mb-2">📝</span>
                  <span className="font-black text-slate-800 block mb-1">لا توجد مجموعات بعد</span>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    اضغط على الزر أعلاه لإنشاء مجموعتك الأولى وكتابة أسئلتك بحرية
                  </p>
                </div>
              ) : filteredSets.length === 0 ? (
                <div className="text-center py-6 px-2 text-slate-400 text-xs font-medium">
                  لا توجد نتائج مطابقة لبحثك
                </div>
              ) : (
                filteredSets.map((set) => {
                  const isSelected = selectedSet?.id === set.id;
                  return (
                    <div
                      key={set.id}
                      onClick={() => {
                        sound.playClick();
                        setSelectedSet(set);
                        setIsCreatingSet(false);
                        setIsAddingQuestion(false);
                        setShowGamePicker(false);
                      }}
                      className={`p-3.5 rounded-2xl border-2 text-right transition-all cursor-pointer select-none flex flex-col gap-1.5 ${
                        isSelected
                          ? 'bg-cyan-50/90 border-cyan-500 shadow-sm ring-1 ring-cyan-400'
                          : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-black text-cyan-800 bg-cyan-100/80 border border-cyan-200 px-2 py-0.5 rounded-md truncate max-w-[140px]">
                          {set.subject || 'مادة'}
                        </span>
                        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => handleStartEditSet(set)}
                            className="text-slate-400 hover:text-cyan-700 p-1 transition-colors cursor-pointer"
                            title="تعديل تفاصيل المجموعة"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => handleDeleteSet(set.id, e)}
                            className="text-slate-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                            title="حذف المجموعة"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <h4 className="font-black text-sm text-slate-900 leading-snug">
                        {set.title}
                      </h4>

                      <div className="flex items-center justify-between text-xs text-slate-500 font-semibold pt-1">
                        <span className="truncate max-w-[130px]">{set.grade || 'الصف'}</span>
                        <span className="font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-bold">
                          {set.questions.length} أسئلة
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

          </div>

          {/* MAIN AREA: Set Creation / Active Set Questions */}
          <div className="flex-1 p-6 overflow-y-auto flex flex-col gap-6">
            
            {/* Form: Create or Edit Group (Free inputs for Subject, Grade, Lesson, Title) */}
            {isCreatingSet ? (
              <form onSubmit={handleSaveSet} className="bg-white border-2 border-cyan-300 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col gap-5 animate-fade-in">
                <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                  <div>
                    <h3 className="font-black text-lg text-slate-900">
                      {editingSetId ? 'تعديل بيانات مجموعة الأسئلة' : '+ إنشاء مجموعة أسئلة جديدة'}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium mt-0.5">
                      اكتب بياناتك بحرية كاملة دون أي قيود على المادة أو الصف أو المنهج
                    </p>
                  </div>
                  {sets.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setIsCreatingSet(false)}
                      className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      إلغاء
                    </button>
                  )}
                </div>

                {/* 1. اسم المجموعة */}
                <div>
                  <label className="text-xs font-black text-slate-800 block mb-1">
                    اسم المجموعة <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={groupTitle}
                    onChange={(e) => setGroupTitle(e.target.value)}
                    placeholder="مثال: مراجعة شاملة للوحدة الأولى / أسئلة مسابقة اليوم"
                    className="w-full p-3.5 border-2 border-slate-200 rounded-xl text-sm font-bold bg-slate-50 focus:bg-white focus:border-cyan-500 focus:outline-none transition-colors"
                  />
                </div>

                {/* 2. اسم المادة + الصف الدراسي (كتابة حرة تماماً) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-black text-slate-800 block mb-1">
                      اسم المادة (اكتب اسم مادتك بحرية) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={groupSubject}
                      onChange={(e) => setGroupSubject(e.target.value)}
                      placeholder="مثال: لغة إنجليزية / فيزياء / رياضيات / قرآن..."
                      className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-bold bg-slate-50 focus:bg-white focus:border-cyan-500 focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-800 block mb-1">
                      الصف الدراسي (اكتب الصف بحرية) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={groupGrade}
                      onChange={(e) => setGroupGrade(e.target.value)}
                      placeholder="مثال: الصف الأول / الصف الرابع / الصف السابع / الصف العاشر..."
                      className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-bold bg-slate-50 focus:bg-white focus:border-cyan-500 focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* 3. اسم الدرس أو الوحدة (كتابة حرة) */}
                <div>
                  <label className="text-xs font-black text-slate-800 block mb-1">
                    اسم الدرس أو الوحدة (كتابة حرة)
                  </label>
                  <input
                    type="text"
                    value={groupLesson}
                    onChange={(e) => setGroupLesson(e.target.value)}
                    placeholder="مثال: الدرس الثاني: حالات المادة / وحدة القراءة والفهم"
                    className="w-full p-3 border-2 border-slate-200 rounded-xl text-sm font-bold bg-slate-50 focus:bg-white focus:border-cyan-500 focus:outline-none transition-colors"
                  />
                </div>

                {/* 4. وصف أو ملاحظات */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    ملاحظات أو وصف إضافي (اختياري)
                  </label>
                  <textarea
                    rows={2}
                    value={groupDesc}
                    onChange={(e) => setGroupDesc(e.target.value)}
                    placeholder="ملاحظات للمعلم أو أهداف الأسئلة..."
                    className="w-full p-2.5 border-2 border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  {sets.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setIsCreatingSet(false)}
                      className="px-5 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                    >
                      إلغاء
                    </button>
                  )}
                  <button
                    type="submit"
                    className="px-7 py-3.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-black text-xs sm:text-sm rounded-xl cursor-pointer shadow-md shadow-cyan-600/20 tactile-btn"
                  >
                    {editingSetId ? 'حفظ التعديلات' : 'حفظ المجموعة والبدء بإضافة الأسئلة'}
                  </button>
                </div>
              </form>
            ) : selectedSet ? (
              
              /* Selected Set View */
              <div className="flex flex-col gap-6">
                
                {/* Header Card of Selected Set */}
                <div className="bg-white border-2 border-slate-200/90 rounded-3xl p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <span className="text-xs font-black text-cyan-800 bg-cyan-100/80 border border-cyan-200 px-3 py-1 rounded-lg">
                        المادة: {selectedSet.subject}
                      </span>
                      <span className="text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-lg">
                        الصف: {selectedSet.grade}
                      </span>
                      {selectedSet.lesson && (
                        <span className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-lg">
                          الدرس: {selectedSet.lesson}
                        </span>
                      )}
                      <span className="text-xs text-slate-500 font-mono font-bold bg-slate-50 px-2 py-0.5 rounded">
                        ({selectedSet.questions.length} أسئلة)
                      </span>
                    </div>

                    <h3 className="text-2xl font-black text-slate-900 leading-snug">
                      {selectedSet.title}
                    </h3>

                    {selectedSet.description && (
                      <p className="text-xs text-slate-600 mt-1 max-w-xl font-medium">
                        {selectedSet.description}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    {/* Launch Game Picker Button */}
                    <button
                      onClick={() => {
                        sound.playClick();
                        setShowGamePicker(!showGamePicker);
                      }}
                      className="px-5 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-500/20 flex items-center gap-2 cursor-pointer transition-colors tactile-btn"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>استخدام هذه المجموعة في أي لعبة 🚀</span>
                    </button>

                    <button
                      onClick={() => {
                        sound.playClick();
                        setIsAddingQuestion(true);
                      }}
                      className="px-4 py-3 bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border border-cyan-200 font-black text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors tactile-btn"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                      <span>إضافة سؤال</span>
                    </button>

                    <button
                      onClick={() => handleStartEditSet(selectedSet)}
                      className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors cursor-pointer"
                      title="تعديل تفاصيل المجموعة"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* GAME PICKER POPUP: Teacher chooses ANY of the 9 games for this set */}
                {showGamePicker && (
                  <div className="bg-gradient-to-br from-indigo-50 via-purple-50 to-sky-50 border-2 border-indigo-300 rounded-3xl p-5 shadow-lg flex flex-col gap-3 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-indigo-950 flex items-center gap-2">
                        <span>🎮</span>
                        <span>اختر اللعبة التي ترغب بتشغيلها مع مجموعة: <strong>"{selectedSet.title}"</strong></span>
                      </span>
                      <button
                        onClick={() => setShowGamePicker(false)}
                        className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        ✕
                      </button>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
                      {allGameTypesList.map((type) => {
                        const meta = GAME_TYPE_METADATA[type];
                        return (
                          <button
                            key={type}
                            onClick={() => handleLaunchGameWithSet(type)}
                            className="p-3 bg-white hover:bg-indigo-50 border-2 border-indigo-100 hover:border-indigo-400 rounded-2xl text-right flex items-center gap-3 transition-all cursor-pointer shadow-2xs group"
                          >
                            <span className="text-2xl group-hover:scale-110 transition-transform">
                              {meta.emoji}
                            </span>
                            <div className="overflow-hidden">
                              <span className="text-xs font-black text-slate-900 block truncate">
                                {meta.name}
                              </span>
                              <span className="text-[10px] text-slate-500 block truncate">
                                {meta.badge}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Form: Add Question to Selected Set */}
                {isAddingQuestion && (
                  <form onSubmit={handleAddQuestionToSet} className="bg-white border-2 border-cyan-400 rounded-3xl p-6 shadow-md flex flex-col gap-4 animate-fade-in">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <h4 className="font-black text-sm text-cyan-950 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-cyan-600" />
                        <span>إضافة سؤال جديد إلى: {selectedSet.title}</span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setIsAddingQuestion(false)}
                        className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        إلغاء
                      </button>
                    </div>
                    
                    <div>
                      <label className="text-xs font-black text-slate-800 block mb-1">
                        نص السؤال <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={qText}
                        onChange={(e) => setQText(e.target.value)}
                        placeholder="اكتب نص السؤال هنا..."
                        className="w-full p-3.5 border-2 border-slate-200 rounded-xl text-sm bg-slate-50 focus:bg-white focus:outline-none focus:border-cyan-500 font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">
                        الخيارات (اختياري - في حال كانت اللعبة اختيار من متعدد)
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <input
                          type="text"
                          value={opt1}
                          onChange={(e) => setOpt1(e.target.value)}
                          placeholder="الخيار الأول..."
                          className="w-full p-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white focus:outline-none"
                        />
                        <input
                          type="text"
                          value={opt2}
                          onChange={(e) => setOpt2(e.target.value)}
                          placeholder="الخيار الثاني..."
                          className="w-full p-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white focus:outline-none"
                        />
                        <input
                          type="text"
                          value={opt3}
                          onChange={(e) => setOpt3(e.target.value)}
                          placeholder="الخيار الثالث..."
                          className="w-full p-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white focus:outline-none"
                        />
                        <input
                          type="text"
                          value={opt4}
                          onChange={(e) => setOpt4(e.target.value)}
                          placeholder="الخيار الرابع..."
                          className="w-full p-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-black text-emerald-800 block mb-1">
                          الإجابة الصحيحة النموذجية <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={correctAnswer}
                          onChange={(e) => setCorrectAnswer(e.target.value)}
                          placeholder="اكتب الإجابة الصحيحة بالضبط..."
                          className="w-full p-3 border-2 border-emerald-400 rounded-xl text-xs bg-white font-black text-emerald-950 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-700 block mb-1">
                          توضيح أو معلومة إثرائية (اختياري)
                        </label>
                        <input
                          type="text"
                          value={qExplanation}
                          onChange={(e) => setQExplanation(e.target.value)}
                          placeholder="توضيح يظهر للطلاب بعد الإجابة..."
                          className="w-full p-3 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingQuestion(false)}
                        className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                      >
                        إلغاء
                      </button>
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-black text-xs rounded-xl cursor-pointer shadow-xs tactile-btn"
                      >
                        حفظ السؤال في المجموعة
                      </button>
                    </div>
                  </form>
                )}

                {/* Questions List */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-black text-sm text-slate-800">
                      أسئلة هذه المجموعة ({selectedSet.questions.length})
                    </h4>
                    {selectedSet.questions.length > 0 && !isAddingQuestion && (
                      <button
                        onClick={() => setIsAddingQuestion(true)}
                        className="text-xs font-bold text-cyan-700 hover:text-cyan-900 flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>إضافة سؤال آخر</span>
                      </button>
                    )}
                  </div>

                  {selectedSet.questions.length === 0 ? (
                    <div className="text-center py-12 px-4 text-slate-500 bg-white border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-cyan-50 text-cyan-600 flex items-center justify-center text-xl font-bold">
                        ✍️
                      </div>
                      <h4 className="font-bold text-sm text-slate-800">لا توجد أسئلة بعد في هذه المجموعة</h4>
                      <p className="text-xs text-slate-500 max-w-sm">
                        أضف أسئلتك وإجاباتها بحرية لتصبح المجموعة جاهزة للانطلاق في ألعاب الحصة.
                      </p>
                      <button
                        onClick={() => setIsAddingQuestion(true)}
                        className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-black text-xs rounded-xl shadow-xs cursor-pointer tactile-btn flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4 stroke-[3]" />
                        <span>إضافة أول سؤال الآن</span>
                      </button>
                    </div>
                  ) : (
                    selectedSet.questions.map((q, idx) => (
                      <div
                        key={q.id}
                        className="p-4 bg-white border-2 border-slate-200/90 rounded-2xl shadow-2xs flex flex-col gap-2.5 hover:border-cyan-200 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-2.5">
                            <span className="w-6 h-6 rounded-lg bg-cyan-100 text-cyan-800 text-xs font-mono font-black flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <span className="font-bold text-sm text-slate-900 leading-snug">
                              {q.text}
                            </span>
                          </div>
                          <button
                            onClick={() => handleDeleteQuestion(q.id)}
                            className="text-slate-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                            title="حذف السؤال"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Options preview */}
                        {q.options && q.options.length > 0 && (
                          <div className="flex flex-wrap gap-2 pt-1 mr-8">
                            {q.options.map((opt, oIdx) => {
                              const isCorrect = String(opt).trim() === String(q.correctAnswer).trim();
                              return (
                                <span
                                  key={oIdx}
                                  className={`text-xs px-2.5 py-1 rounded-lg border font-medium ${
                                    isCorrect
                                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-black'
                                      : 'bg-slate-50 border-slate-200 text-slate-600'
                                  }`}
                                >
                                  {isCorrect && '✓ '}
                                  {opt}
                                </span>
                              );
                            })}
                          </div>
                        )}

                        {q.explanation && (
                          <p className="text-xs text-slate-500 mr-8 bg-slate-50 p-2 rounded-lg border border-slate-200/60">
                            💡 {q.explanation}
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>

              </div>

            ) : (
              /* No Set Selected & Empty State */
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-500 bg-white/70 rounded-3xl border-2 border-dashed border-cyan-200 gap-4">
                <div className="w-16 h-16 rounded-3xl bg-cyan-100/70 text-cyan-700 flex items-center justify-center text-3xl shadow-inner">
                  📚
                </div>
                <div>
                  <h3 className="font-black text-lg text-slate-900">بنك الأسئلة المفتوح للمعلم</h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-md font-medium leading-relaxed">
                    لا توجد مجموعات بعد. ابدأ بإنشاء مجموعتك الأولى واكتب اسم المادة والصف والدرس بحرية تامة دون أي قيود!
                  </p>
                </div>
                <button
                  onClick={handleStartCreateSet}
                  className="px-6 py-3 bg-gradient-to-r from-cyan-600 via-teal-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-black text-xs rounded-2xl shadow-md shadow-cyan-600/20 cursor-pointer transition-all tactile-btn flex items-center gap-2"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>+ إنشاء مجموعة أسئلة جديدة</span>
                </button>
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
