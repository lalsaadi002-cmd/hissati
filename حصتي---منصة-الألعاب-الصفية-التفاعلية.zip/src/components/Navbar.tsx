import React from 'react';
import { Volume2, VolumeX, Maximize, Plus, Sparkles, Database, Trophy, Home } from 'lucide-react';
import { sound } from '../services/soundService';
import { toggleFullScreenElement } from '../utils/confetti';

interface NavbarProps {
  currentTab: 'home' | 'games' | 'activities' | 'question-bank';
  onSelectTab: (tab: 'home' | 'games' | 'activities' | 'question-bank') => void;
  onCreateActivity: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onCreateActivity,
  isMuted,
  onToggleMute,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/75 backdrop-blur-lg border-b border-indigo-200/60 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Zone 1: Brand Wordmark */}
        <div 
          onClick={() => {
            sound.playClick();
            onSelectTab('home');
          }}
          className="flex items-center gap-3.5 cursor-pointer select-none group"
        >
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/25 group-hover:scale-105 group-hover:rotate-1 transition-all duration-300">
              <Sparkles className="w-6 h-6 text-amber-300 animate-subtle-pulse" />
            </div>
            <span className="absolute -bottom-1 -left-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-white"></span>
            </span>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 group-hover:text-indigo-600 transition-colors">
                حِصَّتِي
              </span>
              <span className="text-[10px] font-black bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-2 py-0.5 rounded-full shadow-xs">
                تفاعلي
              </span>
            </div>
            <span className="text-[11px] font-semibold text-slate-500 hidden sm:inline -mt-0.5">
              ألعاب صفية للشاشات الذكية
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-1.5 p-1.5 bg-slate-100/90 rounded-2xl border border-slate-200/80 shadow-inner">
          <button
            onClick={() => {
              sound.playClick();
              onSelectTab('home');
            }}
            className={`px-4 py-2 text-sm font-bold rounded-xl transition-all duration-200 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              currentTab === 'home'
                ? 'bg-white text-indigo-700 shadow-sm shadow-slate-200 scale-101'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>الرئيسية</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onSelectTab('games');
            }}
            className={`px-4 py-2 text-sm font-bold rounded-xl transition-all duration-200 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              currentTab === 'games'
                ? 'bg-white text-indigo-700 shadow-sm shadow-slate-200 scale-101'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Trophy className="w-4 h-4 text-amber-500" />
            <span>مكتبة الألعاب</span>
            <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded-md font-mono">9</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onSelectTab('activities');
            }}
            className={`px-4 py-2 text-sm font-bold rounded-xl transition-all duration-200 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              currentTab === 'activities'
                ? 'bg-white text-indigo-700 shadow-sm shadow-slate-200 scale-101'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <span>أنشطتي المحفوظة</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onSelectTab('question-bank');
            }}
            className={`px-4 py-2 text-sm font-bold rounded-xl transition-all duration-200 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              currentTab === 'question-bank'
                ? 'bg-white text-indigo-700 shadow-sm shadow-slate-200 scale-101'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Database className="w-4 h-4 text-cyan-600" />
            <span>بنك الأسئلة</span>
          </button>
        </nav>

        {/* Zone 3: Actions & Quick Utilities */}
        <div className="flex items-center gap-2.5">
          {/* Sound Toggle */}
          <button
            onClick={onToggleMute}
            title={isMuted ? 'تشغيل المؤثرات الصوتية' : 'كتم المؤثرات الصوتية'}
            className={`p-2.5 rounded-xl border transition-all cursor-pointer tactile-btn ${
              isMuted
                ? 'bg-rose-50 border-rose-200 text-rose-600'
                : 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100 shadow-xs'
            }`}
            aria-label="Sound Toggle"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => {
              sound.playClick();
              toggleFullScreenElement();
            }}
            title="وضع ملء الشاشة للبروجكتر"
            className="hidden sm:inline-flex p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-xs transition-all cursor-pointer tactile-btn"
            aria-label="Fullscreen Toggle"
          >
            <Maximize className="w-4 h-4" />
          </button>

          {/* Create Activity CTA */}
          <button
            onClick={() => {
              sound.playClick();
              onCreateActivity();
            }}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-700 hover:from-indigo-700 hover:to-purple-800 text-white text-sm font-black rounded-xl shadow-md shadow-indigo-500/20 hover:shadow-lg transition-all duration-200 whitespace-nowrap cursor-pointer tactile-btn"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>إنشاء نشاط جديد</span>
          </button>
        </div>

      </div>
    </header>
  );
};
